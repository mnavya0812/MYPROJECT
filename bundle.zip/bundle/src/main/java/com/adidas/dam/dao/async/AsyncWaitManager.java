package com.adidas.dam.dao.async;

import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AsyncWaitManager {

	private final Logger LOG = LoggerFactory.getLogger(AsyncWaitManager.class);
	private Set<String> inProgressItems;

	public AsyncWaitManager() {
		inProgressItems = new HashSet<String>();
	}

	public synchronized boolean hasItem(String item) {
		return inProgressItems.contains(item);
	}

	public synchronized void addItem(String item) {
		inProgressItems.add(item);
	}

	public synchronized void removeItem(String item) {
		inProgressItems.remove(item);
	}

	public void waitForCompletion(AsyncCompletionCheck completionCheck, int maxWaitSeconds) {
		try {
			int waitCount = 0;

			while (waitCount < maxWaitSeconds && !completionCheck.isComplete()) { //Wait up to maxWaitSeconds seconds before giving up
				if (waitCount % 10 == 0) {
					LOG.debug(completionCheck.getWaitMessage());
				}
				
				Thread.sleep(1000);
				waitCount++;
			}
			
			LOG.debug(completionCheck.getCompleteMessage());
		} catch (InterruptedException e) {
			LOG.error("Interrupted exception in AsyncWaitManager.");
		}   	
	}
}
