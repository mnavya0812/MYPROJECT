package com.adidas.dam.models;


import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement
public class ViprServiceData {

	String enevelop;
	String header;
	String authenticatedUser;
	String username;
	String password;
	String body;
	String requeSample;
	String envelopXmlns;
	String authenticatedUserXmlns;
	String requeSampleXmlns;
	String fileName;
	  
	  
	  /***
		<Envelope xmlns="http://schemas.xmlsoap.org/soap/envelope/">
	    <Header>
	        <AuthenticatedUser xmlns="http://usindamap64.am.adsint.biz">
	            <username>div</username>
	            <password>pwfdIvAdIdAs</password>
	        </AuthenticatedUser>
	    </Header>
	    <Body>
	        <RequeSample xmlns="http://usindamap64.am.adsint.biz/OrderTracking">
	            <FileName>4352W_UJA_TKUWUJA_010_F.psd</FileName>
	        </RequeSample>
	    </Body>
		</Envelope>
	
	  **/
	
	public ViprServiceData() {}
	
	public String getEnvelope() {
		return header;
	}

	@XmlElement
	public void setEnvelope(String enevelop) {
		this.enevelop = enevelop;
	}

	   
	public String getHeader() {
		return header;
	}

	@XmlElement
	public void setHeader(String header) {
		this.header = header;
	}
	
	public String getAuthenticatedUser() {
		return authenticatedUser;
	}

	@XmlElement
	public void setAuthenticatedUser(String authenticatedUser) {
		this.authenticatedUser = authenticatedUser;
	}

	public String getUserName() {
		return username;
	}

	@XmlElement
	public void setUserName(String username) {
		this.username = username;
	}
	
	public String getPassword() {
		return header;
	}


	@XmlElement
	public void setPassword(String password) {
		this.password = password;
	}

	
	public String getRequeSample() {
		return requeSample;
	}

	@XmlElement
	public void setRequeSample(String requeSample) {
		this.requeSample = requeSample;
	}

	public String getFileName() {
		return fileName;
	}

	@XmlElement
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	
	public String getBody() {
		return header;
	}

	@XmlElement
	public void setBody(String body) {
		this.body = body;
	}


	@XmlAttribute
	public void setEnvelopXmlns(String xmlns) {
		this.envelopXmlns = xmlns;
	}

	public String getEnvelopXmlns() {
		return this.envelopXmlns;
	}
	
	@XmlAttribute
	public void setAuthenticatedUserXmlns(String xmlns) {
		this.authenticatedUserXmlns = xmlns;
	}

	public String getAuthenticatedUserXmlns() {
		return authenticatedUserXmlns;
	}
	
	@XmlAttribute
	public void setRequeSampleXmlns(String xmlns) {
		this.requeSampleXmlns = xmlns;
	}
	
	public String getRequeSampleXmlns() {
		return this.requeSampleXmlns;
	}
	
	
	/***
	 * 
	 * @param userName
	 * @param pswd
	 * @param fileName
	 * @param authUserXmlns
	 * @param reqSampleXmlns
	 * @return
	 */
	public String getSOAPxml( String userName, String pswd, String fileName, String authUserXmlns, String reqSampleXmlns ) {
		String XmlSoap = "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\">"
					   + "  <Header>"
					   + "     <AuthenticatedUser xmlns=\""+authUserXmlns+"\">"
					   + "          <username>"+userName+"</username>"
					   + "          <password>"+pswd+"</password>"
					   + "      </AuthenticatedUser>"
					   + "  </Header>"
					   + "  <Body>"
					   + "      <RequeSample xmlns=\""+reqSampleXmlns+"\">"
					   + "          <FileName>"+fileName+"</FileName>"
					   + "      </RequeSample>"
					   + "  </Body>"
					   + "</Envelope>";
		
		return XmlSoap;
	}

}