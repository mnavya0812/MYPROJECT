package com.adidas.dam.workflows;

import com.adidas.dam.util.Helper;
import com.adidas.dam.util.SLDConstants;
import com.adobe.granite.asset.api.Asset;
import com.day.cq.dam.commons.util.DamUtil;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.exec.WorkflowProcess;
import com.day.cq.workflow.metadata.MetaDataMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import javax.jcr.Node;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceMetadata;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.osgi.framework.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component
@Service
@Properties({
    @Property(name = Constants.SERVICE_DESCRIPTION, value = "Adidas Add Asset Tags", propertyPrivate = false),
    @Property(name = Constants.SERVICE_VENDOR, value = "3|SHARE"),
    @Property(name = "process.label", value = "Adidas Add Asset Tags", propertyPrivate = false)})
public class AddAssetTags implements WorkflowProcess {

    private static final Logger log = LoggerFactory.getLogger(AddAssetTags.class);
    private ResourceResolver resolver = null;

    @Reference
    ResourceResolverFactory resourceResolverFactory;

    @Override
    public void execute(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap metaDataMap) throws WorkflowException {

        try {
            HashMap map = new HashMap();
            map.put("user.jcr.session", workflowSession.getSession());
            resolver = resourceResolverFactory.getResourceResolver(map);
            resolver.refresh();
            Resource payloadResource = Helper.getResourceFromPayload(workItem, workflowSession.getSession(), resolver);
            if (payloadResource != null && !DamUtil.isSubAsset(payloadResource)) {
              
                
                Resource metadataResource = payloadResource.getChild(SLDConstants.ASSET_JCR_METADATA);
              
                ValueMap metadataProps = null;
                if (metadataResource != null){
                 metadataProps = metadataResource.getValueMap();
                }
              
                
                
                Node metadataNode = metadataResource.adaptTo(Node.class);
                if (metadataProps != null){
                if (!metadataProps.containsKey(SLDConstants.DAM_TAGS) && !Helper.isAssetConfidential(payloadResource)) {
                	
                    TagManager tagManager = resolver.adaptTo(TagManager.class);
                    Tag tag = tagManager.resolve(SLDConstants.TAGS_ADIDAS_EVERYONE);

                    if (tag == null) {
                        // create tag if doesnt exist
                        tag = tagManager.createTag(SLDConstants.TAGS_ADIDAS_EVERYONE, SLDConstants.TAGS_EVERYONE, "");
                    }

                    // apply tag to resource metadata
                    Tag[] currentTags = tagManager.getTags(payloadResource);
                    Set<String> allTagValues = new HashSet<String>();
                    if (currentTags != null) {
                        for (Tag currentTag : currentTags) {
                        	
                            allTagValues.add(currentTag.getTagID());
                            
                            
                        }
                    }
                    allTagValues.add(tag.getTagID());
                    

                    
                    metadataNode.setProperty(SLDConstants.DAM_TAGS, allTagValues.toArray(new String[0]));
                    log.info("tag {} was set for resource {}", tag.getTagID(), payloadResource.getPath());
                }
                
            }

            }

        } catch (Exception e1) {
            log.error("err in AddAssetTags.execute -->" + e1.getMessage(), e1);
        }

    }

}
