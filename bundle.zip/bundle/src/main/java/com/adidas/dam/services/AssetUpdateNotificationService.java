package com.adidas.dam.services;

public interface AssetUpdateNotificationService {
	public String[] getPublisherUrls();
	public String getPublisherCredentials();
	public void notifyUsers();
}
