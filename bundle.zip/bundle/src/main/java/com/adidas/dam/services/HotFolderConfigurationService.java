package com.adidas.dam.services;

import com.adidas.dam.hotFolder.HotFolderConfiguration;
import com.day.cq.commons.jcr.JcrUtil;
import org.apache.felix.scr.annotations.*;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import java.util.HashMap;
import java.util.Map;

@Component(immediate = true,name = "Adidas Hot Folder Configuration Service")
@Service(value=HotFolderConfigurationService.class)
public class HotFolderConfigurationService {

    private static final Logger log = LoggerFactory.getLogger(HotFolderConfigurationService.class);
    private HashMap<String,HotFolderConfiguration> hotFolderConfigurations = new HashMap<String, HotFolderConfiguration>();

    @Reference
    ResourceResolverFactory resolverFactory;

    public void addHotFolderConfiguration(String key,HotFolderConfiguration hotFolderConfiguration){
        this.hotFolderConfigurations.put(key,hotFolderConfiguration);
        log.info("Loaded: " + key);

        ensureHotFolderExists(key);
    }

    private void ensureHotFolderExists(String hotFolderPath) {

        try {
            ResourceResolver resolver = resolverFactory.getAdministrativeResourceResolver(null);
            Session session = resolver.adaptTo(Session.class);
            JcrUtil.createPath(hotFolderPath,"sling:OrderedFolder",session);
            session.save();
            session.logout();
        } catch (LoginException e) {
            log.error("Cannot get admin session." + e.getMessage());
        } catch (RepositoryException e) {
            log.error("Cannot resolve session." + e.getMessage());
        }

    }

    public HotFolderConfiguration getHotFolderConfiguration(String key) {
        return this.hotFolderConfigurations.get(key);
    }

    public HashMap<String, HotFolderConfiguration> getHotFolderConfigurations(){
        return this.hotFolderConfigurations;
    }

    @Activate
    public void activate(ComponentContext componentContext) {

    }

    /**
     * Checks a path and finds a configuration for that path or null if no configuration covers that path.
     * @param payloadPath path of an asset in a hot folder
     * @return null if not configuration found for the path
     */
    public HotFolderConfiguration findConfigurationForPath(String payloadPath) {
        for (Map.Entry<String,HotFolderConfiguration> config : hotFolderConfigurations.entrySet()) {
            String hotFolderPath = config.getKey();

            //Check that the payload starts with the hotFolder, and that is the end of the directory name
            if (payloadPath.startsWith(hotFolderPath) && payloadPath.charAt(hotFolderPath.length()) == '/') {

                //get the config for this hotFolder
                return config.getValue();
            }
        }

        return null;
    }
}
