package com.adidas.dam.services;

import java.util.Map;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.PropertyUnbounded;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(metatype = true, immediate = true,label = "Adidas SOS Service")
@Service(SOSAdidasService.class)
@Properties({
        @Property(name = "siteRootFolder", label = "Site Root Folder", unbounded = PropertyUnbounded.DEFAULT)
})
public class SOSAdidasService {

	private String siteRootFolder;

	private String highResJpeg;
	private String lowResJpeg;
	private String cmykTff;
	private String rgbTff;
	private String pdf;
	private String png;
	
	
	private static final Logger LOG = LoggerFactory.getLogger(SOSAdidasService.class);
	
	 @Activate
	  protected void activate(Map<String, Object> properties)
	  {
	    
	    readProperties(properties);
	  }
	
	
	 protected void readProperties(Map<String, Object> properties)
	  {
	    LOG.info(properties.toString());
	    this.siteRootFolder = PropertiesUtil.toString(properties.get("siteRootFolder"), "sld");
	    
	    this.highResJpeg  = PropertiesUtil.toString(properties.get("highResJpeg"), ".aem.high.res.jpeg");

	    this.lowResJpeg  = PropertiesUtil.toString(properties.get("lowResJpeg"), ".aem.low.res.jpeg");

	    this.cmykTff  = PropertiesUtil.toString(properties.get("cmykTff"), ".cmyk.tiff");

	    this.rgbTff  = PropertiesUtil.toString(properties.get("rgbTff"), ".rgb.tiff");

	    this.pdf  = PropertiesUtil.toString(properties.get("pdf"), ".pdf");

	    this.png  = PropertiesUtil.toString(properties.get("png"), ".png");
	  
	  }


	public String getSiteRootFolder() {
		return siteRootFolder;
	}


	public void setSiteRootFolder(String siteRootFolder) {
		this.siteRootFolder = siteRootFolder;
	}


	public String getHighResJpeg() {
		return highResJpeg;
	}


	public void setHighResJpeg(String highResJpeg) {
		this.highResJpeg = highResJpeg;
	}


	public String getLowResJpeg() {
		return lowResJpeg;
	}


	public void setLowResJpeg(String lowresJpeg) {
		this.lowResJpeg = lowresJpeg;
	}


	public String getCmykTff() {
		return cmykTff;
	}


	public void setCmykTff(String cmykTff) {
		this.cmykTff = cmykTff;
	}


	public String getRgbTff() {
		return rgbTff;
	}


	public void setRgbTff(String rgbTff) {
		this.rgbTff = rgbTff;
	}


	public String getPdf() {
		return pdf;
	}


	public void setPdf(String pdf) {
		this.pdf = pdf;
	}


	public String getPng() {
		return png;
	}


	public void setPng(String png) {
		this.png = png;
	}
	
	
	
}
