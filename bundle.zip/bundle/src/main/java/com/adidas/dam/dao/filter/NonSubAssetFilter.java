package com.adidas.dam.dao.filter;

import org.apache.sling.api.resource.Resource;

import com.day.cq.dam.commons.util.DamUtil;

public class NonSubAssetFilter implements DamDAOFilter {

	private AssetFilter assetFilter;
	
	public NonSubAssetFilter() {
		this.assetFilter = new AssetFilter();
	}
	
	@Override
	public boolean matches(Resource resource) {
		return this.assetFilter.matches(resource) && !DamUtil.isSubAsset(resource);
	}

}
