package com.adidas.dam.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SLDConstants {

    public static enum ArtDocumentType {
        NEUTRAL("digital-image-neutral"),
        FORMAT_PAGE("format-page"),
        APPAREL_PRODUCTION("apparel-production-art"), 
        NOT_NEUTRAL("digital-image-not-neutral");

        public String code;

        ArtDocumentType(String c) {
            code = ("adidas-picklists:art-document-type/" + c).toLowerCase();
        }
    }
    
    /**
     * Logger instance for this class.
     */
    private static final Logger LOG = LoggerFactory.getLogger(SLDConstants.class);

    // AEM DAM path
    public final static String DAM_ROOT_PATH = "/content/dam";
    public final static String SLD_ROOT_PATH = DAM_ROOT_PATH + "/sld";

    // Asset MetaData
    public static final String DAM_ASSET = "dam:Asset";
    public static final String DAM_STATUS = "dam:status";
    public static final String DAM_PROJECT = "dam:project";
    public static final String DAM_TASK = "dam:task";
    public static final String DAM_PROOFING_GROUP = "dam:proofingGroup";
    public static final String DAM_PROOF_DATE = "dam:proofingDate";
    public static final String DAM_PROOF_BY_USER = "dam:proofingByUser";
    public static final String DAM_TAGS = "cq:tags";
    public static final String ASSET_JCR_METADATA = "jcr:content/metadata";
    public static final String ASSET_LASTMOD_DATE = "jcr:lastModified";
    public static final String ASSET_LASTMOD_BY = "jcr:lastModifiedBy";
    public static final String ASSET_CREATED_BY = "jcr:createdBy";
    public static final String DAM_STATUS_APPROVE = "approved";
    public static final String DAM_STATUS_REJECT = "rejected";
    public static final String STYLE_NUMBER = "styleNumber";
    public static final String COLOR_CODE = "colorCode";
    public static final String GRAPHIC_CODE = "graphicCode";
    public static final String FILE_NAME = "fileName";
    public static final String DC_TITLE = "dc:title";
    
    public static final String METADATA_CONFIDENTIAL = "jcr:content/metadata/"+SLDConstants.DI_CONFIDENTIAL;
    public static final String NOT_CONFIDENTIAL = "no";
    public static final String ASSET_DRM = "xmpRights:WebStatement";
    public static final String ASSET_DRM_PATH = "/etc/dam/drm/licenses/adidas-eula";
    public static final String ASSET_DRM_RESTRICT = "adobe_dam:restrictions";

    public static final String DUE_DATE = "priority.dueDate";
    public static final String PRIORITY = "priority";

    // Datasource
    private static final String ADI_DATASOURCE_PATH = "/apps/adidas-dam/datasource";
    public static final String ADI_PROOFING_GRPS = ADI_DATASOURCE_PATH + "/proofinggroups";
    public static final String ADI_PUB_LOCATIONS = DAM_ROOT_PATH + "/adidas";

    // AEM Project properties
    public static final String PROJ_PUB_LOCATION = "jcr:content/publocation";
    public static final String PROJ_PROOFING_GROUP = "jcr:content/proofer";
    public static final String PROJ_HOTFOLDER_PATH = "jcr:content/hotfolder";
    public static final String PROJ_TASK_PRIORITY = "jcr:content/taskPriority";

    // AEM Project Tasks
    public static final String TASK_ID = "taskId";
    public static final String TASK_SHOW_PROJ_LIB_URL = "/libs/cq/core/content/projects/showtasks.html?item=";
    public static final String TASK_PROJ_PATH = "project.path";

    // Digital Imagery properties
    public static final String DI_ROOT_PATH = SLD_ROOT_PATH + "/digital-imagery";
    public static final String ADI_HOTFOLDER_PATH = DAM_ROOT_PATH + "/hotfolders";
    public static final String ADI_DI_REVISION = "revisions";
    public static final String ADI_DI_REVISION_PATH = DI_ROOT_PATH + "/" + ADI_DI_REVISION;
    public static final String DI_PROPS_FOLDER = "diFolder";
    public static final String DI_WEEKLY = "annual";
    public static final String DI_NEUTRALS = "neutrals";
    public static final String DI_CONFIDENTIAL = "confidential";
    public static final String DI_WEEKLY_PATH = DI_ROOT_PATH + "/" + DI_WEEKLY;
    public static final String DI_NEUTRALS_PATH = DI_ROOT_PATH + "/" + DI_NEUTRALS;
    public static final String DI_CONFIDENTIAL_PATH = DI_ROOT_PATH + "/" + DI_CONFIDENTIAL;

    // Workflow properties
    public static final String WF_PROJ_PATH = "projectPath";
    public static final String WF_PROJ_ASSET_FOLDER = "projectAssetFolderPath";
    public static final String WF_MODEL = "modelId";

    // Sling Properties
    public static final String SLING_ORD_FOLDER = "sling:OrderedFolder";
    public static final String SLING_FOLDER = "sling:Folder";

    // User profile
    public static final String USER_LIGHTBOX_PATH = "/profile/lightbox/default";

    // AssetGroups
    public static final String VENDOR_PREFIX = "vendor-";
    public static final String CONTRACTOR_PREFIX = "contractor-";
    public static final String VENDOR_TAG = "vendor/";
    public static final String CONTRACTOR_TAG = "contractor/";

    // Adidas Groups
    public static final String ADIDAS_GRP_INTERNAL = "adidas_sld_users";
    public static final String ADIDAS_GRP_CONFIDENTIAL = "adidas_confidential_users";
    public static final String ADIDAS_GRP_ADMINS = "adidas_sld_admins";
    public static final String ADIDAS_GRP_VENDORS = "sld_vendors_contractors";
    public static final String ADIDAS_GRP_EXTERNAL = "adidas_external_users";
    public static final String ADIDAS_GRP_AUTHORS = "adidas_content_creators";

    // Adidas Tags
    public static final String TAGS_EVERYONE = "everyone";
    public static final String TAGS_ADIDAS_EVERYONE = "adidas:" + TAGS_EVERYONE;

    public static final String ACTIVE = "active";
    public static final String BRAND = "brand";
    public static final String CAT_MKT_LINE = "categoryMarketingLine";
    public static final String CORP_MKT_LINE = "corporateMarketingLine";
    public static final String GENDER = "gender";
    public static final String MFG_PROCESS = "mfgProcess";
    public static final String MFG_SUB_PROCESS = "mfgSubProcess";
    public static final String ARTICLE_NUMBER = "articleNumber";
    public static final String STYLE_NAME = "styleName";
    public static final String STYLE_STATUS = "styleStatus";
    public static final String GRAPHIC_NAME = "graphicName";
    public static final String GRAPHIC_SERIES = "graphicSeries";
    public static final String GRAPHIC_SIZE = "graphicSize";
    public static final String TEAM = "team";
    public static final String PLAYER_NAME = "playerName";
    public static final String PLAYER_NUMBER = "playerNumber";
    public static final String PRODUCT_GROUP = "productGroup";
    public static final String PRODUCT_TYPE = "productType";
    public static final String FAM_COLOR_CODE = "familyColorCode";
    public static final String PRINT_AREA_COLOR_CODE = "printAreaColorCode";
    public static final String ACCNT_EXCLUSIVITY = "accountExclusivity";
    public static final String POSE = "pose";
    public static final String LEAGUE = "league";
    public static final String ART_DOCUMENT_TYPE = "dam:artDocumentType";
    public static final String ART_DOC_EDITOR = "dam:artDocumentEditor";
    public static final String ART_DOC_EDITOR_DEPT = "dam:artDocumentEditorDepartment";
    public static final String ART_DOC_EDITOR_LOC = "dam:artDocumentEditorLocation";
    public static final String ART_HOLD_REASON = "artHoldReason";
    public static final String AVAIL_TO_SHIP = "availableToShip";
    public static final String DESCRIPTION = "dc:description";
    public static final String FABRIC_CONTENT = "fabricContent";
    public static final String ORDER_DEADLINE = "orderDeadline";
    public static final String VENDOR = "vendor";
    public static final String PICKLIST_TAG_SPACE = "adidas-picklists:";
    public static final String PICKLIST_TAG_PATH = "/etc/tags/adidas-picklists";
    public static final String ADIDAS_TAG_SPACE = "adidas:";
    public static final String ADIDAS_TAG_PATH = "/etc/tags/adidas";
    public static final String TAG_POSE_PATH = PICKLIST_TAG_PATH + "/pose";
}
