package com.adidas.dam.dao.filter;

import org.apache.sling.api.resource.Resource;

public interface DamDAOFilter {
	public boolean matches(Resource resource);
}
