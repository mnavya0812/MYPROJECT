package com.adidas.dam.servlets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adidas.dam.services.AssetUpdateNotificationService;
import com.adidas.dam.util.PublisherHttpClientFactory;

@SlingServlet(paths = "/bin/assetLogs", methods = "GET", metatype = true)
public class AssetAuditReportServlet extends SlingSafeMethodsServlet {

	private static final Logger log = LoggerFactory.getLogger(AssetAuditReportServlet.class);
	private static final long serialVersionUID = -6916524087964987290L;

	private PublisherHttpClientFactory clientFactory;

	@Reference
	private ResourceResolverFactory resourceResolverfactory;

	@Reference
	AssetUpdateNotificationService assetUpdateNotificationService;

	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {

		try {
			ResourceResolver resourceResolver = request.getResourceResolver();
			String[] publisherUrls = assetUpdateNotificationService.getPublisherUrls();
			String publisherCredentials = assetUpdateNotificationService.getPublisherCredentials();

			String assetItem = (request.getParameter("assets") != null) ? request.getParameter("assets") : "/content/dam/sld/digital-imagery/annual/2015/52/504PA_LAL_UPR7LAL_LPL_MF.psd";
			Resource resource = resourceResolver.getResource(assetItem);

			if (resource == null) {
				return;
			}

			String stats = getAssetStats(publisherUrls, publisherCredentials, resource.getPath());

			response.setContentType("text/csv");
			response.setHeader("Content-Disposition", "attachment; filename=" + resource.getName() + ".csv");

			PrintWriter out = response.getWriter();
			out.println(getInfo(stats, resource.getName()));

		} catch (Exception e) {
			log.debug("Err in assetlog servlet {}", e.getMessage(), e);
		}

	}

	/**
	 * *
	 * Get download stats from publish server(s) using asset audit node ( DAM
	 * Event Recorder )
	 *
	 * @param publisherUrls
	 * @param assetpath
	 * @return
	 */
	private String getAssetStats(String[] publisherUrls, String publisherCredentials, String assetpath) {

		JSONArray jsonArray = new JSONArray();
		ArrayList<String> users = new ArrayList<String>(); //todo: filter out users
		StringBuilder sb2 = new StringBuilder();

		for (String publisher : publisherUrls) {

			CloseableHttpClient httpClient = clientFactory.getPublisherHttpClient(publisher, publisherCredentials);

			String getURL = publisher + "/bin/downloadLogs?asset=" + assetpath;
			log.debug("GET " + getURL);
			HttpGet httpGet = new HttpGet(getURL.replace(" ", "%20"));

			CloseableHttpResponse response = null;

			try {
				response = httpClient.execute(httpGet);

				if (response.getStatusLine().getStatusCode() == HttpServletResponse.SC_OK) {

					InputStream responseStream = response.getEntity().getContent();
					BufferedReader br = new BufferedReader(new InputStreamReader(responseStream));

					String responseString = "";
					String line = "";

					while ((line = br.readLine()) != null) {
						responseString += line;
					}

					JSONObject responseObject = new JSONObject(responseString);
					jsonArray.put(responseObject);
					JSONArray downloads = responseObject.getJSONArray("downloads");

					for (int i = 0; i < downloads.length(); i++) {

						JSONObject download = downloads.getJSONObject(i);
						String email = (download.has("email")) ? download.getString("email") : "N/a";
						String user = (download.has("cq:userid")) ? download.getString("cq:userid") : "";
						String downloadTime = (download.has("cq:time")) ? download.getString("cq:time") : "";
						String eventType = (download.has("cq:type")) ? download.getString("cq:type") : "";

						sb2.append(user + ",");
						sb2.append(email + ",");
						sb2.append(downloadTime + ",");
						sb2.append(eventType + "\r\n");

					}

					return sb2.toString();

				} else {
					log.error("Could not get JSON from publisher. " + response.getStatusLine().getStatusCode() + " " + response.getStatusLine().getReasonPhrase());
				}
			} catch (IOException e) {
				log.error("Cannot obtain download logs from " + getURL + ". " + e.getMessage(), e);
			} catch (JSONException e) {
				log.error("Cannot parse JSON Object. " + e.getMessage(), e);
			}
		}

		return jsonArray.toString();
	}

	/**
	 * *
	 * Format data for response
	 *
	 * @param data
	 * @param assetTitle
	 * @return
	 */
	private String getInfo(String data, String assetTitle) {

		StringBuilder sb = new StringBuilder();
		/*  	
    	sb.append("<head>																				");
    	sb.append("<link rel=\"stylesheet\" type=\"text/css\" href=\"/etc/designs/sld/ui.widgets.css\">	");
		 */
		sb.append("User,			");
		sb.append("Email,			");
		sb.append("Downloaded,		");
		sb.append("Event-Type	\r\n");
		sb.append(data);

		return sb.toString();
	}

	@Activate
	protected void activate(Map<String, Object> properties)
	{
		clientFactory = new PublisherHttpClientFactory();
	}

}
