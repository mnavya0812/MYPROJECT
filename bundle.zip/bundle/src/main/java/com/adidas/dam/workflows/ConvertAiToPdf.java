package com.adidas.dam.workflows;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.framework.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adidas.dam.util.Helper;
import com.day.cq.dam.api.Asset;
import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.exec.WorkflowProcess;
import com.day.cq.workflow.metadata.MetaDataMap;


@Component
@Service
@Properties({
    @Property(name = Constants.SERVICE_DESCRIPTION, value = "Adidas Convert AI to PDF", propertyPrivate=false),
    @Property(name = Constants.SERVICE_VENDOR, value = "3|SHARE"),
    @Property(name = "process.label", value = "Adidas Convert AI to PDF", propertyPrivate=false ) })
public class ConvertAiToPdf implements WorkflowProcess {

	private static final Logger log	= LoggerFactory.getLogger(ConvertAiToPdf.class);
	private ResourceResolver resolver = null;
	
	@Reference
	ResourceResolverFactory resourceResolverFactory;

	@Override
	public void execute(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap metaDataMap) throws WorkflowException {
		
		try {
	    	resolver = resourceResolverFactory.getAdministrativeResourceResolver(null);	    	
	        Resource payloadResource = Helper.getResourceFromPayload(workItem, workflowSession.getSession(), resolver);
	        
	        if ( payloadResource!=null ) {	        	
	        	Asset asset = payloadResource.adaptTo(Asset.class);

	        	if ( asset.getMimeType().equals("application/postscript") ) {
	        		String renditionName = asset.getName().substring(0, asset.getName().indexOf('.'));
	        		asset.addRendition(renditionName + ".pdf", asset.getOriginal().getStream(), "pdf");
	        	}
	        }
		} catch (Exception ex) {
			log.error("error in convert ai to pdf");
		}	
	}
}
