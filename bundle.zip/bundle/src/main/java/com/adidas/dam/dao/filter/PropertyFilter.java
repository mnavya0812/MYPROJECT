package com.adidas.dam.dao.filter;

import java.util.Map;

import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;

import org.apache.sling.api.resource.Resource;

public class PropertyFilter implements DamDAOFilter {

	private Map<String, String> propertyMap;
	
	//This is an AND filter and will return true if the node matches ALL of the specified property values
	public PropertyFilter(Map<String, String> propertyMap) {
		this.propertyMap = propertyMap;
	}
	
	@Override
	public boolean matches(Resource resource) {
		try {
			boolean matches = true;
			
			Node node = resource.adaptTo(Node.class);
			
			for (String key : propertyMap.keySet()) {
				matches = checkProperty(node, key, propertyMap.get(key));
				if (matches == false) {
					break;
				}
			}
			
			return matches;
		} catch (Exception e) {
			throw new FilterException(e);
		}		
	}
	
	private boolean checkProperty(Node node, String key, String value) throws PathNotFoundException, RepositoryException {
		if (key.startsWith("@")) {
			String subNodeName = key.substring(1, key.indexOf("/"));
			String propertyName = key.substring(key.indexOf("/") + 1);
			if (node.hasNode(subNodeName)) {
				Node subNode = node.getNode(subNodeName);
				return checkProperty(subNode, propertyName, value);
			} else {
				return false;
			}
		}
		else if (node.hasProperty(key)) {
			if (!node.getProperty(key).getString().equals(value)) {
				return false;
			}
		}
		else {
			return false;
		}
		
		return true;
	}

}
