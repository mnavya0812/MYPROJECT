package com.adidas.dam.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.ValueFormatException;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;

@Component(immediate = true)
@Service
public class DownloadLogServlet extends SlingSafeMethodsServlet {

	private static final long serialVersionUID = -3411777675713306320L;
	private static final Logger log = LoggerFactory.getLogger(DownloadLogServlet.class);

	@Property(value="/bin/downloadLogs")
	static final String SERVLET_PATH="sling.servlet.paths";

	@Reference
	private QueryBuilder queryBuilder;
	
	@Reference
	private ResourceResolverFactory resolverFactory;

	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		ResourceResolver resolver = null;

		try {
			/*
			 * This should be modified to use request.getResourceResolver().  
			 * Endpoints that are calling this will need to be updated to authenticate before making this request.
			 * Leaving this as-is for now to minimize the impact of this change.
			 */
			resolver = resolverFactory.getAdministrativeResourceResolver(null);
			String assetPath = request.getParameter("asset");
			SearchResult results = findAssetActivity(resolver, assetPath);
			JSONObject json = buildJSONResult(assetPath, results);
			outputResponse(response, json);
		} catch (Exception e) {
			log.error("An error occured in processing.", e);
			throw new IOException(e);
		} finally {
			if (resolver.isLive()) {
				resolver.close();
			}
		}
	}

	private SearchResult findAssetActivity(ResourceResolver resolver, String assetPath) {
		Map<String, String> queryParams = new HashMap<String, String>();

		queryParams.put("path", "/home/users");
		queryParams.put("1_property", "object/type");
		queryParams.put("1_property.value", "asset");
		queryParams.put("2_property", "object/link");
		queryParams.put("2_property.value", assetPath);
		queryParams.put("3_group.p.or", "true");
		queryParams.put("3_group.1_property", "verb");
		queryParams.put("3_group.1_property.value", "DOWNLOADED");
		queryParams.put("3_group.2_property", "verb");
		queryParams.put("3_group.2_property.value", "RENDITION_DOWNLOADED");

		com.day.cq.search.Query query = queryBuilder.createQuery(PredicateGroup.create(queryParams), resolver.adaptTo(Session.class));

		SearchResult results = query.getResult();
		return results;
	}

	private JSONObject buildJSONResult(String assetPath, SearchResult results) throws JSONException {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("assetPath", assetPath);

		JSONArray downloads = extractDownloads(assetPath, results);
		jsonObject.put("downloads", downloads);

		return jsonObject;
	}

	private JSONArray extractDownloads(String assetPath, SearchResult results) {
		JSONArray downloads = new JSONArray();

		for (Hit hit : results.getHits()) {
			try {
				Node activityNode = hit.getNode();
				JSONObject nodeObject = extractValues(assetPath, activityNode);
				downloads.put(nodeObject);
			} catch (Exception e) {
				log.error("An error occurred while extracting values from the search results.", e);
			}

		}

		return downloads;
	}

	private JSONObject extractValues(String assetPath, Node activityNode) throws JSONException, ValueFormatException, PathNotFoundException, RepositoryException {
		JSONObject nodeObj = new JSONObject();

		nodeObj.put("jcr:primaryType", "cq:AuditEvent");
		nodeObj.put("cq:category", "com/day/cq/dam");
		nodeObj.put("cq:path", assetPath);

		String date = activityNode.getProperty("jcr:created").getString();
		nodeObj.put("cq:time", date);

		String eventType = activityNode.getProperty("verb").getString();
		nodeObj.put("cq:type", eventType);

		Node userNode = activityNode.getParent().getParent().getParent().getParent().getParent().getParent();
		String userName = userNode.getProperty("rep:authorizableId").getString();
		nodeObj.put("cq:userid", userName);

		if (userNode.hasNode("profile") && userNode.getNode("profile").hasProperty("email")) {
			Node profileNode = userNode.getNode("profile");
			String userEmail = profileNode.getProperty("email").getString();
			nodeObj.put("email", userEmail);
		}

		return nodeObj;
	}
	
	private void outputResponse(SlingHttpServletResponse response, JSONObject json) throws IOException {
		response.setContentType("application/json");
		PrintWriter out = response.getWriter();
		out.println(json.toString());
	}

}
