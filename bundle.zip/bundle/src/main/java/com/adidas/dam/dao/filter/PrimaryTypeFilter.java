package com.adidas.dam.dao.filter;

import java.util.List;

import javax.jcr.Node;

import org.apache.jackrabbit.JcrConstants;
import org.apache.sling.api.resource.Resource;

public class PrimaryTypeFilter implements DamDAOFilter {

	private List<String> primaryTypes;
	
	//This is an OR filter and will return true if the node matches ANY of the provided node types
	public PrimaryTypeFilter(List<String> primaryTypes) {
		this.primaryTypes = primaryTypes;
	}
	
	@Override
	public boolean matches(Resource resource) {
		try {
			boolean matches = false;
			
			Node node = resource.adaptTo(Node.class);
			
			if (node.hasProperty(JcrConstants.JCR_PRIMARYTYPE)) {
				String primaryType = node.getProperty(JcrConstants.JCR_PRIMARYTYPE).getString();
				
				for (String currType:primaryTypes) {
					if (currType.equals(primaryType)) {
						matches = true;
						break;
					}
				}
			}
			
			return matches;
		} catch (Exception e) {
			throw new FilterException(e);
		}		
	}

}
