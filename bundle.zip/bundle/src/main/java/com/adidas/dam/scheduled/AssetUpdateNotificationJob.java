package com.adidas.dam.scheduled;

import java.util.Arrays;
import java.util.List;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adidas.dam.services.AssetUpdateNotificationService;

@Component(immediate=true, metatype=true)
@Service(value=Runnable.class)
@Properties({
	@Property(name="scheduler.expression", value="0 30 0 * * ? *", description="crontab expression for job scheduling.")
})
public class AssetUpdateNotificationJob implements Runnable {

    @Reference
    AssetUpdateNotificationService assetUpdateNotificationService;

    private static final Logger log = LoggerFactory.getLogger(AssetUpdateNotificationJob.class);

    @Override
    public void run() {
        String[] runModes = System.getProperty("sling.run.modes").split(",");
        List<String> runModesList = Arrays.asList(runModes);
        if (!runModesList.contains("author") || runModesList.contains("offload")) {
            log.info("Runs on primary author only");
            return; //Not author, so exit
        }
        log.info("Running asset notification service.");
        assetUpdateNotificationService.notifyUsers();
    }
}
