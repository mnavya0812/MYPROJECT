package com.adidas.dam.util;

import java.net.URI;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.ValueFactory;
import javax.jcr.ValueFormatException;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;

import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.jackrabbit.api.JackrabbitSession;
import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.jackrabbit.api.security.user.Group;
import org.apache.jackrabbit.api.security.user.UserManager;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adidas.dam.dao.ProjectAssetsDAO;
import com.adidas.dam.models.ProjectTaskNotificationData;
import com.adobe.cq.projects.api.Project;
import com.adobe.granite.taskmanagement.Task;
import com.adobe.granite.taskmanagement.TaskManager;
import com.adobe.granite.taskmanagement.TaskManagerException;
import com.day.cq.commons.date.DateUtil;
import com.day.cq.commons.jcr.JcrUtil;
import com.day.cq.dam.api.Asset;
import com.day.cq.dam.commons.util.DamUtil;
import com.day.cq.workflow.exec.WorkItem;

public class Helper {

	/**
	 * Logger instance for this class.
	 */
	private static final Logger LOG = LoggerFactory.getLogger(Helper.class);

	//DAOs used to walk the tree to find resources
	private static ProjectAssetsDAO projectAssetsDao = new ProjectAssetsDAO();

	/**
	 * Helper method to determine if the type of a resource is
	 * sling:OrderedFolder
	 *
	 * @param resource the <code>Resource</code> object
	 * @return true only if the resource's type is sling:OrderedFolder, false
	 * otherwise
	 */
	public static boolean isFolder(Resource resource) {
		boolean isResourceFolder = false;
		if (resource != null) {
			isResourceFolder = "sling:OrderedFolder".equals(resource.getResourceType());
		}
		return isResourceFolder;
	}

	/**
	 * Method to help get all child resource folders
	 *
	 * @param resolver
	 * @param resourcePath
	 * @return list of folders (path,name)
	 */
	public static Map<String, String> getResources(ResourceResolver resolver, String resourcePath) {

		Map<String, String> mapResources = new LinkedHashMap<String, String>();
		Resource containingFolder = resolver.getResource(resourcePath);
		Iterator<Resource> resourceIterator = containingFolder.listChildren();

		while (resourceIterator.hasNext()) {
			Resource assetResource = resourceIterator.next();
			if (Helper.isFolder(assetResource)) {
				mapResources.put(assetResource.getPath(), assetResource.getName());
			}
		}

		return mapResources;
	}

	/**
	 * Attempt to resolve a <code>Resource</code> from the workflow payload
	 *
	 * @param workItem the <code>WorkItem</code> payload of the workflow
	 * @param session the current workflow <code>Session</code>
	 * @return a <code>Resource</code> object that represents a DAM
	 * <code>Asset</code> or DAM folder
	 */
	public static Resource getResourceFromPayload(WorkItem workItem, Session session, ResourceResolver resourceResolver) {
		Resource payloadResource = null;
		try {
			//TODO: In both cases, we are resolving to a Resource.  Why not just get the payload path as a resource directly?
			// attempt to resolve a DAM Asset from the payload
			Asset damAsset = Helper.getAssetFromPayload(workItem, session, resourceResolver);
			if (damAsset != null) {
				payloadResource = damAsset.adaptTo(Resource.class);
			} else {
				// fallback to using the node from payload, since we may have a folder there
				Node nodeResource = getNodeFromPayload(workItem, session);
				payloadResource = resourceResolver.getResource(nodeResource.getPath());
			}
		} catch (Exception e) {
			LOG.error("Could not get the resource from the payload!", e);
		}
		return payloadResource;
	}

	/**
	 * *
	 *
	 * @param item
	 * @param session
	 * @param resourceResolver
	 * @return
	 */
	public static Asset getAssetFromPayload(final WorkItem item, final Session session, ResourceResolver resourceResolver) {

		Asset asset = null;

		if (item.getWorkflowData().getPayloadType().equals("JCR_PATH")) {
			final String path = item.getWorkflowData().getPayload().toString();
			Resource resource = null;
			try {
				resource = resourceResolver.getResource(path);//getResourceResolver(session).getResource(path);
			} catch (Exception e) {
				LOG.error(e.getMessage(), e);
			}
			if (null != resource) {
				asset = DamUtil.resolveToAsset(resource);
			} else {
				LOG.error("getAssetFromPaylod: asset [{}] in payload of workflow [{}] does not exist.", path,
						item.getWorkflow().getId());
			}
		}
		return asset;
	}

	/**
	 * Retrieve the {@link Node} contained in a {@link WorkItem}'s payload, as
	 * indicated by the payload JCR path string. If the node cannot be found,
	 * <code>null</code> is returned.
	 *
	 * @param item The workflow item from which to get the payload.
	 * @param session The JCR {@link Session} to access the repository with.
	 * @return The node given by the workflow payload, or <code>null</code> if
	 * not found.
	 */
	public static Node getNodeFromPayload(WorkItem item, Session session) {
		Node asset = null;
		if (item.getWorkflowData().getPayloadType().equals("JCR_PATH")) {
			String path = item.getWorkflowData().getPayload().toString();

			try {
				if (session.itemExists(path)) {
					asset = (Node) session.getItem(path);
				} else {
					LOG.warn("getNodeFromPayload: payload node [{}] for work "
							+ "item [" + item.getId() + "] does not exist anymore", path);
				}
			} catch (RepositoryException e) {
				LOG.error(
						"getNodeFromPayload: error while getting payload node [{}] "
								+ "for work item [" + item.getId() + "]: ", path, e);
			}
		}
		return asset;
	}

	/**
	 * *
	 * Gets Projects selected Asset published location
	 *
	 * @param projectResource
	 * @return path to published location
	 */
	public static String getPublishedLocation(Resource projectResource) {
		Project project = projectResource.adaptTo(Project.class);
		ValueMap map = project.adaptTo(ValueMap.class);

		String publocation = (String) map.get(SLDConstants.PROJ_PUB_LOCATION);

		return publocation;

	}

	/**
	 * *
	 * Gets Projects selected Proofing group to review/approve/reject Assets
	 *
	 * @param projectResource
	 * @return path to proofing group
	 */
	public static String getProoferGroup(Resource projectResource) {
		Project project = projectResource.adaptTo(Project.class);
		ValueMap map = project.adaptTo(ValueMap.class);

		String proofer_group = (String) map.get(SLDConstants.PROJ_PROOFING_GROUP);

		return proofer_group;

	}

	/**
	 * *
	 * Gets Projects selected Proofing group to review/approve/reject Assets
	 *
	 * @param resolver
	 * @param projectPath
	 * @return path to proofing group
	 */
	public static String getProoferGroup(ResourceResolver resolver, String projectPath) {
		Resource projectResource = resolver.getResource(projectPath);
		Project project = projectResource.adaptTo(Project.class);
		ValueMap map = project.adaptTo(ValueMap.class);

		String proofer_group = (String) map.get(SLDConstants.PROJ_PROOFING_GROUP);

		return proofer_group;

	}

	/**
	 * *
	 * Gets Projects hotfolder path
	 *
	 * @param resolver
	 * @param projectPath
	 * @return path to hotfolder
	 */
	public static String getHotFolderPath(ResourceResolver resolver, String projectPath) {
		Resource projectResource = resolver.getResource(projectPath);
		Project project = projectResource.adaptTo(Project.class);
		ValueMap map = project.adaptTo(ValueMap.class);

		return (String) map.get(SLDConstants.PROJ_HOTFOLDER_PATH);
	}

	/**
	 * *
	 * Gets Projects Asset Folder
	 *
	 * @param resolver
	 * @param projectPath
	 * @return path to Asset Folder
	 */
	public static String getProjectAssetFolder(ResourceResolver resolver, String projectPath) {
		Resource projectResource = resolver.getResource(projectPath);
		Project project = projectResource.adaptTo(Project.class);

		return project.getAssetFolder().getPath();
	}

	/**
	 * *
	 * Gets the
	 *
	 * @param resolver
	 * @param projectPath
	 * @param projectProp
	 * @return
	 */
	public static String getProjectProps(ResourceResolver resolver, String projectPath, String projectProp) {
		Resource projectResource = resolver.getResource(projectPath);
		Project project = projectResource.adaptTo(Project.class);
		ValueMap map = project.adaptTo(ValueMap.class);

		try {
			return (String) map.get(projectProp);
		} catch (Exception ex) {
			return "";
		}
	}

	/**
	 * *
	 * Retrieve Assets for a specific path; used for retrieving all assets from
	 * hotfolders
	 *
	 * @param resolver
	 * @param projectPath
	 * @return
	 * @throws RepositoryException
	 */
	public static Iterator<Resource> getProjectAssetsSelection4Proofing(ResourceResolver resolver, String projectPath) {

		String hf = Helper.getHotFolderPath(resolver, projectPath); // get hotfolderpath from project property

		// Added checks since project hotfolder property path undetermined 
		//TODO: Is this always null?
		if (null == hf) {
			hf = Helper.getProjectAssetFolder(resolver, projectPath); // else get hotfolderpath from project's dam
			if (null == hf) {
				hf = SLDConstants.ADI_HOTFOLDER_PATH; // otherwise default to default hotfolder path
			}
		}
		LOG.debug("Hot Folder: " + hf);

		List<Resource> filterList = projectAssetsDao.getProjectAssets(resolver, hf);

		return filterList.listIterator();
	}

	/**
	 * *
	 * Gets the week of the year for copying approves assets
	 *
	 * @param resolver
	 * @return path to published approved asset location
	 * @throws RepositoryException
	 */
	public static String getWeekofYearPath(ResourceResolver resolver) throws RepositoryException {
		SimpleDateFormat weekofYearFormat = new SimpleDateFormat("YYYY/ww"); // java 7 week of year
		Calendar nowTime = Calendar.getInstance();
		String WeekofYearFolder = weekofYearFormat.format(nowTime.getTime());
		String weekOfYearFolderPath = SLDConstants.DI_WEEKLY_PATH + "/" + WeekofYearFolder;

		LOG.debug("weekOfYearFolderPath=" + weekOfYearFolderPath);

		try {
			Resource resource = resolver.getResource(weekOfYearFolderPath);

			if (null == resource) {
				JcrUtil.createPath(weekOfYearFolderPath, SLDConstants.SLING_ORD_FOLDER, resolver.adaptTo(Session.class));
			} else {
				//LOG.debug("folder week already exist " + weekOfYearFolderPath );
			}

		} catch (Exception ex) {
			LOG.error(" error in getWeekofYearPath()" + ex.getMessage(), ex);
		}

		return weekOfYearFolderPath;
	}

	/**
	 * *
	 * Gets the week of the year for copying approves assets
	 *
	 * @param resolver
	 * @return path to published approved asset location
	 * @throws RepositoryException
	 */
	public static String getDiRevisionsPath(ResourceResolver resolver) throws RepositoryException {

		try {

			Resource resource = resolver.getResource(SLDConstants.ADI_DI_REVISION_PATH);

			if (null == resource) {
				JcrUtil.createPath(SLDConstants.ADI_DI_REVISION_PATH, SLDConstants.SLING_ORD_FOLDER, resolver.adaptTo(Session.class));
			} else {
				LOG.debug("folder week already exist " + SLDConstants.ADI_DI_REVISION_PATH);
			}

		} catch (Exception ex) {
			LOG.error("ERRR in detDiRevisionsPath", ex);
		}

		return SLDConstants.ADI_DI_REVISION_PATH;
	}

	/**
	 * *
	 * Gets the Digital Images path for 'Confidential' or 'Neutral' assets
	 *
	 * @param resolver
	 * @param diType value= confidential | neutrals from diFolder metatadata
	 * property
	 * @return path to di folder ie /content/dam/sld/di/confidential
	 */
	public static String getDiFolderPath(ResourceResolver resolver, String diType) {

		String diFolderPath = "";
		if (diType.equalsIgnoreCase(SLDConstants.DI_CONFIDENTIAL)) {
			diFolderPath = SLDConstants.DI_CONFIDENTIAL_PATH;
		} else if (diType.equalsIgnoreCase(SLDConstants.DI_NEUTRALS)) {
			diFolderPath = SLDConstants.DI_NEUTRALS_PATH;
		} else if (diType.equalsIgnoreCase(SLDConstants.ADI_DI_REVISION)) {
			diFolderPath = SLDConstants.ADI_DI_REVISION_PATH;
		}

		try {
			Resource resource = resolver.getResource(diFolderPath);

			if (null == resource) {
				JcrUtil.createPath(diFolderPath, SLDConstants.SLING_ORD_FOLDER, resolver.adaptTo(Session.class));
			}

		} catch (RepositoryException rex) {
			LOG.error("ERRR RepositoryException in getDiFolderPath {} " + rex.getMessage(), diFolderPath, rex);
		} catch (Exception ex) {
			LOG.error("ERRR Exception in getDiFolderPath {} " + ex.getMessage(), diFolderPath, ex);
		}

		return diFolderPath;
	}

	/**
	 * *
	 * Method to get Project Task notification url from the notification inbox
	 * url since ootb url links to the projects dam
	 *
	 * @param resolver
	 * @param sNotificationUrl =
	 * http://localhost:4502/libs/cq/workflow/content/inbox/list.loadPayloadUrl?taskId=/content/projects/20151105/sld_hold_pendingncaajerseysplayerspecifichotfolder/jcr:content/tasks/2015-11-05/proof_images_andannotate
	 * @return
	 */
	public static String getProjectTaskNotificationUrl(ResourceResolver resolver, String sNotificationUrl) {

		try {

			String projectPath = getProjectPathFromNotificationTaskUrl(resolver, sNotificationUrl);
			if (null != projectPath && "" != projectPath) {
				return SLDConstants.TASK_SHOW_PROJ_LIB_URL + projectPath;
			} else {
				return sNotificationUrl;
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			LOG.error("getProjectTaskNotificationUrl->" + e.getMessage(), e);
		}

		return "";

	}

	/**
	 * *
	 * Method to get the Project priority from the notification inbox payload
	 * url
	 *
	 * @param resolver
	 * @param sNotificationUrl
	 * @return
	 */
	public static String getProjectPriority(ResourceResolver resolver, String sNotificationUrl) {
		try {
			String projectPath = getProjectPathFromNotificationTaskUrl(resolver, sNotificationUrl);

			if (null != projectPath && "" != projectPath) {
				Resource projectResource = resolver.getResource(projectPath);
				ValueMap map = projectResource.adaptTo(ValueMap.class);

				return (String) map.get(SLDConstants.PROJ_TASK_PRIORITY);
			}
		} catch (Exception ex) {
			LOG.error("getProjectPriority-->" + ex.getMessage(), ex);
		}

		return "";
	}

	/**
	 * *
	 *
	 * @param resolver
	 * @param sNotificationUrl
	 * @return
	 */
	public static ProjectTaskNotificationData getProjectTaskNotifications(ResourceResolver resolver, String sNotificationUrl) {

		try {
			// Task info
			String taskId = getTaskIdFromUrl(sNotificationUrl);
			TaskManager taskManager = (TaskManager) resolver.adaptTo(TaskManager.class);
			Task task = taskManager.getTask(taskId);
			String projectPath = (String) task.getProperty(SLDConstants.TASK_PROJ_PATH);

			// Project info
			Project project = resolver.getResource(projectPath).adaptTo(Project.class);
			Resource projectAssetFolder = project.getAssetFolder();
			List<Resource> projectAssets = projectAssetsDao.getPendingAssets(resolver, projectAssetFolder.getPath());

			ProjectTaskNotificationData ptnd = new ProjectTaskNotificationData();

			ptnd.setTitle(project.getTitle()); // project info
			ptnd.setAssetCount(projectAssets.size());  // project dam info
			ptnd.setAssignee(task.getCurrentAssignee());		// task info
			ptnd.setPriority(task.getProperty("taskPriority").toString());
			ptnd.setPriorityDueDate(task.getProperty("taskDueDate").toString());

			//get additional info from Asset data
			setProjectTaskNotificationData(ptnd, projectAssets, task);

			return ptnd;

		} catch (TaskManagerException e) {
			LOG.warn("Notification inbox item is not a task type" + e.getMessage(), e);
		}
		return null;
	}

	/**
	 * *
	 * Get earliest priority asset metadata to attach to notification inbox
	 *
	 * @param resolver
	 * @param projectAssetFolder
	 * @return just first record since its sort ascending
	 */
	private static void setProjectTaskNotificationData(ProjectTaskNotificationData ptnd, List<Resource> projectAssets, Task task) {

		try {
			if (projectAssets.size() > 0) {
				Map<String, Object> currMetadata = projectAssets.get(0).adaptTo(Asset.class).getMetadata();
				
				if (currMetadata.containsKey(SLDConstants.LEAGUE)) {
					String league = currMetadata.get(SLDConstants.LEAGUE).toString();
					int indx = league.lastIndexOf("/");
					league = league.substring(indx + 1).toUpperCase();
					ptnd.setLeague(league);
				}
				
				if (currMetadata.containsKey(SLDConstants.ASSET_CREATED_BY)) {
					String artist = currMetadata.get(SLDConstants.ASSET_CREATED_BY).toString();
					ptnd.setArtist(artist);
				}
				
			}
		} catch (Exception e) {
			LOG.error("getProjectAssetInfo ERROR " + e.getMessage(), e);
		}
	}

	/**
	 * *
	 * Method to get Project Path from taskId; in addition, set the priority due
	 * date since we have reference to the task
	 *
	 * @param resolver
	 * @param sNotificationUrl
	 * @return
	 */
	private static String getProjectPathFromNotificationTaskUrl(ResourceResolver resolver, String sNotificationUrl) {

		try {

			String taskId = getTaskIdFromUrl(sNotificationUrl);

			if (null != taskId && "" != taskId) {
				TaskManager taskManager = (TaskManager) resolver.adaptTo(TaskManager.class);

				Task task = taskManager.getTask(taskId);

				if (null != task) {
					return (String) task.getProperty(SLDConstants.TASK_PROJ_PATH);
				}
			}

		} catch (TaskManagerException e) {
			LOG.error("Err getProjectPathFromNotificationTaskUrl-->" + e.getMessage(), e);
		}

		return "";
	}

	/**
	 * *
	 * Find Assets by AssetGroup tags ** not used, switched to
	 * getTagsByUserMemberOf()
	 *
	 * @param resolver
	 * @return
	 */
	public static Iterator<Resource> getAssetsByAssetGroupTags(ResourceResolver resolver, String userID) {

		List<Resource> filterList = new ArrayList<Resource>();
		Set<Group> AssetGroups = User.getUserGroups(resolver, userID);

		//LOG.debug(  "AssetGroups.toString() -->" + AssetGroups.toString() );
		StringBuilder assetGroupsBuilder = new StringBuilder();

		// Append all groups to sql 2 query
		for (Group group : AssetGroups) {

			assetGroupsBuilder.append(" OR [jcr:content/metadata/cq:tags] LIKE 'adidas:");

			try {
				assetGroupsBuilder.append(group.getID());
			} catch (Exception ex) {
				LOG.error("ERROR in assetGroupsBuilder.append( );", ex);
			}

			assetGroupsBuilder.append("' ");
		}

		// Create SQL 2 to get all assets based on wildcard tags
		String sqlStatement = "SELECT * FROM [dam:Asset] WHERE ISDESCENDANTNODE([" + SLDConstants.DI_ROOT_PATH + "]) "
				+ " AND "
				+ " ( "
				+ "[jcr:content/metadata/cq:tags] LIKE $tags "
				+ assetGroupsBuilder.toString()
				+ " ) "
				+ " AND [jcr:path] NOT LIKE $cover";

		try {

			Session session = resolver.adaptTo(Session.class);
			ValueFactory vf = session.getValueFactory();

			QueryManager queryManager = session.getWorkspace().getQueryManager();
			javax.jcr.query.Query query = queryManager.createQuery(sqlStatement, javax.jcr.query.Query.JCR_SQL2);
			query.bindValue("tags", vf.createValue("%/dummy_tag_void")); /// this is used so that subsequent clause can be appended with OR, otherwise remove OR clause from first 4 characters of StringBuilder
			query.bindValue("cover", vf.createValue("%cover"));

			QueryResult result = query.execute();

			NodeIterator it = result.getNodes();

			while (it.hasNext()) {
				Node node = it.nextNode();
				Resource rs = resolver.getResource(node.getPath());
				LOG.debug("#### found tag asset -->" + rs.getPath());
				filterList.add(rs);
			}

		} catch (javax.jcr.UnsupportedRepositoryOperationException urex) {
			LOG.error("ERROR   " + urex.getMessage(), urex);
		} catch (RepositoryException rex) {
			LOG.error("ERROR   " + rex.getMessage(), rex);
		} catch (Exception e) {
			LOG.error("ERROR  " + e.getMessage(), e);
		}

		LOG.debug("filterList.size()-->" + filterList.size());
		return filterList.iterator();

	}

	/**
	 * *
	 * Method to create tags from groups users are memberOf
	 *
	 * @param resolver
	 * @param AssetGroups
	 * @return queryBuilder hidden property tags to render as filter in
	 * assetshare page
	 * @throws Exception
	 */
	public static Iterator<String> getTagsByUserMemberOf(ResourceResolver resolver, Set<Group> AssetGroups) throws Exception {

		List<String> tagList = new ArrayList<String>();

		// Build Query filters
		tagList.add("qb.addHidden(\"type\", \"" + SLDConstants.DAM_ASSET + "\");");
		tagList.add("qb.addHidden(\"path\", \"" + SLDConstants.SLD_ROOT_PATH + "\");");

		// Add additional filters for non-admins, otherwise return all for an administrator
		if (!User.isMemberOfGroup(resolver, "administrators")) {

			// non vendor accounts
			if (!User.isMemberOfGroup(resolver, SLDConstants.ADIDAS_GRP_VENDORS)) {

				tagList.add("qb.addHidden(\"group.p.or\", \"false\");");
				tagList.add("qb.addHidden(\"group.1_property\", \"jcr:content/metadata/cq:tags\");");
				tagList.add("qb.addHidden(\"group.1_property.value\", \"adidas:everyone\");");
			} else {
				// vendors/contractors/factories
				int tagCounter = 1 ;
				tagList.add("qb.addHidden(\"group.p.or\", \"false\");");
				tagList.add("qb.addHidden(\"group.1_property\", \"jcr:content/metadata/cq:tags\");");
				for (Group group : AssetGroups) {
					if (group.getID().startsWith(SLDConstants.VENDOR_PREFIX)
							|| group.getID().startsWith(SLDConstants.CONTRACTOR_PREFIX)) {

						String groupTagID = group.getID();
						if (group.getID().startsWith(SLDConstants.VENDOR_PREFIX)) {
							groupTagID = group.getID().replace(SLDConstants.VENDOR_PREFIX, SLDConstants.VENDOR_TAG);
						} else if (group.getID().startsWith(SLDConstants.CONTRACTOR_PREFIX)) {
							groupTagID = group.getID().replace(SLDConstants.CONTRACTOR_PREFIX, SLDConstants.CONTRACTOR_TAG);
						}

						tagList.add("qb.addHidden(\"group.1_property."+tagCounter+"_value\", \"adidas:" + groupTagID + "\");");
						tagCounter++;
					}
					
					
				}
			}

			// confidential, check for asset metadata with confidential property
			if (!User.isMemberOfGroup(resolver, SLDConstants.ADIDAS_GRP_CONFIDENTIAL)) {
				tagList.add("qb.addHidden(\"group.2_property\", \"jcr:content/metadata/confidential\");");
				tagList.add("qb.addHidden(\"group.2_property.value\", \"no\");");
			}

		} else { // administrators
			tagList.add("qb.addHidden(\"property\", \"jcr:content/metadata/cq:tags\");");
		}

		tagList.add("qb.addHidden(\"p.limit\", \"-1\");");

		return tagList.iterator();
	}

	/**
	 * *
	 * Creates user profile path for lightbox
	 *
	 * @param adminSession
	 * @param authUser
	 * @return
	 */
	public static boolean setLightbox(Session adminSession, Authorizable authUser) {
		try {
			String path = authUser.getPath() + SLDConstants.USER_LIGHTBOX_PATH;

			if (adminSession.itemExists(path)) {
				return false;
			}

			String userId = authUser.getID();
			UserManager userMgr = ((JackrabbitSession) adminSession).getUserManager();
			Authorizable auth = userMgr.getAuthorizable(userId);
			org.apache.jackrabbit.api.security.user.User user;

			if (!auth.isGroup()) {
				user = (org.apache.jackrabbit.api.security.user.User) auth;
			} else {
				user = null;
			}

			if (user != null) {

				if (!adminSession.itemExists(path)) {
					String[] pathSplits = path.split("/");
					String pathToCheck = "";
					Node rootNode = adminSession.getRootNode();

					for (String pathSplit : pathSplits) {
						if (pathToCheck.endsWith("/")) {
							pathToCheck = pathToCheck + pathSplit;
						} else {
							pathToCheck = pathToCheck + "/" + pathSplit;
						}
						if (!adminSession.itemExists(pathToCheck)) {
							rootNode.addNode(pathToCheck.substring(1), SLDConstants.SLING_FOLDER);
						}
					}
					if (!adminSession.itemExists(path + "/" + "completed")) {
						((Node) adminSession.getItem(path)).addNode("completed", SLDConstants.SLING_FOLDER);
					}
				}

				adminSession.save();
				return true;
			}
		} catch (RepositoryException re) {
			LOG.error("Repository exception ", re);
		}

		return false;
	}

	/**
	 * *
	 *
	 * @param somedate
	 * @return
	 */
	public static String dateSLDFormat(String somedate) {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date date = sdf.parse(somedate);
			return "" + DateUtil.getISO8601DateNoTime(date);
		} catch (Exception ex) {
			LOG.error("dateFormat error", ex);
		}
		return "";
	}

	/**
	 * *
	 * Gets taskId= value from notification url
	 *
	 * @param url
	 * @return
	 */
	private static String getTaskIdFromUrl(String url) {

		try {
			List<NameValuePair> params = URLEncodedUtils.parse(new URI(url), "UTF-8");

			for (NameValuePair param : params) {
				if (SLDConstants.TASK_ID.equals(param.getName())) {
					return param.getValue();
				}
			}
		} catch (URISyntaxException e) {
			LOG.error("getTaskIdFromUrl=" + e.getMessage(), e);
		}

		return "";
	}

	/**
	 * *
	 * Checks if asset metadata node has any confidential properties
	 *
	 * @param resource
	 * @return true | false
	 */
	public static boolean isAssetConfidential(Resource resource) {
		try {
			boolean isConfidential = false;
			Node metadataNode = resource.adaptTo(Node.class).getNode(SLDConstants.ASSET_JCR_METADATA);
			if (metadataNode.hasProperty(SLDConstants.DI_PROPS_FOLDER)) {
				isConfidential = metadataNode.getProperty(SLDConstants.DI_PROPS_FOLDER).getString().equalsIgnoreCase(SLDConstants.DI_CONFIDENTIAL);
			}
			if (metadataNode.hasProperty(SLDConstants.DI_CONFIDENTIAL)) {
				isConfidential = (metadataNode.getProperty(SLDConstants.DI_CONFIDENTIAL).getString().equalsIgnoreCase("yes")) ? true : isConfidential;
			}

			return isConfidential;

		} catch (ValueFormatException e) {
			LOG.error(e.getMessage(), e);
		} catch (PathNotFoundException e) {
			LOG.error(e.getMessage(), e);
		} catch (RepositoryException e) {
			LOG.error(e.getMessage(), e);
		}

		return false;
	}

	/**
	 * Retreives Style, Team, Graphic, Color, and Pose metadata from the file
	 * name
	 *
	 * @param assetName
	 * @param resolver
	 * @return a Map of the metadata. If the file does not follow the format, an
	 * empty map is returned
	 */
	public static HashMap<String, Object> getMetadataFromFileName(String assetName, ResourceResolver resolver) {

		LOG.debug("Parsing " + assetName);
		HashMap<String, Object> metadataMap = new HashMap<String, Object>();
		int extIndex = assetName.indexOf(".");
		ArrayList<String> fileNameMetadata = null;
		if (extIndex > 0) {
			fileNameMetadata = new ArrayList<String>(Arrays.asList(assetName.substring(0, extIndex).split("_")));
		} else {
			fileNameMetadata = new ArrayList<String>(Arrays.asList(assetName.split("_")));
		}
		if (fileNameMetadata.size() >= 5) {
			try {
				String styleNumber = fileNameMetadata.get(0);
				String team = fileNameMetadata.get(1);
				String graphicCode = fileNameMetadata.get(2);
				String colorCode = fileNameMetadata.get(3);
				String pose = fileNameMetadata.get(4);
				pose = TagUtil.ensureTagExists(SLDConstants.TAG_POSE_PATH, pose, resolver);
				LOG.debug(styleNumber + " | " + team + " | " + graphicCode + " | " + colorCode + " | " + pose);

				metadataMap.put(SLDConstants.STYLE_NUMBER, styleNumber.toUpperCase());
				metadataMap.put(SLDConstants.TEAM, team);
				metadataMap.put(SLDConstants.GRAPHIC_CODE, graphicCode.toUpperCase());
				metadataMap.put(SLDConstants.COLOR_CODE, colorCode.toUpperCase());
				metadataMap.put(SLDConstants.POSE, pose);
				metadataMap.put(SLDConstants.FILE_NAME, assetName.toUpperCase());
			} catch (Exception e) {
				LOG.error("Problem getting metadata from filename: " + e.getClass() + ": " + e.getMessage(), e);
			}
		}
		return metadataMap;
	}
	
	
	public static HashMap<String, Object> cleanMetadataForNonDi(HashMap<String, Object> metadataMap) {
		HashMap<String, Object> metadataMapCleaned = metadataMap;
		LOG.debug("Cleaning Metadata Map for Non Di Assets ");
		metadataMapCleaned.put(SLDConstants.STYLE_NUMBER, "");
		metadataMapCleaned.put(SLDConstants.TEAM, "");
		metadataMapCleaned.put(SLDConstants.GRAPHIC_CODE, "");
		metadataMapCleaned.put(SLDConstants.COLOR_CODE, "");
		metadataMapCleaned.put(SLDConstants.POSE, "");
		
		return metadataMapCleaned;
	}
	public static void updateNodeProperties(Node assetNode, HashMap<String, Object> metadataMap) throws RepositoryException {
		for (Map.Entry<String, Object> entry : metadataMap.entrySet()) {
			String key = entry.getKey();
			Object value = entry.getValue();
			LOG.debug(key + ": " + value);
			if (value instanceof String[]) {
				assetNode.setProperty(key, (String[]) value);
			} else if (value instanceof Calendar) {
				assetNode.setProperty(key, (Calendar) value);
			} else if (value instanceof Integer) {
				assetNode.setProperty(key, (Integer) value);
			} else if (value instanceof Boolean) {
				assetNode.setProperty(key, (Boolean) value);
			} else {
				assetNode.setProperty(key, (String) value);
			}
		}
	}
}
