package com.adidas.dam.models;

import java.util.Arrays;
import java.util.HashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by bear on 11/10/15.
 */
public class SAMMSData {

    private static final String DELIMITER = "\\|";
    private String styleNumber;
    private String colorCode;
    private String graphicNumber;
    private static final Logger log = LoggerFactory.getLogger(SAMMSData.class);

    private HashMap<String, String> dataMap = new HashMap<String, String>();

    public SAMMSData(String[] headers, String dataString) {

        int styleIndex = Arrays.asList(headers).indexOf("StyleCode");
        int colorIndex = Arrays.asList(headers).indexOf("ColorCode");
        int graphicIndex = Arrays.asList(headers).indexOf("GraphicCode");

        String[] dataValues = dataString.split(DELIMITER, -1);
        this.styleNumber = dataValues[styleIndex].toUpperCase();
        this.colorCode = dataValues[colorIndex].toUpperCase();
        this.graphicNumber = dataValues[graphicIndex].toUpperCase();

        for (int i = 0; i < dataValues.length; i++) {
            dataMap.put(headers[i], dataValues[i]);
        }
    }

    public HashMap<String, String> getDataMap() {
        return dataMap;
    }

    public String getStyleNumber() {
        return styleNumber;
    }

    public String getColorCode() {
        return colorCode;
    }

    public String getGraphicNumber() {
        return graphicNumber;
    }
}
