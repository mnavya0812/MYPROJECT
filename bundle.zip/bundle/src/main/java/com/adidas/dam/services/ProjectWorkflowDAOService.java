package com.adidas.dam.services;

import java.util.List;

import javax.jcr.RepositoryException;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;

import com.adobe.cq.projects.api.Project;

public interface ProjectWorkflowDAOService {
	public List<Resource> getActiveTasks(ResourceResolver resourceResolver, String projectPath);
	public int getActiveTaskCount(ResourceResolver resourceResolver, String projectPath);
	public void startProofingWorkflow(ResourceResolver resolver, Project hotFolderProject, String userName, String userPassword, String priority) throws RepositoryException;
}
