package com.adidas.dam.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Service;
import org.apache.http.NameValuePair;
import org.apache.http.StatusLine;
import org.apache.http.message.BasicNameValuePair;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adidas.dam.dao.async.AsyncCompletionCheck;
import com.adidas.dam.dao.async.AsyncException;
import com.adidas.dam.dao.async.AsyncWaitManager;
import com.adidas.dam.dao.filter.DamDAOFilter;
import com.adidas.dam.dao.filter.PrimaryTypeFilter;
import com.adidas.dam.dao.filter.PropertyFilter;
import com.adidas.dam.dao.jcr.NodeRetriever;
import com.adidas.dam.hotFolder.HotFolderConfiguration;
import com.adidas.dam.services.ProjectDAOService;
import com.adidas.dam.util.AEMHttp;

@Component(immediate = true, metatype = true)
@Service(value=ProjectDAOService.class)
public class ProjectDAOServiceImpl implements ProjectDAOService {

	private final Logger LOG = LoggerFactory.getLogger(ProjectDAOService.class);
	
	private AsyncWaitManager asyncWaitManager;
	
    @Activate
    protected void activate(final Map<String, Object> config) {
    	asyncWaitManager = new AsyncWaitManager();
    }

    //Searches for a project with the specified hotfolderPath set to jcr:content/hotFolderPath
	public Resource getHotfolderProject(ResourceResolver resourceResolver, String hotfolderPath) {
		try {
			List<DamDAOFilter> filters = new ArrayList<DamDAOFilter>();

			List<String> primaryTypes = Arrays.asList("nt:unstructured");
			filters.add(new PrimaryTypeFilter(primaryTypes));		

			Map<String, String> propertyMap = new HashMap<String, String>();
			propertyMap.put("sling:resourceType", "cq/gui/components/projects/admin/card/projectcard");
			propertyMap.put("@jcr:content/hotFolderPath", hotfolderPath);
			propertyMap.put("@jcr:content/isHotFolderProject", "true");
			filters.add(new PropertyFilter(propertyMap));

			NodeRetriever retriever = new NodeRetriever(resourceResolver, filters);
			List<Resource> projects = retriever.getResourcesDeep("/content/projects");

			if (projects.size() > 0) {
				return projects.get(0);
			} else {
				return null;
			}
		} catch (Exception e) {
			LOG.warn("Unable to find a project for " + hotfolderPath, e);
			return null;
		}
	}
	
    public void createHotFolderProject(ResourceResolver resourceResolver, HotFolderConfiguration config, String userName, String userPassword) {    	
        
    	String hotfolderPath = config.getPath();
    	AsyncCompletionCheck completionCheck = new ProjectCompletionCheck(resourceResolver, hotfolderPath, this);
    	
    	if (asyncWaitManager.hasItem(hotfolderPath)) {
    		LOG.debug("Already received a request to create a project for " + hotfolderPath + ".  Waiting...");
    		asyncWaitManager.waitForCompletion(completionCheck, 60);
    	} else {
    		LOG.debug("Creating a project for " + hotfolderPath);
    		asyncWaitManager.addItem(hotfolderPath);
    		
            ArrayList<NameValuePair> parameters = new ArrayList<NameValuePair>();
            String hotFolderName = config.getName();
            String diFolder = config.getDiFolderType();
            String priority = config.getPriority();
            String proofingGroup = config.getProofingGroup();

            parameters.add(new BasicNameValuePair("template", "/apps/adidas-dam/templates/digital-images-project"));
            parameters.add(new BasicNameValuePair("wizard", ""));
            parameters.add(new BasicNameValuePair("wizard@Delete", ""));
            parameters.add(new BasicNameValuePair("_charset_", "UTF-8"));
            parameters.add(new BasicNameValuePair(":operation", "projectcreate"));
            parameters.add(new BasicNameValuePair("jcr:title", hotFolderName));
            parameters.add(new BasicNameValuePair("proofer", proofingGroup));
            parameters.add(new BasicNameValuePair("jcr:description", "Hot Folder Proofing for " + hotFolderName));
            parameters.add(new BasicNameValuePair("taskPriority", (priority.equals("high") ? "High" : "Medium")));
            parameters.add(new BasicNameValuePair("project.dueDate", ""));
            parameters.add(new BasicNameValuePair("project.dueDate@TypeHint", "Date"));
            parameters.add(new BasicNameValuePair("assignee", "null"));
            parameters.add(new BasicNameValuePair("teamMemberUserId", "admin"));
            parameters.add(new BasicNameValuePair("teamMemberRoleId", "owner"));
            parameters.add(new BasicNameValuePair("teamMemberUserId", config.getProofingGroup()));
            parameters.add(new BasicNameValuePair("teamMemberRoleId", "proofers"));
            parameters.add(new BasicNameValuePair("teamMemberUserId", "adidas_sld_admins"));
            parameters.add(new BasicNameValuePair("teamMemberRoleId", "fileadmins"));
            parameters.add(new BasicNameValuePair("name", hotFolderName.toLowerCase().replace(" ", "_") + "_hot_folder"));
            parameters.add(new BasicNameValuePair(":http-equiv-accept", "application/json,*/*;q=0.9"));
            parameters.add(new BasicNameValuePair("diFolder", diFolder));
            parameters.add(new BasicNameValuePair("hotFolderPath", hotfolderPath));
            parameters.add(new BasicNameValuePair("isHotFolderProject", "true"));
            parameters.add(new BasicNameValuePair("isHotFolderProject@TypeHint", "Boolean"));

            StatusLine status = AEMHttp.sendHttpPost("http://localhost:4502/content/projects", parameters, userName, userPassword);
            
            if (status.getStatusCode() == 201) {
            	asyncWaitManager.waitForCompletion(completionCheck, 60);
                asyncWaitManager.removeItem(hotfolderPath);
            } else {
            	asyncWaitManager.removeItem(hotfolderPath);
            	throw new AsyncException("http://localhost:4502/content/projects", status);
            }
    	}
    }
}

class ProjectCompletionCheck implements AsyncCompletionCheck {

	private String hotfolderPath;
	private ResourceResolver resourceResolver;
	private ProjectDAOService projectDaoService;
	
	public ProjectCompletionCheck(ResourceResolver resourceResolver, String hotfolderPath, ProjectDAOService projectDaoService) {
		this.hotfolderPath = hotfolderPath;
		this.resourceResolver = resourceResolver;
		this.projectDaoService = projectDaoService;
	}
	
	@Override
	public String getPath() {
		return hotfolderPath;
	}
	
	@Override
	public String getWaitMessage() {
		return "Waiting for " + hotfolderPath + "'s project to be created.";
	}

	@Override
	public boolean isComplete() {
		Resource project = projectDaoService.getHotfolderProject(resourceResolver, hotfolderPath);
		return project != null;
	}

	@Override
	public String getCompleteMessage() {
		return hotfolderPath + "'s project created.";
	}
	
}