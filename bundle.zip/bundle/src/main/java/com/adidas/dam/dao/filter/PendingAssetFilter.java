package com.adidas.dam.dao.filter;

import java.util.Map;

import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.ValueFormatException;

import org.apache.sling.api.resource.Resource;

import com.adidas.dam.util.SLDConstants;
import com.day.cq.dam.api.Asset;

public class PendingAssetFilter implements DamDAOFilter {

	private AssetFilter assetFilter;
	
	public PendingAssetFilter() {
		this.assetFilter = new AssetFilter();
	}
	
	public boolean matches(Resource resource) {
		try {
			return (assetFilter.matches(resource) && !isRejected(resource));
		} catch (Exception e) {
			throw new FilterException(e);
		}	
	}
	
	private boolean isRejected(Resource resource) throws RepositoryException, PathNotFoundException, ValueFormatException {
		Asset asset = resource.adaptTo(Asset.class);
		Map<String,Object> metadataMap = asset.getMetadata();
		
		return (null != metadataMap.get("dam:status") && metadataMap.get("dam:status").toString().equals(SLDConstants.DAM_STATUS_REJECT));
	}
}
