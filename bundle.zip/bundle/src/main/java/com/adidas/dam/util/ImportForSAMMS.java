package com.adidas.dam.util;

import com.adidas.dam.models.SAMMSData;
import com.day.cq.commons.jcr.JcrUtil;
import java.io.*;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import javax.jcr.*;
import javax.jcr.lock.LockException;
import javax.jcr.nodetype.ConstraintViolationException;
import javax.jcr.version.VersionException;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ImportForSAMMS {

    private static final String DELIMITER = "\\|";
    private static final Logger log = LoggerFactory.getLogger(ImportForSAMMS.class);
    private final ResourceResolver resolver;
    private final String importFilePath;
    private final String dataNodePath;

    private String[] headers;
    private int styleIndex;
    private int colorIndex;
    private int graphicIndex;
    private int totalUpdatesNodes = 0;

    public ImportForSAMMS(ResourceResolver resolver, String importFilePath, String importStorePath){
        this.resolver = resolver;
        this.importFilePath = importFilePath;
        this.dataNodePath = importStorePath;

    }

    private enum Headers{
        StyleCode,
        ColorCode,
        GraphicCode,
        ActiveFlag,
        Brand,
        CatMktgLine,
        CorpMktgLine,
        Gender,
        ManProcess,
        ManSubProcess,
        ArticleNumber,
        StyleName,
        StyleStatus,
        GraphicSeries,
        GraphicName,
        GraphicSizeCode,
        Team,
        PlayerName,
        PlayerNumber,
        FamilyColorCode,
        PrintAreaColorCode,
        AccountExclusivity
    }

    public Collection<SAMMSData> runImport() {
        Set<SAMMSData> importData = new HashSet<SAMMSData>();
        log.info("Running import from " + importFilePath);
        File importFile = new File(importFilePath);
        try {
            BufferedReader importReader = new BufferedReader( new FileReader(importFile));

            String headerLine = importReader.readLine(); // read first line for headers
            log.debug("Header line: " + headerLine);
            this.headers = headerLine.split(DELIMITER,-1);
            for (int i=0;i<headers.length;i++) {
                log.debug("Header " + i + ": " + headers[i]);
            }
            styleIndex = Arrays.asList(headers).indexOf("StyleCode");
            colorIndex = Arrays.asList(headers).indexOf("ColorCode");
            graphicIndex = Arrays.asList(headers).indexOf("GraphicCode");
            log.debug("Indexes: style(" + styleIndex + "), color(" + colorIndex + "), graphic(" + graphicIndex + ")");
            if (styleIndex < 0 || colorIndex < 0 || graphicIndex < 0) {
                log.error("All or some key values are not present (style/color/graphic). Cannot import. Header line:"+headerLine);
                return Collections.EMPTY_SET;
            }

            String dataLine;
            while( (dataLine = importReader.readLine()) != null ) {
                try {
                    SAMMSData data = new SAMMSData(headers,dataLine);
                    saveData(data);
                    importData.add(data);
                } catch (RepositoryException e) {
                    log.error("Unable to save data. " + e.getMessage());
                }
            }

            log.info("Imported a total of " + importData.size() + " entries");
            Node dataNode = resolver.getResource(dataNodePath).adaptTo(Node.class);
            dataNode.setProperty("lastSAMMSImport", Calendar.getInstance());
        } catch (FileNotFoundException e) {
            log.error("No file found. " + e.getMessage(), e);
        } catch (IOException e) {
            log.error("Unable to read file. " + e.getMessage(), e);
        } catch (ValueFormatException e) {
            log.error("Unable to set property. " + e.getMessage(), e);
        } catch (VersionException e) {
            log.error("Unable to set property. " + e.getMessage(), e);
        } catch (ConstraintViolationException e) {
            log.error("Unable to set property. " + e.getMessage(), e);
        } catch (LockException e) {
            log.error("Unable to set property. " + e.getMessage(), e);
        } catch (RepositoryException e) {
            log.error("Unable to set property. " + e.getMessage(), e);
        } finally {
            return importData;
        }
    }

    private void saveData(SAMMSData sammsData) throws RepositoryException {
        String dataNodePath =  this.dataNodePath + "/" + sammsData.getStyleNumber() + "/" + sammsData.getColorCode() + "/" + sammsData.getGraphicNumber();
        Session session = resolver.adaptTo(Session.class);
        Node dataNode = JcrUtil.createPath(dataNodePath,"nt:unstructured",session);
        log.info("Storing data to " + dataNodePath);
        for (Map.Entry<String,String> dataEntry : sammsData.getDataMap().entrySet()){
            String nodeProperty = selectNodeProperty(dataEntry.getKey());
            String value = dataEntry.getValue();
            if (nodeProperty != null && !"".equals(value)) {
                String tagRootPath = null;
                if (nodeProperty.equals("active")) {
                    value = "false";
                } else if (nodeProperty.equals(SLDConstants.BRAND)) {
                    tagRootPath = SLDConstants.PICKLIST_TAG_PATH + "/brand";
                } else if (nodeProperty.equals(SLDConstants.CORP_MKT_LINE)) {
                    tagRootPath = SLDConstants.PICKLIST_TAG_PATH + "/corporate-marketing-line";
                } else if (nodeProperty.equals(SLDConstants.CAT_MKT_LINE)) {
                    tagRootPath = SLDConstants.PICKLIST_TAG_PATH + "/category-marketing-line";
                } else if (nodeProperty.equals(SLDConstants.GENDER)) {
                    tagRootPath = SLDConstants.PICKLIST_TAG_PATH + "/gender-age";
                } else if (nodeProperty.equals(SLDConstants.FAM_COLOR_CODE)) {
                    tagRootPath = SLDConstants.PICKLIST_TAG_PATH + "/family-color-code";
                }
                if (tagRootPath != null) {
                    value = TagUtil.findTagIDByTitle(tagRootPath, value, resolver, true);
                }

                dataNode.setProperty(nodeProperty, value);
            }
        }
        session.save();
    }


    /**
     * Selects the AEM node property that the SAMMS data column/header is mapped to
     * @param headerName header/column name from SAMMS data
     * @return name of AEM metadata property or null if the header is a key value or not a valid header
     */
    private String selectNodeProperty(String headerName) {
        Headers header = Headers.valueOf(headerName);
        switch (header) {
            case StyleCode:
            case ColorCode:
            case GraphicCode:
                // Key values are skipped
                return null;
            case ActiveFlag:
                return SLDConstants.ACTIVE;
            case Brand:
                return SLDConstants.BRAND;
            case CatMktgLine:
                return SLDConstants.CAT_MKT_LINE;
            case CorpMktgLine:
                return SLDConstants.CORP_MKT_LINE;
            case Gender:
                return SLDConstants.GENDER;
            case ManProcess:
                return SLDConstants.MFG_PROCESS;
            case ManSubProcess:
                return SLDConstants.MFG_SUB_PROCESS;
            case ArticleNumber:
                return SLDConstants.ARTICLE_NUMBER;
            case StyleName:
                return SLDConstants.STYLE_NAME;
            case StyleStatus:
                return SLDConstants.STYLE_STATUS;
            case GraphicSeries:
                return SLDConstants.GRAPHIC_SERIES;
            case GraphicName:
                return SLDConstants.GRAPHIC_NAME;
            case GraphicSizeCode:
                return SLDConstants.GRAPHIC_SIZE;
            case Team:
                return SLDConstants.TEAM;
            case PlayerName:
                return SLDConstants.PLAYER_NAME;
            case PlayerNumber:
                return SLDConstants.PLAYER_NUMBER;
            case FamilyColorCode:
                return SLDConstants.FAM_COLOR_CODE;
            case PrintAreaColorCode:
                return SLDConstants.PRINT_AREA_COLOR_CODE;
            case AccountExclusivity:
                return SLDConstants.ACCNT_EXCLUSIVITY;
            default:
                log.warn("Unknown header: " + header);
        }

        return null;
    }
}
