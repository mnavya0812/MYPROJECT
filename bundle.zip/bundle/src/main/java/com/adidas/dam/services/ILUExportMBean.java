package com.adidas.dam.services;
import com.adobe.granite.jmx.annotation.Description;
import com.adobe.granite.jmx.annotation.Name;
import java.util.Date;
 
/**
 * 
 * @author brobert
 */
@Description("Adidas ILU Export Activity")
public interface ILUExportMBean {
    @Description("Last reported status of ILU export")
    public String getLastStatus();

    @Description("Last reported error of ILU export")
    public String getLastError();
    
    @Description("Start date/time of last ILU export")
    public Date getStartTime();

    @Description("End date/time of last ILU export")
    public Date getEndTime();

    @Description("If true, export is currently running")
    public boolean isRunning();

    @Description("Export assets for year/week indicated in the year/week fields")
    public String exportAssets(@Name("Year") @Description("2014, 2015...") int year, @Name("Week") @Description("1-53") int week);
    
    @Description("Export assets from last week")
    public String exportLastWeeksAssets();
}
