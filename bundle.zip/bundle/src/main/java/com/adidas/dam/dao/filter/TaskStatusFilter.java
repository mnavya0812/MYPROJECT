package com.adidas.dam.dao.filter;

import javax.jcr.Node;

import org.apache.sling.api.resource.Resource;

public class TaskStatusFilter implements DamDAOFilter {

	private String status;
	
	public TaskStatusFilter(String status) {
		this.status = status;
	}
	
	@Override
	public boolean matches(Resource resource) {
		try {
			Node node = resource.adaptTo(Node.class);
			return (node.hasProperty("status") && node.getProperty("status").getString().equals(status));
		} catch (Exception e) {
			throw new FilterException(e);
		}
		
	}

}
