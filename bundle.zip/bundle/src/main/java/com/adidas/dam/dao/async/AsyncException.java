package com.adidas.dam.dao.async;

import org.apache.http.StatusLine;

public class AsyncException extends RuntimeException {

	private static final long serialVersionUID = 3537108591215609311L;

	public AsyncException(String url, StatusLine status) {
		super(getMessage(url, status));
	}

	private static String getMessage(String url, StatusLine status) {
		return "A " + status.getStatusCode() + " response was returned for " + url + ".";
	}
}
