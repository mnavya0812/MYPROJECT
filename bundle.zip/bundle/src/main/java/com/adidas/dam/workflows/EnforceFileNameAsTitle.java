package com.adidas.dam.workflows;

import com.adidas.dam.util.Helper;
import com.adidas.dam.util.SLDConstants;
import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.exec.WorkflowProcess;
import com.day.cq.workflow.metadata.MetaDataMap;
import java.util.Collections;
import javax.jcr.Node;
import javax.jcr.RepositoryException;
import org.apache.felix.scr.annotations.*;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.framework.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(metatype = true)
@Service
@Properties({
    @org.apache.felix.scr.annotations.Property(name = Constants.SERVICE_DESCRIPTION, value = "Ensures that dc:title and fileName metadata match actual asset file name"),
    @org.apache.felix.scr.annotations.Property(name = Constants.SERVICE_VENDOR, value = "3|Share"),
    @Property(name = "process.label", value = "Enforce File Name As Title")
})
public class EnforceFileNameAsTitle implements WorkflowProcess {

    private static final Logger log = LoggerFactory.getLogger(EnforceFileNameAsTitle.class);

    @Reference
    private ResourceResolverFactory resolverFactory;

    @Override
    public void execute(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap metaDataMap) throws WorkflowException {

        try {
            ResourceResolver resolver = resolverFactory.getResourceResolver(Collections.singletonMap("user.jcr.session", (Object) workflowSession.getSession()));
            Resource payloadResource = Helper.getResourceFromPayload(workItem, workflowSession.getSession(), resolver);
            Node payloadNode = payloadResource.adaptTo(Node.class);
            log.debug("payload: " + payloadNode.getPath());

            Node metadataNode = payloadNode.getNode("jcr:content/metadata");
            String fileName = payloadNode.getName();
            log.debug("filename: " + fileName);

            boolean updateTitle = true;
            if (metadataNode.hasProperty(SLDConstants.DC_TITLE) && metadataNode.hasNode(SLDConstants.FILE_NAME)) {
                String currentTitle = metadataNode.getProperty(SLDConstants.DC_TITLE).getString();
                String file = metadataNode.getProperty(SLDConstants.FILE_NAME).getString();
                log.debug("currentTitle: " + currentTitle);
                if (!fileName.equals(currentTitle) || !fileName.toUpperCase().equals(file)) {
                    updateTitle = true;
                } else {
                    updateTitle = false;
                }
            }
            if (updateTitle) {
                metadataNode.setProperty(SLDConstants.FILE_NAME, fileName.toUpperCase());
                metadataNode.setProperty(SLDConstants.DC_TITLE, fileName);
                metadataNode.getSession().save();                
            }
        } catch (RepositoryException e) {
            log.error("Could not read from repository. " + e.getMessage());
        } catch (LoginException e) {
            log.error("Could not get session. " + e.getMessage());
        }

    }
}
