package com.adidas.dam.util;

import com.day.cq.commons.jcr.JcrUtil;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.*;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class ExportForSAMMS {

    private static final Logger log = LoggerFactory.getLogger(ExportForSAMMS.class);
    private static final String SAMMS_DATA_PATH = "/content/appdata/samms";
    private static final String LAST_EXPORT_PROP = "lastExport";


    public static void exportSAMMSData(String exportLocation, ResourceResolver resolver, boolean exportAll) {

        log.info("Starting export of requests SAMMS data.");

        ArrayList<String> exportLines = new ArrayList<String>();
        Session session = resolver.adaptTo(Session.class);

        Calendar lastSAMMSUpdate = getLastSAMMSUpdate(resolver);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:MM:ss.SSSZ"); //2010-01-01T00:00:00.000+02:00
        StringBuilder sql2Statement = new StringBuilder("");
        sql2Statement.append("SELECT * FROM [dam:Asset] WHERE ISDESCENDANTNODE([/content/dam]) ");
        if (!exportAll && lastSAMMSUpdate != null) {
            log.info("Last export: " + sdf.format(lastSAMMSUpdate.getTime()));
            sql2Statement.append("AND [jcr:content/jcr:lastModified] > $lastSAMMSDate ");
        } else {
            log.warn("Searching for ALL assets. ");
        }

        try {
            updateSAMMSDataNode(resolver);
        } catch (RepositoryException e) {
            log.error("Unable to update SAMMS data node. " + e.getMessage());
        }

        try {
            ValueFactory vf = session.getValueFactory();
            QueryManager queryManager = session.getWorkspace().getQueryManager();
            Query query = queryManager.createQuery(sql2Statement.toString(), Query.JCR_SQL2);
            if (!exportAll && lastSAMMSUpdate != null) {
                    query.bindValue("lastSAMMSDate",vf.createValue(lastSAMMSUpdate));
            }
            log.info("Query: " + query.getStatement());

            QueryResult result = query.execute();

            NodeIterator nodes = result.getNodes();

            int numResults = 0;

            while(nodes.hasNext()) {
                Node resultNode = nodes.nextNode();
                
                log.info("SAMMS Query results node path :" + resultNode.getPath());
                
                Node metadataNode = resultNode.getNode("jcr:content/metadata");

                if (metadataNode.hasProperty(SLDConstants.STYLE_NUMBER) &&
                        metadataNode.hasProperty(SLDConstants.COLOR_CODE) &&
                        metadataNode.hasProperty(SLDConstants.GRAPHIC_CODE)) {

                    String style = metadataNode.getProperty(SLDConstants.STYLE_NUMBER).getString();
                    String color = metadataNode.getProperty(SLDConstants.COLOR_CODE).getString();
                    String graphic = metadataNode.getProperty(SLDConstants.GRAPHIC_CODE).getString();

                    String line = style + "|" + color + "|" + graphic;

                    if (!exportLines.contains(line)) {
                        log.debug(resultNode.getPath() + " " + line);
                        exportLines.add(line);
                    }
                }

                numResults++;
            }
            log.info("Processed {} assets from query.", numResults);
            log.info("Exporting " + exportLines.size() + " lines of data to " + exportLocation);
            File exportFile = new File(exportLocation);
            if (!exportFile.exists()) {
                try {
                    if (!exportFile.createNewFile()) {
                        log.error("Unable to create file.");
                        return;
                    }
                } catch (IOException e) {
                    log.error("Unable to create file. " + e.getMessage());
                    return;
                }
            }
            PrintWriter out = new PrintWriter(exportLocation);

            for (String line : exportLines) {
                out.println(line);
            }

            out.flush();
            out.close();

        } catch (RepositoryException e) {
            log.error("Unable to get Query Manager. " + e.getMessage());
        } catch (FileNotFoundException e) {
            log.error("Cannot write to file. " + e.getMessage());
        }

    }

    private static void updateSAMMSDataNode(ResourceResolver resolver) throws RepositoryException {
        Resource sammsDataRes = resolver.getResource(SAMMS_DATA_PATH);
        Node sammsDataNode = sammsDataRes.adaptTo(Node.class);
        sammsDataNode.setProperty(LAST_EXPORT_PROP,Calendar.getInstance());
        resolver.adaptTo(Session.class).save();
    }

    private static Calendar getLastSAMMSUpdate(ResourceResolver resolver) {

        Resource sammsDataRes = resolver.getResource(SAMMS_DATA_PATH);
        if (sammsDataRes == null) {
            try {
                createSAMMSDataNode(resolver);
                resolver.refresh();
            } catch (RepositoryException e) {
                log.error("Unable to create " + SAMMS_DATA_PATH + " " +  e.getMessage());
            }
        }

        sammsDataRes = resolver.getResource(SAMMS_DATA_PATH);
        try {
            return sammsDataRes.adaptTo(Node.class).getProperty(LAST_EXPORT_PROP).getDate();
        } catch (RepositoryException e) {
            log.warn("No value for " + LAST_EXPORT_PROP);
            return null;
        }

    }

    private static void createSAMMSDataNode(ResourceResolver resolver) throws RepositoryException {
        JcrUtil.createPath("/content/appdata/samms","nt:unstructured",resolver.adaptTo(Session.class));

        resolver.adaptTo(Session.class).save();
    }


}
