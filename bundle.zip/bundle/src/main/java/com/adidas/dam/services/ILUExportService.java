package com.adidas.dam.services;

import com.adidas.dam.util.AEMHttp;
import com.adidas.dam.util.SLDConstants;
import com.adobe.granite.jmx.annotation.AnnotatedStandardMBean;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Dictionary;
import java.util.Scanner;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.management.NotCompliantMBeanException;
import org.apache.commons.io.FileUtils;
import org.apache.felix.scr.annotations.*;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(metatype = true, immediate = true, label = "Adidas Inventory LookUp Export Service")
@Service(ILUExportService.class)
@Properties({
    @Property(name = "jmx.objectname", value = "com.adidas:type=InventoryLookUp"),
    @Property(name = "export.location", label = "Export Location", unbounded = PropertyUnbounded.DEFAULT),
    @Property(name = "weekly.folder.location", label = "Weekly Folder Location", unbounded = PropertyUnbounded.DEFAULT),
    @Property(name = "dynamic.media.parameters", label = "Dynamic Media Parameters", unbounded = PropertyUnbounded.DEFAULT),
    @Property(name = "aem.user.name", label = "AEM User Name", description = "User name with read access to DI annual folder", unbounded = PropertyUnbounded.DEFAULT),
    @Property(name = "aem.user.password", label = "AEM User Password", unbounded = PropertyUnbounded.DEFAULT)

})
public class ILUExportService extends AnnotatedStandardMBean implements ILUExportMBean {
    
    private static final String DEFAULT_WEEKLY_FOLDER = "/content/dam/digital-imagery/annual";
    private static final String MISSING_COMPONENT_PLACEHOLDER = "";
    private String weeklyLocation;
    private String exportLocation;
    private String dynamicMediaParameters;
    
    private static final Logger LOG = LoggerFactory.getLogger(ILUExportService.class);
    private final SimpleDateFormat weekPathFormat = new SimpleDateFormat("/YYYY/ww");
    
    public ILUExportService() throws NotCompliantMBeanException {
        super(ILUExportMBean.class);
    }
    
    private Thread worker = null;
    private Date startTime = null;
    private Date endTime = null;
    private String lastStatus = "Not running";
    private String lastError = "";
    
    @Override
    public String getLastStatus() {
        return lastStatus;
    }
    
    @Override
    public String getLastError() {
        return lastError;
    }
    
    @Override
    public Date getStartTime() {
        return startTime;
    }
    
    @Override
    public Date getEndTime() {
        return endTime;
    }
    
    @Override
    public boolean isRunning() {
        return worker != null && worker.isAlive();
    }
    
    private static final String STYLE_METADATA = "jcr:content/metadata/" + SLDConstants.STYLE_NUMBER;
    private static final String COLOR_METADATA = "jcr:content/metadata/" + SLDConstants.COLOR_CODE;
    private static final String GRAPHIC_METADATA = "jcr:content/metadata/" + SLDConstants.GRAPHIC_CODE;
    
    @Reference
    ResourceResolverFactory resolverFactory;
    private String userName;
    private String userPswd;
    
    @Override
    public String exportLastWeeksAssets() {
        if (isRunning()) {
            return "Another export is already running";
        } else {
            Calendar lastWeek = Calendar.getInstance();
            lastWeek.add(Calendar.DATE, -7);
            exportAssetsForWeek(lastWeek.getTime());
            return "Export started for " + lastWeek;
        }
    }
    
    @Override
    public String exportAssets(int year, int week) {
        if (isRunning()) {
            return "Another export is already running";
        } else {
            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.YEAR, year);
            cal.set(Calendar.WEEK_OF_YEAR, week);
            exportAssetsForWeek(cal.getTime());
            return "Export started for " + year + "/" + week;
        }
    }
    
    private void exportAssetsForWeek(final Date week) {
        worker = new Thread(new Runnable() {
            @Override
            public void run() {
                lastError = "";
                lastStatus = "";
                startTime = new Date();
                endTime = null;
                _exportAssetsForWeek(week);
                endTime = new Date();
            }
        });
        worker.start();
    }
    
    private void _exportAssetsForWeek(Date week) {
        int completed = 0;
        int errors = 0;
        boolean aborted = false;
        if ("".equals(exportLocation)) {
            reportError("No export location configured. Cannot run export.");
            return;
        }
        ResourceResolver resolver = null;
        try {
            resolver = resolverFactory.getAdministrativeResourceResolver(null);
            
            String weekFolderPath = weeklyLocation + weekPathFormat.format(week);
            LOG.info("Exporting for " + weekFolderPath);
            String exportFolder = exportLocation + weekPathFormat.format(week);
            try {
                FileUtils.forceMkdir(new File(exportFolder));
            } catch (IOException e) {
                reportError("Cannot create export directory. " + e.getMessage());
                aborted = true;
                throw e;
            }
            Resource weekFolder = resolver.getResource(weekFolderPath);
            if (weekFolder == null) {
                reportError("Folder does not exist: " + weekFolderPath);
                aborted = true;
                throw new RepositoryException("Could not find folder " + weekFolderPath);
            }
            Node weekFolderNode = weekFolder.adaptTo(Node.class);
            NodeIterator assetNodes = weekFolderNode.getNodes();
            while (assetNodes.hasNext()) {
                try {
                    Node currentNode = assetNodes.nextNode();
                    if (currentNode.getPrimaryNodeType().isNodeType("dam:Asset") && currentNode.hasNode("jcr:content/metadata")) {
                        String assetPath = currentNode.getPath();
                        
                        String style = currentNode.hasProperty(STYLE_METADATA) ? currentNode.getProperty(STYLE_METADATA).getString() : MISSING_COMPONENT_PLACEHOLDER;
                        String color = currentNode.hasProperty(COLOR_METADATA) ? currentNode.getProperty(COLOR_METADATA).getString() : MISSING_COMPONENT_PLACEHOLDER;
                        String graphic = currentNode.hasProperty(GRAPHIC_METADATA) ? currentNode.getProperty(GRAPHIC_METADATA).getString() : MISSING_COMPONENT_PLACEHOLDER;
                        
                        String exportFileName = style + color + graphic + ".jpg";
                        String exportPath = exportLocation + weekPathFormat.format(week) + "/" + exportFileName;
                        LOG.debug("Exporting " + assetPath);
                        exportAsset(assetPath, exportPath);
                        completed++;
                    }
                } catch (Exception e) {
                    errors++;
                    reportError("Cannot export asset. " + e.getMessage(), e);
                }
                lastStatus = completed + " assets exported, " + errors + " errors reported in logs.";
            }
        } catch (LoginException e) {
            reportError("Cannot login. " + e.getMessage(), e);
            aborted = true;
        } catch (RepositoryException e) {
            reportError("Cannot get children. " + e.getMessage(), e);
            aborted = true;
        } catch (IOException ex) {
            reportError("IO Error: " + ex.getMessage(), ex);
            aborted = true;
        } finally {
            if (resolver != null && resolver.isLive()) {
                resolver.close();
            }
            if (!aborted) {
                lastStatus = "Export finished; " + completed + " assets exported, " + errors + " errors reported in logs.";
            }
        }
    }
    
    private void exportAsset(String assetPath, String assetExportPath) throws Exception {
        String aemHost = "http://localhost:4502";
        String assetURLPath = "/is/image" + assetPath + "?" + dynamicMediaParameters;
        File exportFile = new File(assetExportPath);
        int numDuplicateNames = 0;
        String workingExportPath;
        while (exportFile.exists()) {
            numDuplicateNames++;
            workingExportPath = assetExportPath.substring(0, assetExportPath.indexOf(".jpg")) + "_" + String.format("%02d", numDuplicateNames) + ".jpg";
            exportFile = new File(workingExportPath);
        }
        LOG.debug("Asset export path: " + exportFile.getPath());
        
        try {
            LOG.debug("Retrieving image from " + aemHost + assetURLPath);
            CloseableHttpResponse response = AEMHttp.sendHttpGet(aemHost, assetURLPath, userName, userPswd);
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode == 200) {
                exportFile.createNewFile();
                response.getEntity().writeTo(new FileOutputStream(exportFile));
            } else {
                String status = statusCode + ": " + response.getStatusLine().getReasonPhrase();
                Scanner s = new java.util.Scanner(response.getEntity().getContent()).useDelimiter("\\A");
                String fullError = s.hasNext() ? s.next() : "";
                response.close();
                throw new Exception("Unable to get formatted image. " + status + ";" + fullError);
            }
        } catch (IOException e) {
            reportError("Could not retrieve image. " + e.getMessage(), e);
            throw e;
        }
        
    }
    
    private void reportError(String error) {
        LOG.error(error);
        lastStatus = error;
        lastError = error;
    }
    
    private void reportError(String error, Throwable cause) {
        LOG.error(error, cause);
        lastStatus = error;
        lastError = error;
    }
    
    protected void activate(ComponentContext componentContext) {
        Dictionary<?, ?> properties = componentContext.getProperties();
        
        userName = PropertiesUtil.toString(properties.get("aem.user.name"), "admin");
        userPswd = PropertiesUtil.toString(properties.get("aem.user.password"), "admin");
        exportLocation = PropertiesUtil.toString(properties.get("export.location"), "");
        weeklyLocation = PropertiesUtil.toString(properties.get("weekly.folder.location"), DEFAULT_WEEKLY_FOLDER);
        dynamicMediaParameters = PropertiesUtil.toString(properties.get("dynamic.media.parameters"), "");
    }
}
