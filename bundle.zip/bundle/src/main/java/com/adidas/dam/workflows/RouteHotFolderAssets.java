package com.adidas.dam.workflows;

import java.util.Calendar;
import java.util.Collections;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.Value;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.PropertyUnbounded;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.osgi.framework.Constants;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adidas.dam.dao.ProjectAssetsDAO;
import com.adidas.dam.hotFolder.HotFolderConfiguration;
import com.adidas.dam.services.HotFolderConfigurationService;
import com.adidas.dam.services.ProjectDAOService;
import com.adidas.dam.services.ProjectWorkflowDAOService;
import com.adidas.dam.util.Helper;
import com.adidas.dam.util.SLDConstants;
import com.adobe.cq.projects.api.Project;
import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.AssetManager;
import com.day.cq.search.QueryBuilder;
import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.exec.WorkflowProcess;
import com.day.cq.workflow.metadata.MetaDataMap;

@Component(metatype = true)
@Service
@Properties({
	@Property(name = Constants.SERVICE_DESCRIPTION, value = "Process Adidas Hot Folders"),
	@Property(name = Constants.SERVICE_VENDOR, value = "3|Share"),
	@Property(name = "process.label", value = "Adidas Hot Folder Routing", propertyPrivate = true)
})
public class RouteHotFolderAssets implements WorkflowProcess {

	@Property(unbounded = PropertyUnbounded.DEFAULT, description = "Username used to create the projects", label = "User Name")
	public static final String USER_PROP = "user.name";

	@Property(unbounded = PropertyUnbounded.DEFAULT, description = "Password", label = "User Password")
	public static final String PASSWORD_PROP = "user.password";

	@Property(unbounded = PropertyUnbounded.ARRAY, description = "Root folder for all hotfolders. Example: /path/to/folder:proofer_group_id", label = "Hot Folder Mappings")
	public static final String HOTFOLDER_MAPPINGS_PROP = "hotfolder.root.path";

	private static final Logger log = LoggerFactory.getLogger(RouteHotFolderAssets.class);

	private ProjectAssetsDAO projectAssetsDao = new ProjectAssetsDAO();
	
	@Reference
	ResourceResolverFactory resourceResolverFactory;

	@Reference
	QueryBuilder queryBuilder;

	@Reference
	HotFolderConfigurationService hotFolderConfigurationService;

	@Reference
	ProjectDAOService projectDAOService;
	
	@Reference
	ProjectWorkflowDAOService projectWorkflowDAOService;

	private String userPassword;
	private String userName;

	public void execute(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap metaDataMap) throws WorkflowException {
		Session session = workflowSession.getSession();
		ResourceResolver resolver = null;

		try {
			resolver = resourceResolverFactory.getAdministrativeResourceResolver(null);

			// get the resource from the payload
			Resource payloadResource = Helper.getResourceFromPayload(workItem, session, resolver);

			if (payloadResource != null) {
				String payloadPath = payloadResource.getPath();
				String userId = payloadResource.getValueMap().get("jcr:createdBy", "admin");

				//Find the configuration for this hot folder. null if no matching configuration
				HotFolderConfiguration hotFolderConfiguration = hotFolderConfigurationService.findConfigurationForPath(payloadPath);

				if (hotFolderConfiguration == null) {
					log.warn("No hot folder configuration for " + payloadPath);
					return;
				}

				Resource projectResource = getOrCreateProject(resolver, hotFolderConfiguration);
				Project hotFolderProject = projectResource.adaptTo(Project.class);
				
				Asset destinationAsset = moveAssetToProject(resolver, payloadPath, hotFolderConfiguration.getPath(), hotFolderProject);
				
				applyMetadataToAsset(destinationAsset, hotFolderConfiguration, userId);
				
				if (projectWorkflowDAOService.getActiveTaskCount(resolver, projectResource.getPath()) < 1) {
					projectWorkflowDAOService.startProofingWorkflow(resolver, hotFolderProject, userName, userPassword, hotFolderConfiguration.getPriority());
				}
			}
		} catch (LoginException e) {
			log.error("Unable to get Admin session" + e.getMessage());
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		} finally {
			resolver.close();
		}
	}

	private Resource getOrCreateProject(ResourceResolver resolver, HotFolderConfiguration hotFolderConfiguration) {
		log.debug("Getting project for hot folder");
		String hotFolderPath = hotFolderConfiguration.getPath();
		
		Resource projectResource = projectDAOService.getHotfolderProject(resolver, hotFolderPath); //Looking for the hotFolderPath instead of the project path

		if (projectResource == null) {
			log.info("No project found for proofing group hot folder. Creating new Project.");
			projectDAOService.createHotFolderProject(resolver, hotFolderConfiguration, userName, userPassword);
			resolver.refresh();
			projectResource = projectDAOService.getHotfolderProject(resolver, hotFolderPath);
		}
		return projectResource;
	}
	
	private Asset moveAssetToProject(ResourceResolver resolver, String payloadPath, String hotFolderPath, Project hotFolderProject) throws Exception {
		AssetManager assetManager = resolver.adaptTo(AssetManager.class);
		String projectAssetFolder = hotFolderProject.getAssetFolder().getPath();

		String destinationPath = payloadPath.replace(hotFolderPath, projectAssetFolder);
		log.info("Moving " + payloadPath + " to " + destinationPath);
		String payloadVarPath = payloadPath.replace("/content/dam", "/var/dam");
		Asset payloadAsset = assetManager.getAssetForBinary(payloadVarPath);

		projectAssetsDao.createDeleteAsset(resolver, payloadAsset, destinationPath);
		Asset destinationAsset = resolver.resolve(destinationPath).adaptTo(Asset.class);
		return destinationAsset;
	}

	/**
	 * Applies metadata from a HotFolderConfiguration to an asset. Metadata is
	 * stored on the metadata node
	 *
	 * @param payloadAsset
	 * @param hotFolderConfiguration
	 * @param userID
	 */
	private void applyMetadataToAsset(Asset payloadAsset, HotFolderConfiguration hotFolderConfiguration, String userID) {
		log.debug("Applying metadata to " + payloadAsset.getPath());
		Node assetNode = payloadAsset.adaptTo(Node.class);

		try {
			ResourceResolver resolver = resourceResolverFactory.getResourceResolver(Collections.singletonMap("user.jcr.session", (Object) assetNode.getSession()));
			Node metadataNode = assetNode.getNode("jcr:content/metadata");

			//get metadata from filename
			String assetName = payloadAsset.getName();
			HashMap<String, Object> metadataMap = Helper.getMetadataFromFileName(assetName, resolver);

			if (metadataMap != null) {
				for (Map.Entry<String, Object> metadataEntry : metadataMap.entrySet()) {
					String key = metadataEntry.getKey();
					String value = (String) metadataEntry.getValue();
					log.debug("Property: " + key + " = " + value);
					metadataNode.setProperty(key, value);
				}
			} else {
				log.warn("Unable to parse style/team/color/graphic/pose metadata for " + assetName);
			}

			// basic metadata from configuration. These values should be stored in the config as tags already
			metadataNode.setProperty(SLDConstants.LEAGUE, hotFolderConfiguration.getLeague());
			metadataNode.setProperty(SLDConstants.BRAND, hotFolderConfiguration.getBrand());
			metadataNode.setProperty(SLDConstants.ART_DOCUMENT_TYPE, hotFolderConfiguration.getArtDocumentType());
			metadataNode.setProperty(SLDConstants.DI_PROPS_FOLDER, hotFolderConfiguration.getDiFolderType());

			//Clear proofing status
			metadataNode.setProperty(SLDConstants.DAM_STATUS, (Value) null);

			// Adding tags for non-admins
			metadataNode.setProperty("cq:tags", new String[]{"adidas:everyone"});

			// Add confidential metadata 
			if (hotFolderConfiguration.getDiFolderType().equalsIgnoreCase(SLDConstants.DI_CONFIDENTIAL)) {
				metadataNode.setProperty(SLDConstants.DI_CONFIDENTIAL, "yes");
			} else {
				metadataNode.setProperty(SLDConstants.DI_CONFIDENTIAL, "no");
			}

			// additional metadata from config
			HashMap<String, String> defaultMetadata = hotFolderConfiguration.getDefaultMetadata();
			for (Map.Entry<String, String> metadata : defaultMetadata.entrySet()) {
				metadataNode.setProperty(metadata.getKey(), metadata.getValue());
			}

			// set priority
			String priority = hotFolderConfiguration.getPriority();
			Calendar dueDate = Calendar.getInstance();
			if (priority.equals("high")) {
				dueDate.add(Calendar.HOUR, 24);
			} else {    // default to 'normal'
				dueDate.add(Calendar.HOUR, 48);
			}
			metadataNode.setProperty("priority", priority);
			metadataNode.setProperty("priority.dueDate", dueDate);

			log.debug("Setting art document editor as " + userID);
			metadataNode.setProperty(SLDConstants.ART_DOC_EDITOR, userID);

			assetNode.getSession().save();
		} catch (RepositoryException e) {
			log.error("Cannot apply metadata. " + e.getMessage(), e);
		} catch (LoginException e) {
			log.error("Could not get resource resolver. " + e.getMessage(), e);
		}

	}

	public void activate(final ComponentContext componentContext) {
		final Dictionary<?, ?> properties = componentContext.getProperties();
		userName = PropertiesUtil.toString(properties.get(USER_PROP), "admin");
		userPassword = PropertiesUtil.toString(properties.get(PASSWORD_PROP), "admin");

	}
}
