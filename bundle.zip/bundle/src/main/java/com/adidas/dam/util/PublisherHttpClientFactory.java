package com.adidas.dam.util;

import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

public class PublisherHttpClientFactory {
	
	public CloseableHttpClient getPublisherHttpClient(String publisher, String publisherCredentials) {
    	String pubHost = publisher.split(":")[1];
    	int pubPort = Integer.parseInt(publisher.split(":")[2]);
    	String pubUser = publisherCredentials.split(":")[0];
    	String pubPass = publisherCredentials.split(":")[1];
    	
        CredentialsProvider credsProvider = new BasicCredentialsProvider();
        credsProvider.setCredentials(new AuthScope(pubHost, pubPort), new UsernamePasswordCredentials(pubUser, pubPass));       
        CloseableHttpClient httpClient = HttpClients.custom().setDefaultCredentialsProvider(credsProvider).build();
        
        return httpClient;
	}

}
