package com.adidas.dam.util;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.jackrabbit.api.security.user.Group;
import org.apache.jackrabbit.api.security.user.UserManager;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.jcr.base.util.AccessControlUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class User {

    private static final Logger log = LoggerFactory.getLogger(User.class);

    /**
     * *
     * Method to get groups users are members of
     *
     * @param resolver
     * @param userID
     * @return
     */
    public static Set<Group> getUserGroups(ResourceResolver resolver, String userID) {
        Set<Group> participants = new HashSet();

        try {
            UserManager um = AccessControlUtil.getUserManager(resolver.adaptTo(Session.class));
            Authorizable user = um.getAuthorizable(userID);
            Iterator<Group> groups = user.memberOf();

            while (groups.hasNext()) {
                participants.add(groups.next());
            }

        } catch (RepositoryException e) {
            log.error("getUserGroups error =" + e.getMessage(), e);
        }

        return participants;
    }

    /**
     * *
     * Checks if current user is an administrator
     *
     * @param resolver
     * @return
     */
    public static boolean isMemberOfGroup(ResourceResolver resolver, String groupToCheck) {
        Authorizable authUser = resolver.adaptTo(Authorizable.class);

        try {

            return checkGroup(authUser.memberOf(), groupToCheck);

        } catch (RepositoryException e) {
            log.error("isAdministrator error =" + e.getMessage(), e);
        }

        return false;
    }

    /**
     * *
     * Recursive check nested group for administrator group
     *
     * @param groups
     * @return true|false
     */
    private static boolean checkGroup(Iterator<Group> groups, String groupToCheck) {

        try {

            while (groups.hasNext()) {
                Group gr = groups.next();
                if (!gr.getID().equals(groupToCheck)) {
                    checkGroup(gr.memberOf(), groupToCheck);
                } else {
                    return true;
                }
            }
        } catch (Exception ex) {
            log.error("checkGroup error" + ex.getMessage(), ex);
        }

        return false;
    }
}
