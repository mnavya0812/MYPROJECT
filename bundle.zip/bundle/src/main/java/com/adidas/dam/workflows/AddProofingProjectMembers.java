package com.adidas.dam.workflows;

import com.adidas.dam.util.Helper;
import com.adobe.cq.projects.api.Project;
import com.adobe.cq.projects.api.ProjectMember;
import com.adobe.cq.projects.api.ProjectMemberRole;
import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.exec.WorkflowProcess;
import com.day.cq.workflow.metadata.MetaDataMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.jcr.Session;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.osgi.framework.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component
@Service
@Properties({
    @Property(name = Constants.SERVICE_DESCRIPTION, value = "Adidas Add Proofing Project Members", propertyPrivate = false),
    @Property(name = Constants.SERVICE_VENDOR, value = "3|Share"),
    @Property(name = "process.label", value = "Adidas Add Proofing Project Members", propertyPrivate = false)})

public class AddProofingProjectMembers implements WorkflowProcess {

    private static final Logger LOG = LoggerFactory.getLogger(AddProofingProjectMembers.class);

    private static final String PROOFER_ROLE = "proofers";

    @Reference
    ResourceResolverFactory resourceResolverFactory;

    public void execute(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap metaDataMap) throws WorkflowException {
        Session session = workflowSession.getSession();
        ResourceResolver resolver = null;
        String projectPath = "";
        Resource projectResource = null;
        MetaDataMap workflowMetaDataMap = null;

        try {
            resolver = resourceResolverFactory.getAdministrativeResourceResolver(null);
        } catch (LoginException e1) {
            LOG.error("err in AddProofingProjectMembers.execute -->" + e1.getMessage(), e1);
        }

        // get the resource from the payload
        Resource payloadResource = Helper.getResourceFromPayload(workItem, session, resolver);
        if (payloadResource != null) {
            workflowMetaDataMap = workItem.getWorkflow().getWorkflowData().getMetaDataMap();
            projectPath = workflowMetaDataMap.get("projectPath").toString();
            projectResource = resolver.getResource(projectPath);
        }

        try {

            Project project = projectResource.adaptTo(Project.class);
            ValueMap map = project.adaptTo(ValueMap.class);

            String publocation = (String) map.get("jcr:content/publocation");
            String proofingGroup = (String) map.get("jcr:content/proofer");

            List<String> members = new ArrayList<String>();
            List<String> roles = new ArrayList<String>();

            /**
             * GET existing members *
             */
            for (ProjectMember member : project.getMembers()) {
                members.add(member.getId());
                for (ProjectMemberRole role : member.getRoles()) {
                    roles.add(role.getId());
                }
            }

            /**
             * APPEND new members *
             */
            members.add(proofingGroup);
            roles.add(PROOFER_ROLE);

            updateProjectTeam(project, members, roles);

            //Add proofer group and proofer role to workflow meta data
            workflowMetaDataMap.put("proofer", proofingGroup);
            workflowMetaDataMap.put("publocation", publocation);

        } catch (Exception e) {
            LOG.error(e.getMessage(), e);
        }

    }

    /**
     * *
     *
     * @param project
     * @param teamMemberUserIds
     * @param teamMemberRoleIds
     */
    public void updateProjectTeam(Project project, String[] teamMemberUserIds, String[] teamMemberRoleIds) {
        List<String> userIds = Arrays.asList(teamMemberUserIds);
        List<String> roleIds = Arrays.asList(teamMemberRoleIds);
        LOG.info("AddProofingProjectMembers.updateProjectTeam invoked.");
        project.updateMembers(userIds, roleIds);
        LOG.info("AddProofingProjectMembers.updateProjectTeam completed.");
    }

    /**
     * *
     *
     * @param project
     * @param teamMemberUserIds
     * @param teamMemberRoleIds
     */
    public void updateProjectTeam(Project project, List<String> teamMemberUserIds, List<String> teamMemberRoleIds) {
        LOG.info("AddProofingProjectMembers.updateProjectTeam invoked.");
        project.updateMembers(teamMemberUserIds, teamMemberRoleIds);
        LOG.info("AddProofingProjectMembers.updateProjectTeam completed.");
    }

}
