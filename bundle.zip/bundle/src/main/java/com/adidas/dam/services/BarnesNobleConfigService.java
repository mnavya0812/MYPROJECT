package com.adidas.dam.services;

import java.util.Map;
import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.PropertyUnbounded;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(metatype = true, immediate = true,label = "Adidas Barnes Noble FTP Service")
@Service(BarnesNobleConfigService.class)
@Properties({
        @Property(name = "ftp.server", label = "FTP Server", unbounded = PropertyUnbounded.DEFAULT),
        @Property(name = "ftp.user", label = "FTP Username", unbounded = PropertyUnbounded.DEFAULT),
        @Property(name = "ftp.password", label = "FTP Password", unbounded = PropertyUnbounded.DEFAULT),
        @Property(name = "ftp.uploadDirectory", label = "FTP Upload Directory", unbounded = PropertyUnbounded.DEFAULT),
        @Property(name = "bn.image.preset", label = "Barnes Noble Image preset", unbounded = PropertyUnbounded.DEFAULT),
        @Property(name = "aemuser", label = "AEM Username", unbounded = PropertyUnbounded.DEFAULT),
        @Property(name = "aempassword", label = "AEM Password", unbounded = PropertyUnbounded.DEFAULT)
})
public class BarnesNobleConfigService {
	
	private String ftpServer;
	private String ftpUser;
	private String ftpPassword;
	private String ftpUploadDirectory;
	private String bnImagePreset;
	private String aemUser;
	private String aemPwd;
	
	//excel header names
	
	private String excelHeader1;
	private String excelHeader2;
	private String excelHeader3;
	private String excelHeader4;
	private String excelHeader5;
	private String excelHeader6;
	private String excelHeader7;
	private String excelHeader8;
	private String excelHeader9;
	
	
	private static final Logger LOG = LoggerFactory.getLogger(BarnesNobleConfigService.class);
	
	 @Activate
	  protected void activate(Map<String, Object> properties)
	  {
	    
	    readProperties(properties);
	  }
	
	
	 protected void readProperties(Map<String, Object> properties)
	  {
	    LOG.info(properties.toString());
	    this.ftpServer = PropertiesUtil.toString(properties.get("ftp.server"), "10.168.184.90");
	    
	    this.ftpUser = PropertiesUtil.toString(properties.get("ftp.user"), "BarnesandNoble");

	    this.ftpPassword = PropertiesUtil.toString(properties.get("ftp.password"), "test");

	    this.ftpUploadDirectory = PropertiesUtil.toString(properties.get("ftp.uploadDirectory"), "/ILDigitalImages");

	    this.bnImagePreset = PropertiesUtil.toString(properties.get("bn.image.preset"), "$bn_export$");

	    this.aemUser = PropertiesUtil.toString(properties.get("aemuser"), "admin");
	    
	    this.aemPwd = PropertiesUtil.toString(properties.get("aempassword"), "admin");
	    
	    
	    this.excelHeader1 = PropertiesUtil.toString(properties.get("excelheader_1"), "Image File Name");
	    
	    this.excelHeader2 = PropertiesUtil.toString(properties.get("excelheader_2"), "");

	    this.excelHeader3 = PropertiesUtil.toString(properties.get("excelheader_3"), "Store #");

	    this.excelHeader4 = PropertiesUtil.toString(properties.get("excelheader_4"), "SLD Style #");

	    this.excelHeader5 = PropertiesUtil.toString(properties.get("excelheader_5"), "Color Code");

	    this.excelHeader6 = PropertiesUtil.toString(properties.get("excelheader_6"), "Graphic Code");

	    this.excelHeader7 = PropertiesUtil.toString(properties.get("excelheader_7"), "Intrepid Style #");

	    this.excelHeader8 = PropertiesUtil.toString(properties.get("excelheader_8"), "SKU #");

	    this.excelHeader9 = PropertiesUtil.toString(properties.get("excelheader_9"), "Ship Date");
	    
	    
	  
	  }
	
	
	
	
	
	
	
	public String getFtpServer() {
		return ftpServer;
	}
	public void setFtpServer(String ftpServer) {
		this.ftpServer = ftpServer;
	}
	public String getFtpUser() {
		return ftpUser;
	}
	public void setFtpUser(String ftpUser) {
		this.ftpUser = ftpUser;
	}
	public String getFtpPassword() {
		return ftpPassword;
	}
	public String getExcelHeader1() {
		return excelHeader1;
	}


	public void setExcelHeader1(String excelHeader1) {
		this.excelHeader1 = excelHeader1;
	}


	public String getExcelHeader2() {
		return excelHeader2;
	}


	public void setExcelHeader2(String excelHeader2) {
		this.excelHeader2 = excelHeader2;
	}


	public String getExcelHeader3() {
		return excelHeader3;
	}


	public void setExcelHeader3(String excelHeader3) {
		this.excelHeader3 = excelHeader3;
	}


	public String getExcelHeader4() {
		return excelHeader4;
	}


	public void setExcelHeader4(String excelHeader4) {
		this.excelHeader4 = excelHeader4;
	}


	public String getExcelHeader5() {
		return excelHeader5;
	}


	public void setExcelHeader5(String excelHeader5) {
		this.excelHeader5 = excelHeader5;
	}


	public String getExcelHeader6() {
		return excelHeader6;
	}


	public void setExcelHeader6(String excelHeader6) {
		this.excelHeader6 = excelHeader6;
	}


	public String getExcelHeader7() {
		return excelHeader7;
	}


	public void setExcelHeader7(String excelHeader7) {
		this.excelHeader7 = excelHeader7;
	}


	public String getExcelHeader8() {
		return excelHeader8;
	}


	public void setExcelHeader8(String excelHeader8) {
		this.excelHeader8 = excelHeader8;
	}


	public String getExcelHeader9() {
		return excelHeader9;
	}


	public void setExcelHeader9(String excelHeader9) {
		this.excelHeader9 = excelHeader9;
	}


	public void setFtpPassword(String ftpPassword) {
		this.ftpPassword = ftpPassword;
	}
	public String getFtpUploadDirectory() {
		return ftpUploadDirectory;
	}


	public void setFtpUploadDirectory(String ftpUploadDirectory) {
		this.ftpUploadDirectory = ftpUploadDirectory;
	}


	public String getBnImagePreset() {
		return bnImagePreset;
	}


	public void setBnImagePreset(String bnImagePreset) {
		this.bnImagePreset = bnImagePreset;
	}


	public String getAemUser() {
		return aemUser;
	}


	public void setAemUser(String aemUser) {
		this.aemUser = aemUser;
	}


	public String getAemPwd() {
		return aemPwd;
	}


	public void setAemPwd(String aemPwd) {
		this.aemPwd = aemPwd;
	}

}
