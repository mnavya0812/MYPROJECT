package com.adidas.dam.util;

import java.io.*;
import java.util.ArrayList;
import java.util.Random;
import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.StatusLine;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AEMHttp {

    private static final Logger log = LoggerFactory.getLogger(AEMHttp.class);

    public static CloseableHttpResponse sendHttpGet(String aemHost, String getPath, String username, String password) throws IOException {
        CloseableHttpClient httpClient = HttpClients.createDefault();
        String getURL = aemHost + getPath;
        HttpGet httpGet = new HttpGet(getURL.replace(" ","%20"));
        httpGet.setHeader("Authorization", createAuthorizationToken(username,password));

        CloseableHttpResponse response = null;
        response = httpClient.execute(httpGet);

        return response;
    }

    public static StatusLine sendHttpPost(String url, ArrayList<NameValuePair> parameters, String username, String password) {

        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpPost httpPost = new HttpPost(url);
        Random r = new Random();
        String boundary = "AEMRequest";
        String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        for (int i = 0; i < 12; i++) {
            boundary += alphabet.charAt(r.nextInt(alphabet.length()));
        }
        httpPost.setHeader("Authorization", createAuthorizationToken(username, password));
        httpPost.setHeader("CSRF-Token", AEMHttp.obtainCSRFToken(username, password));
        httpPost.setHeader("Content-Type", "multipart/form-data; boundary="+boundary);
        httpPost.setHeader("Referer", url);
        MultipartEntityBuilder builder = MultipartEntityBuilder.create();
        builder.setBoundary(boundary);

        for (NameValuePair parameter : parameters) {
            builder.addTextBody(parameter.getName(), parameter.getValue());
        }

        HttpEntity multipart = builder.build();

        httpPost.setEntity(multipart);
        CloseableHttpResponse response = null;
        try {
            log.debug("Sending POST to " + httpPost.getURI());
            response = httpClient.execute(httpPost);

            InputStream responseStream = response.getEntity().getContent();
            BufferedReader br = new BufferedReader( new InputStreamReader(responseStream));
            String body = "";
            String line;
            while ((line = br.readLine()) != null){
                body += line;
            }

            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode >= 400) {
                log.error(statusCode + " - " + response.getStatusLine().getReasonPhrase());
                log.error(body);
            } else {
                log.debug(statusCode + " - " + response.getStatusLine().getReasonPhrase());
                log.trace(body);
            }
        } catch (IOException e) {
            log.error("Invalid Response. " + e.getMessage(), e);
            String stacktrace = "";
            for (StackTraceElement element : e.getStackTrace() ) {
                stacktrace += element.toString() + "\n";
            }
            log.error(stacktrace);
        }

        return response != null ? response.getStatusLine() : null;

    }
    /**
     * Creates an authorization token for use as an HTTP Header
     * @param username AEM account username
     * @param password AEM account password
     * @return Basic Auth token
     */
    private static String createAuthorizationToken(String username, String password) {
        String decodedToken = username + ":" + password;
        String encodedToken = null;
        try {
            encodedToken = new String(Base64.encodeBase64(decodedToken.getBytes("UTF-8")));
        } catch (UnsupportedEncodingException e) {
            log.error("Cannot encode authorization token for credentials. " + e.getMessage(), e);
        }
        return "Basic " + encodedToken;
    }

    /**
     * Gets the CSRT Token for the specified AEM user
     * @param username
     * @param password
     * @return
     */
    public static String obtainCSRFToken(String username, String password) {
        String aemHost = "http://localhost:4502";
        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpGet httpGet = new HttpGet(aemHost + "/libs/granite/csrf/token.json");
        httpGet.setHeader("Authorization", createAuthorizationToken(username, password));

        String token = null;
        try {
            CloseableHttpResponse response = httpClient.execute(httpGet);
            HttpEntity httpEntity = response.getEntity();
            String body = EntityUtils.toString(httpEntity);
            token = body.replaceAll("^\\{|\\}$","").split(":")[1].replaceAll("^\"|\"$","");
            System.out.println("Token: " + token);
        } catch (IOException e) {
            log.error("Unable to get CSRF Token. " + e.getMessage(), e);
        }

        return token;
    }
}
