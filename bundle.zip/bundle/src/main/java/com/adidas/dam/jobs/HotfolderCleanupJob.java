package com.adidas.dam.jobs;

import java.util.Calendar;
import java.util.Date;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Iterator;

import javax.jcr.Session;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adidas.dam.hotFolder.HotFolderConfiguration;
import com.adidas.dam.services.HotFolderConfigurationService;
import com.day.cq.dam.api.Asset;
import com.day.cq.dam.commons.util.DamUtil;
import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowService;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.WorkflowData;
import com.day.cq.workflow.model.WorkflowModel;

@Component(immediate=true, metatype=true)
@Service(value=Runnable.class)
@Properties({
	@Property(name="scheduler.expression", value="0 0,15,30,45 * * * ?", description="crontab expression for job scheduling."),
	@Property(name="scheduler.concurrent", boolValue=false, description="Whether to allow multiple jobs to run concurrently."),
	@Property(name="cleanup.window", value="60", description="Minutes since the asset was added to be eligible for cleanup."),
	@Property(name="workflow.model", value="/etc/workflow/models/process-hotfolders/jcr:content/model", description="Workflow model to execute against assets.")
})
public class HotfolderCleanupJob implements Runnable {

	private final Logger LOG = LoggerFactory.getLogger(HotfolderCleanupJob.class);
	
	private long cleanupDateGap;
	private String wfModelPath;

	@Reference 
	private ResourceResolverFactory resolverFactory;

	@Reference
	private HotFolderConfigurationService hfConfigSvc;
	
	@Reference
	private WorkflowService wfService;

	@Override
	public void run() {

		LOG.info("Starting hotfolder cleanup job.");
		ResourceResolver resolver = null;

		try {
			resolver = resolverFactory.getAdministrativeResourceResolver(null);		
			HashMap<String, HotFolderConfiguration> configs = hfConfigSvc.getHotFolderConfigurations();
			processHotfolders(resolver, configs);
		} catch (Exception e) {
			LOG.error("Exception in hotfolder cleanup job.", e);
		} finally {
			if (resolver != null && resolver.isLive()) {
				resolver.close();
			}
		}
		
		LOG.info("Hotfolder cleanup job complete.");
	}

	private void processHotfolders(ResourceResolver resolver, HashMap<String, HotFolderConfiguration> configs) {
		long currentDate = Calendar.getInstance().getTimeInMillis();
		
		for (String key:configs.keySet()) {
			HotFolderConfiguration currConfig = configs.get(key);
			Resource hotFolderResource = resolver.resolve(currConfig.getPath());
			processHotfolderAssets(resolver, currentDate, hotFolderResource);
		}
	}

	private void processHotfolderAssets(ResourceResolver resolver, long currentDate, Resource hotFolderResource) {
		Iterator<Asset> hotfolderAssets = DamUtil.getAssets(hotFolderResource);

		while (hotfolderAssets.hasNext()) {
			Asset childAsset = hotfolderAssets.next();
			Date modifiedDate = childAsset.getOriginal().getProperties().get("jcr:lastModified", Date.class);
			long modificationDate = modifiedDate.getTime();
			if (currentDate - modificationDate > cleanupDateGap) {
				startWorkflow(resolver, childAsset);	
			}
		}
	}

	private void startWorkflow(ResourceResolver resolver, Asset childAsset) {
		try {
			LOG.info("Executing workflow for " + childAsset.getPath());
			WorkflowSession wfSession = wfService.getWorkflowSession(resolver.adaptTo(Session.class));
			WorkflowModel wfModel = wfSession.getModel(wfModelPath);
			WorkflowData wfData = wfSession.newWorkflowData("JCR_PATH", childAsset.getOriginal().getPath());
			wfSession.startWorkflow(wfModel, wfData);
		} catch (WorkflowException e) {
			LOG.error("Error handled while attempting to reprocess " + childAsset.getPath() + ".", e);
		}
	}

	@Activate
	protected void activate(ComponentContext componentContext) {
		final Dictionary<?, ?> props = componentContext.getProperties();
		
		int cleanupWindow = PropertiesUtil.toInteger(props.get("cleanup.window"), 60);
		this.cleanupDateGap = cleanupWindow * 60 * 1000;
		
		this.wfModelPath = PropertiesUtil.toString(props.get("workflow.model"), "/etc/workflow/models/process-hotfolders/jcr:content/model");
		
		LOG.info("Hotfolder cleanup job initialized and scheduled with a cleanup window of " + cleanupWindow + " minutes.");
	}
}