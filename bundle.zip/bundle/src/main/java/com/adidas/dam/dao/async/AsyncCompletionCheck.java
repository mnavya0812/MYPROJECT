package com.adidas.dam.dao.async;

public interface AsyncCompletionCheck {
	String getPath();
	String getWaitMessage();
	boolean isComplete();
	String getCompleteMessage();
}
