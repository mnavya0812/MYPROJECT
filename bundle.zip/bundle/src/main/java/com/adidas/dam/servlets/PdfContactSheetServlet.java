package com.adidas.dam.servlets;

import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.lightbox.Lightbox;
import com.day.cq.dam.api.lightbox.LightboxService;
import com.day.cq.dam.commons.util.DamUtil;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.rmi.ServerException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.jcr.Session;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.stream.StreamSource;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.fop.apps.Fop;
import org.apache.fop.apps.FopFactory;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

@SlingServlet(paths = "/bin/pdfcontactsheet", methods = "POST", metatype = true)
public class PdfContactSheetServlet extends SlingAllMethodsServlet {

    private static final Logger log = LoggerFactory.getLogger(PdfContactSheetServlet.class);
    private static final long serialVersionUID = 1L;
    private ResourceResolver resourceResolver = null;

    private static String imageEncodePrefix = "data:image/png;base64,";
    private static String renditionSize = "cq5dam.thumbnail.319.319.png";

    private static final FopFactory fopFactory = FopFactory.newInstance();
    private static final TransformerFactory transformerFactory = TransformerFactory.newInstance();

    @Reference
    private LightboxService lightboxService;

    @Override
    protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServerException, IOException {
        doGet(request, response);
    }

    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServerException, IOException {

        Session session = request.getResourceResolver().adaptTo(Session.class);
        resourceResolver = request.getResourceResolver();

        try {

            /* String assets = request.getParameter("assets");
	    	 log.debug("assets-->"+assets);
	    	 
	    	 if ( assets==null || assets=="" ) {
	    		 return;
	    	 }
             */
            ByteArrayOutputStream out = new ByteArrayOutputStream();

            // FOP
            Fop fop = fopFactory.newFop("application/pdf", out);

            // Transformer
            Resource xsl = resourceResolver.getResource("/apps/adidas-dam/datasource/pdf/contactsheet.xsl");
            Source xsltSrc = new StreamSource(xsl.adaptTo(InputStream.class));
            Transformer transformer = transformerFactory.newTransformer(xsltSrc);
            Result result = new SAXResult(fop.getDefaultHandler());

            transformer.setParameter("username", session.getUserID());

            // Start the transformation and rendering process
            //String[] assetItems = assets.split("&");
            DOMSource source = new DOMSource(CreateDOM(resourceResolver));

            //transformer.transform(new StreamSource(new StringReader(contentStr)), result); // this is used for the xml file ref, instead of in-memory
            transformer.transform(source, result);
            //log.debug("PDF contact sheet has {} pages", fop.getResults().getPageCount());

            // Prepare response
            response.setContentType("application/pdf");
            response.setContentLength(out.size());

            // Send content to Browser
            response.getOutputStream().write(out.toByteArray());
            response.getOutputStream().flush();

        } catch (Exception ex) {
            log.error("err in pdfcontactsheetservlet -->" + ex.getMessage(), ex);
        }

    }

    /**
     * *
     * Method to create in-memory xml DOM
     *
     * @param resourceResolver
     * @return
     */
    private Document CreateDOM(ResourceResolver resourceResolver) {
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = null;
        try {

            docBuilder = docFactory.newDocumentBuilder();

            // root element
            Document doc = docBuilder.newDocument();
            Element rootElement = doc.createElement("root");
            doc.appendChild(rootElement);

            Element etop = doc.createElement("pdf-title");
            etop.appendChild(doc.createTextNode(""));
            rootElement.appendChild(etop);

            Element e1 = doc.createElement("pdf-description");
            e1.appendChild(doc.createTextNode(""));
            etop.appendChild(e1);

            Element e2 = doc.createElement("user-name");
            e2.appendChild(doc.createTextNode(resourceResolver.getUserID()));
            etop.appendChild(e2);

            Calendar cal = new GregorianCalendar();
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
            dateFormat.setTimeZone(cal.getTimeZone());

            Element e3 = doc.createElement("add-info");
            e3.appendChild(doc.createTextNode("" + dateFormat.format(cal.getTime())));
            etop.appendChild(e3);

            // contact-sheet data heading
            Element contactsheet = doc.createElement("contactsheet-data");

            Element csHeader = doc.createElement("header");

            Element csE1 = doc.createElement("cell");
            csE1.setAttribute("background-color", "#3F51B5"); // this attribute doesnt work yet: todo 
            csE1.appendChild(doc.createTextNode(" "));
            csHeader.appendChild(csE1);
            contactsheet.appendChild(csHeader);

            // contact-sheet 
            try {
                Lightbox lb = lightboxService.getLightbox(resourceResolver.adaptTo(Session.class));

                int count = 0;
                Element csRow = null;

                for (String assets : lb.getEntries()) {
                    String damPath = lb.getReference(assets);
                    Resource resource = resourceResolver.getResource(damPath);
                    //log.debug( "in pdf contact sheet servlet resource path-->" + resource.getPath() );

                    if (DamUtil.isRendition(resource)) {
                        //resource = resourceResolver.getResource(resource.getParent().getParent().getParent().getPath()); //assetOriginal/jcr:content/renditions/assetRendition
                        resource = resourceResolver.getResource(resource.getParent().getPath().replace("/jcr:content/renditions", ""));
                        //log.debug( "new resource path-->" + resource.getPath() );
                    }

                    Asset asset = resource.adaptTo(Asset.class);
                    InputStream in3 = asset.getRendition(renditionSize).getStream();

                    String imageEncoded = "";

                    try {
                        imageEncoded = new String(Base64.encodeBase64(IOUtils.toByteArray(in3)));
                    } catch (IOException e) {
                        log.debug(e.getMessage(), e);
                    }

                    // create new row for contact sheet
                    if (count == 0) {
                        csRow = doc.createElement("row");
                    }

                    Element imgCell = doc.createElement("cell");
                    imgCell.appendChild(doc.createTextNode(imageEncodePrefix + imageEncoded));
                    csRow.appendChild(imgCell);

                    Element imgCellFn = doc.createElement("filename");
                    imgCellFn.appendChild(doc.createTextNode(asset.getName()));
                    imgCell.appendChild(imgCellFn);

                    Element imgCellFModDate = doc.createElement("filedatemodified");
                    imgCellFModDate.appendChild(doc.createTextNode("" + dateFormat.format(asset.getLastModified())));
                    imgCell.appendChild(imgCellFModDate);

                    ++count;

                    // show only 4 thumbnails in a table row
                    if (count >= 4) {
                        contactsheet.appendChild(csRow);
                        count = 0;
                    }

                }

                contactsheet.appendChild(csRow);

            } catch (Exception ex) {
                log.debug("error in CreateDOM=" + ex.getMessage(), ex);
            }

            etop.appendChild(contactsheet);

            return doc;

        } catch (ParserConfigurationException e) {
            log.error(e.getMessage(), e);
        }

        return null;
    }

}
