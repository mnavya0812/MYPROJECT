package com.adidas.dam.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.RepositoryException;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Service;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adidas.dam.dao.async.AsyncCompletionCheck;
import com.adidas.dam.dao.async.AsyncWaitManager;
import com.adidas.dam.dao.filter.DamDAOFilter;
import com.adidas.dam.dao.filter.TaskStatusFilter;
import com.adidas.dam.dao.jcr.NodeRetriever;
import com.adidas.dam.services.ProjectWorkflowDAOService;
import com.adidas.dam.util.AEMHttp;
import com.adobe.cq.projects.api.Project;

@Component(immediate = true, metatype = true)
@Service(value=ProjectWorkflowDAOService.class)
public class ProjectWorkflowDAOServiceImpl implements ProjectWorkflowDAOService {

	private final Logger LOG = LoggerFactory.getLogger(ProjectWorkflowDAOService.class);
	
	private AsyncWaitManager asyncWaitManager;
	
    @Activate
    protected void activate(final Map<String, Object> config) {
    	asyncWaitManager = new AsyncWaitManager();
    }
	
    @Override
	public List<Resource> getActiveTasks(ResourceResolver resourceResolver, String projectPath) {
		try {
			List<DamDAOFilter> filters = new ArrayList<DamDAOFilter>();
			filters.add(new TaskStatusFilter("ACTIVE"));		
			
			NodeRetriever retriever = new NodeRetriever(resourceResolver, filters);
			
			String tasksPath = projectPath + "/jcr:content/tasks";
			
			return retriever.getResourcesDeep(tasksPath);
		} catch (Exception e) {
			LOG.error("Unable to retrieve active tasks for " + projectPath, e);
			return new ArrayList<Resource>();
		}
	}
	
	@Override
	public int getActiveTaskCount(ResourceResolver resourceResolver, String projectPath) {
		int activeTaskCount = getActiveTasks(resourceResolver, projectPath).size();
		LOG.debug("Found " + activeTaskCount + " active tasks for " + projectPath);
		return activeTaskCount;
	}
	
	@Override
	public void startProofingWorkflow(ResourceResolver resourceResolver, Project project, String userName, String userPassword, String priority) throws RepositoryException {
		String projectPath = project.adaptTo(Node.class).getPath();
		
		if (asyncWaitManager.hasItem(projectPath)) {
			LOG.debug("Already received a request to start a workflow for " + projectPath + ".");
		} else {
    		LOG.debug("Starting a workflow for " + projectPath + ".");
    		asyncWaitManager.addItem(projectPath);
    		
    		String url = "http://localhost:4502" + projectPath;
    		String proofingWorkflowModel = "/etc/workflow/models/adidas-di-proof-workflow/jcr:content/model";

    		ArrayList<NameValuePair> parameters = new ArrayList<NameValuePair>();

    		parameters.add(new BasicNameValuePair("projectAssetFolderPath", project.getAssetFolder().getPath()));
    		parameters.add(new BasicNameValuePair("modelId", proofingWorkflowModel));
    		parameters.add(new BasicNameValuePair("project", projectPath));
    		parameters.add(new BasicNameValuePair("wizard", "/libs/cq/core/content/projects/workflowwizards/photoshoot.html"));
    		parameters.add(new BasicNameValuePair("wizard@Delete", ""));
    		parameters.add(new BasicNameValuePair("_charset_", "UTF-8"));
    		parameters.add(new BasicNameValuePair("workflowTitle", "Hot Folder Proofing"));
    		parameters.add(new BasicNameValuePair("startComment", ""));
    		parameters.add(new BasicNameValuePair("projectPath", projectPath));
    		parameters.add(new BasicNameValuePair(":operation", "startWorkflow"));
    		parameters.add(new BasicNameValuePair(":http-equiv-accept", "application/json,*/*;q=0.9"));
    		parameters.add(new BasicNameValuePair("taskPriority", (priority.equals("high") ? "High" : "Medium")));

    		AEMHttp.sendHttpPost(url, parameters, userName, userPassword);
    		
    		AsyncCompletionCheck completionCheck = new WorkflowCompletionCheck(resourceResolver, projectPath, this);
    		new Thread(new WaitThread(completionCheck, asyncWaitManager)).start();
		}	
	}
}

class WaitThread implements Runnable {
		
	private AsyncCompletionCheck completionCheck;
	private AsyncWaitManager waitManager;
	
	public WaitThread(AsyncCompletionCheck completionCheck, AsyncWaitManager waitManager) {
		this.completionCheck = completionCheck;
		this.waitManager = waitManager;
	}

	@Override
	public void run() {
		waitManager.waitForCompletion(completionCheck, 360);
		waitManager.removeItem(completionCheck.getPath());
	}
	
}

class WorkflowCompletionCheck implements AsyncCompletionCheck {

	private final Logger LOG = LoggerFactory.getLogger(WorkflowCompletionCheck.class);
	
	private String projectPath;
	private ResourceResolver resourceResolver;
	private ProjectWorkflowDAOService projectDaoService;
	
	public WorkflowCompletionCheck(ResourceResolver resourceResolver, String projectPath, ProjectWorkflowDAOService projectDaoService) {
		
		try {
			this.projectPath = projectPath;
			this.resourceResolver = resourceResolver.clone(null);
			this.projectDaoService = projectDaoService;
		} catch (LoginException e) {
			LOG.error("Unable to clone resource resolver", e);
		}
		
	}
	
	@Override
	public String getPath() {
		return projectPath;
	}	
	
	@Override
	public String getWaitMessage() {
		return "Waiting for a workflow to be created for " + projectPath + ".";
	}

	@Override
	public boolean isComplete() {
		int activeTasks = projectDaoService.getActiveTaskCount(resourceResolver, projectPath);
		return activeTasks > 0;
	}

	@Override
	public String getCompleteMessage() {
		return "Workflow created for " + projectPath + "'.";
	}
}
