package com.adidas.dam.servlets;


import com.adidas.dam.util.SLDConstants;
import com.adobe.granite.asset.api.Asset;
import com.google.common.base.Strings;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.*;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Session;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.rmi.ServerException;
import java.util.Calendar;

 
@SlingServlet(paths="/bin/AssetProofingUpdateServlet", methods = "POST", metatype=true)
public class AssetProofingUpdate extends SlingAllMethodsServlet {
	
     private static final Logger log = LoggerFactory.getLogger(AssetProofingUpdate.class);

     private static final long serialVersionUID = 2598426539166789515L;
     
     @Reference
     ResourceResolverFactory resourceResolverfactory;
	private static final Object updateLock = new Object();

	@Override
     protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServerException, IOException {
    	 doGet(request,response);
     }
        
     @Override
     protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {

		 ResourceResolver resourceResolver = null;

		 int responseStatus = HttpServletResponse.SC_OK;
		 String responseContent = "OK";
		 try {
			 Session session = request.getResourceResolver().adaptTo(Session.class);
			 resourceResolver = resourceResolverfactory.getAdministrativeResourceResolver(null);

			 log.debug("session.getUserID()-->" + session.getUserID());
			 String userName = session.getUserID();

			 // Get the submitted form data
			 String mode = request.getParameter("mode");  /// mode = proofing
			 String assetItemsString = request.getParameter("assets");
			 String statusItem = request.getParameter("status");
			 String projectItem = request.getParameter("project");
			 String stepItem = request.getParameter("task");
			 String prooferItem = request.getParameter("proofer");

			 if (null == mode) {
				 //log.debug("AssetProofingUpdateServlet.asset NULL");
				 return;
			 }

			 log.debug("AssetProofingUpdateServlet.asset." + assetItemsString + "^^" + statusItem + "^^" + projectItem + "^^" + stepItem);
			 String[] assetItems = assetItemsString.split(",");


			 for (String assetItem : assetItems) {

				 if (Strings.isNullOrEmpty(assetItem)) {
					 continue;
				 }

				 synchronized (updateLock) {
					 log.debug("Updating metadata for " + assetItem);
					 resourceResolver.refresh();
					 Asset asset = resourceResolver.getResource(assetItem).adaptTo(Asset.class);
					 Resource metadataResource = asset.getChild("jcr:content/metadata");
					 ModifiableValueMap map = metadataResource.adaptTo(ModifiableValueMap.class);

					 try {
						 map.put(SLDConstants.DAM_STATUS, statusItem);
						 map.put(SLDConstants.DAM_PROJECT, projectItem);
						 map.put(SLDConstants.DAM_TASK, stepItem.toLowerCase());
						 map.put(SLDConstants.DAM_PROOFING_GROUP, prooferItem.toLowerCase());
						 map.put(SLDConstants.DAM_PROOF_BY_USER, userName);
						 Calendar cal = Calendar.getInstance();
						 map.put("dam:proofingDate", cal.getTime().toString());
						 asset.getResourceResolver().commit();
					 } catch (PersistenceException e) {
						 log.error("Could not save metadata for " + assetItem, e);
						 responseStatus = HttpServletResponse.SC_INTERNAL_SERVER_ERROR;
						 responseContent = "Could not save asset information";
					 }

				 }

			 }



		 } catch (LoginException e) {
			 log.error("Could not get admin resolver. ", e);
			 responseStatus = HttpServletResponse.SC_INTERNAL_SERVER_ERROR;
			 responseContent = "Could not obtain session";
		 } finally {
			 if (resourceResolver != null && resourceResolver.isLive()) {
				 resourceResolver.close();
			 }
		 }

		 // Return to caller
		 response.setContentType("text/html");
		 response.setStatus(responseStatus);
		 response.getWriter().println(responseContent);
	 }
}