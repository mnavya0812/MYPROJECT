package com.adidas.dam.util;

import com.adobe.acs.uncommons.fam.ActionManager;
import com.adobe.acs.uncommons.fam.ActionManagerFactory;
import com.adobe.acs.uncommons.fam.DeferredActions;
import com.adobe.acs.uncommons.functions.BiConsumer;
import com.adobe.acs.uncommons.functions.BiFunction;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.Value;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Re-tag assets from a file File should be tab-delimited and in the format of
 * path tag1 tag2, etc
 */
@Component(metatype = true, immediate = true, label = "Retag Assets")
@Service(RetagAssets.class)
public class RetagAssets {

    @Reference
    ActionManagerFactory actionManagerFactory;
    @Reference
    DeferredActions actions;

    private static final Logger LOG = LoggerFactory.getLogger(RetagAssets.class);
    public static final String QUERY_LANGUAGE = "JCR-SQL2";

    public int retagForPath(String filePath, String basePath, ResourceResolver resolver) throws RepositoryException, LoginException, Exception {
        if (resolver.getResource(basePath) == null) {
            throw new RepositoryException("Base path was not found: " + basePath);
        }

        Map<String, String[]> tagData = loadData(filePath);
        
        String query = "SELECT * FROM [dam:Asset] as a WHERE ISDESCENDANTNODE(a,'"+basePath+"')";
        ActionManager am = actionManagerFactory.createTaskManager("Remap tags "+basePath, resolver, 1);        
        int results = am.withQueryResults(query, QUERY_LANGUAGE, actions.retryAll(5, retagAllAssets(tagData)), skipIfNoRecord(tagData));
        am.addCleanupTask();
        return results;
    }

    private Map<String, String[]> loadData(String filePath) throws FileNotFoundException, IOException {
        File f = new File(filePath);
        LOG.info("Reading "+filePath);
        BufferedReader reader = new BufferedReader(new FileReader(f));
        Map<String, String[]> tagData = new HashMap<String, String[]>();
        String line = null;
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split("\\t");
            tagData.put(parts[0].trim(), Arrays.copyOfRange(parts, 1, parts.length));
        }
        LOG.info("Read "+tagData.size()+" rows from "+filePath);
        return tagData;
    }

    private BiConsumer<ResourceResolver, String> retagAllAssets(final Map<String, String[]> tagData) {
        return new BiConsumer<ResourceResolver, String>() {
            @Override
            public void accept(ResourceResolver res, String path) throws Exception {
                Resource meta = res.getResource(path + "/jcr:content/metadata");
                if (meta != null) {
                    Node metaNode = meta.adaptTo(Node.class);
                    if (!metaNode.hasProperty(SLDConstants.DAM_TAGS)
                            || !tagsMatch(metaNode, tagData.get(path))) {
                        res.adaptTo(Session.class).getWorkspace().getObservationManager().setUserData("changedByWorkflowProcess");
                        metaNode.setProperty(SLDConstants.DAM_TAGS, tagData.get(path));
                        res.commit();
                        res.refresh();
                    }
                }
            }
        };
    }

    private boolean tagsMatch(Node metaNode, String[] compare) throws RepositoryException {
        Value[] currentTags = metaNode.getProperty(SLDConstants.DAM_TAGS).getValues();
        for (String tag : compare) {
            boolean found = false;
            for (Value currentTag : currentTags) {
                if (currentTag.getString().equals(tag)) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                return false;
            }
        }
        return true;
    }

    private BiFunction<ResourceResolver, String, Boolean> skipIfNoRecord(final Map<String, String[]> tagData) {
        return new BiFunction<ResourceResolver, String, Boolean>() {
            @Override
            public Boolean apply(ResourceResolver res, String path) throws Exception {
                return tagData.containsKey(path);
            }
        };
    }
}
