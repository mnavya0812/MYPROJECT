package com.adidas.dam.workflows;



import com.adidas.dam.services.SAMMSDataService;
import com.adidas.dam.util.SLDConstants;
import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.exec.WorkflowProcess;
import com.day.cq.workflow.metadata.MetaDataMap;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import javax.jcr.Node;
import javax.jcr.RepositoryException;
import org.apache.felix.scr.annotations.*;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.framework.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(description = "Adidas SAMMS Data Process Step", metatype = true, immediate = true, enabled = true)
@Service
@Properties({
        @Property(name = Constants.SERVICE_DESCRIPTION, value = "Applies data from SAMMS based on style, color, and graphic"),
        @Property(name = Constants.SERVICE_VENDOR, value = "3|Share"),
        @Property(name = "process.label",value="Adidas SAMMS Data Processing",propertyPrivate = true)
})
public class SAMMSDataStep implements WorkflowProcess {

    @Reference
    SAMMSDataService sammsDataService;

    @Reference
    ResourceResolverFactory resolverFactory;

    private Logger log = LoggerFactory.getLogger(SAMMSDataStep.class);


    @Override
    public void execute(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap metaDataMap) throws WorkflowException {
        ResourceResolver resolver = null;
        String style = "";
        String color = "";
        String graphic = "";
        
        try {
            resolver = resolverFactory.getResourceResolver(Collections.singletonMap("user.jcr.session",(Object)workflowSession.getSession()));
            String payloadPath = workItem.getWorkflowData().getPayload().toString();
            Node assetNode = resolver.getResource(payloadPath.substring(0,payloadPath.indexOf("/jcr:content"))).adaptTo(Node.class);
            Node metadataNode = assetNode.getNode("jcr:content/metadata");
            
            if ( metadataNode.hasProperty(SLDConstants.STYLE_NUMBER) ) 
            	style = metadataNode.getProperty(SLDConstants.STYLE_NUMBER).getString();
            
            if ( metadataNode.hasProperty(SLDConstants.COLOR_CODE) )
            	color = metadataNode.getProperty(SLDConstants.COLOR_CODE).getString();
            
            if ( metadataNode.hasProperty(SLDConstants.GRAPHIC_CODE) )
            	graphic = metadataNode.getProperty(SLDConstants.GRAPHIC_CODE).getString();

            if (    style != null && !"".equals(style) &&
                    color != null && !"".equals(color) &&
                    graphic != null && !"".equals(graphic)   ) {
                    style = style.toUpperCase();
                    color = color.toUpperCase();
                    graphic = graphic.toUpperCase();
                
                HashMap<String, String> properties = sammsDataService.getPropertiesForKey(style, color, graphic);
                for (Map.Entry<String,String> property : properties.entrySet()) {
                    String propName = property.getKey();
                    String propValue = property.getValue();
                    if (!"".equals(propValue)) {
                        metadataNode.setProperty(property.getKey(), property.getValue());
                    }
                }
            }
        } catch (RepositoryException e) {
            log.error("Unable to access metadata node. " + e.getMessage());
        } catch (LoginException e) {
            log.error("Unable to login. " + e.getMessage());
        }
    }
}
