package com.adidas.dam.servlets;

import java.io.IOException;
import java.rmi.ServerException;
import java.util.Calendar;

import javax.jcr.Session;
import javax.servlet.http.HttpServletResponse;

import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.jackrabbit.api.security.user.UserManager;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.jcr.base.util.AccessControlUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@SlingServlet(paths="/bin/UpdateAgreement", methods = "POST", metatype=true)
public class UpdateAgreementServlet extends SlingAllMethodsServlet {

	private static final Logger log = LoggerFactory.getLogger(UpdateAgreementServlet.class);

	private static final long serialVersionUID = 2598426539166789515L;
	
	@Reference
    ResourceResolverFactory resolverFactory;
	
	@Override
	protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServerException, IOException {
		doGet(request, response);
	}

	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServerException, IOException {
	       
		ResourceResolver resourceResolver = null;
		
		log.debug("invoked UpdateAgreementServlet");
		
		boolean updateEULA = true;
		boolean updateCA = true;
	    
		try
	    {
			resourceResolver = resolverFactory.getAdministrativeResourceResolver(null);
			
			 //retrieve the requested URL
            //String uri = request.getParameter("uri");
            
            Session session = request.getResourceResolver().adaptTo(javax.jcr.Session.class);
            
            log.debug("session.getUserID()-->" + session.getUserID());
            String userName = session.getUserID();
            
            UserManager um = AccessControlUtil.getUserManager(resourceResolver.adaptTo(Session.class));
       	 
 	        Authorizable user = um.getAuthorizable(userName);
 	        ModifiableValueMap profile = resourceResolver.getResource(user.getPath() + "/profile").adaptTo(ModifiableValueMap.class);
 	        
 	        Calendar cal = Calendar.getInstance();
 	       
 	        if ( updateEULA ) {
 	    	   profile.put("eula", cal.getTime().toString());
 	    	   String eula = profile.get("eula", "");
 	    	   log.debug("updating user {} eula profile value to {} .. " + userName,eula);
	        }
 	       
 	        if ( updateCA ) {
 	    	   profile.put("ca", cal.getTime().toString());
 	    	   String ca = profile.get("ca", "");
 	    	   log.debug("updating user {} confidentiality agreement profile value to {} .. " + userName,ca);
 	        }
 	       
 	        resourceResolver.commit();
 	        
          // Return to caller
          response.setContentType("text/html");
          response.setStatus(HttpServletResponse.SC_OK);
            
	    } catch(Exception ex) {
	    	 log.error("ERR in servlet updateagreement " + ex.getMessage());
	    }
	}
}
