package com.adidas.dam.services;

import com.adidas.dam.hotFolder.HotFolderConfiguration;
import org.apache.felix.scr.annotations.*;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Dictionary;

@Component(configurationFactory = true, metatype = true, policy= ConfigurationPolicy.REQUIRE,immediate = true,label="Adidas Hot Folder Configuration Factory")
@Service(value = HotFolderConfigurationFactory.class)
@Properties({
        @Property(name="hotfolder.path", unbounded= PropertyUnbounded.DEFAULT,label = "Hot Folder Path",description = ""),
        @Property(name="hotfolder.name", unbounded=PropertyUnbounded.DEFAULT,label="Hot Folder Name"),
        @Property(name="priority", label="Priority",options = {
                @PropertyOption(value="Normal (48hr)",name="normal"),
                @PropertyOption(value="High (24hr)",name="high")
        }, value = "normal"),
        @Property(name="art.document.type", unbounded=PropertyUnbounded.DEFAULT, label="Art Document Type"),
        @Property(name="brand", unbounded=PropertyUnbounded.DEFAULT,label="Brand"),
        @Property(name="di.folder", unbounded=PropertyUnbounded.DEFAULT,label="DI Folder"),
        @Property(name="league", unbounded=PropertyUnbounded.DEFAULT,label="League"),
        @Property(name="default.metadata", unbounded=PropertyUnbounded.ARRAY,label="Default Metadata Fields",description="Properties stored to the jcr:content/metadata node. formatted as <property-name>=<value>"),
        @Property(name="proofing.group", unbounded=PropertyUnbounded.DEFAULT,label="Proofing Group")
})
public class HotFolderConfigurationFactory {

    @Reference
    HotFolderConfigurationService hotFolderConfigurationService;
    private static final Logger log = LoggerFactory.getLogger(HotFolderConfigurationFactory.class);

    @Activate
    public void activate(ComponentContext componentContext) {
        final Dictionary<?,?> props = componentContext.getProperties();
        String hotFolderPath = PropertiesUtil.toString(props.get("hotfolder.path"),"");
        String hotfolderName = PropertiesUtil.toString(props.get("hotfolder.name"),"");
        String priority = PropertiesUtil.toString(props.get("priority"),"normal");
        String artDocumentType = PropertiesUtil.toString(props.get("art.document.type"),"");
        String brand= PropertiesUtil.toString(props.get("brand"),"");
        String diFolder = PropertiesUtil.toString(props.get("di.folder"),"");
        String league = PropertiesUtil.toString(props.get("league"),"");
        String[] defaultMetadata = PropertiesUtil.toStringArray(props.get("default.metadata"));
        String proofingGroup = PropertiesUtil.toString(props.get("proofing.group"),"");
        if ( "".equals(hotFolderPath) || "".equals(proofingGroup) ) {
            log.error("Invalid Hot Folder Configuration");
            return;
        }

        HotFolderConfiguration hotFolderConfiguration = new HotFolderConfiguration();
        hotFolderConfiguration.setPath(hotFolderPath);
        hotFolderConfiguration.setName(hotfolderName);
        hotFolderConfiguration.setPriority(priority);
        hotFolderConfiguration.setArtDocumentType(artDocumentType);
        hotFolderConfiguration.setBrand(brand);
        hotFolderConfiguration.setDiFolderType(diFolder);
        hotFolderConfiguration.setLeague(league);
        if (defaultMetadata != null) {
            for (String metadataEntry : defaultMetadata) {
                String[] entry = metadataEntry.trim().split("=");
                hotFolderConfiguration.addDefaultMetadata(entry[0], entry[1]);
            }
        }
        hotFolderConfiguration.setProofingGroup(proofingGroup);

        //add to service
        hotFolderConfigurationService.addHotFolderConfiguration(hotFolderPath,hotFolderConfiguration);


    }
}
