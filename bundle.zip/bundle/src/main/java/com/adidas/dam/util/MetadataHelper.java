package com.adidas.dam.util;

import javax.jcr.Node;
import javax.jcr.Value;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;

public class MetadataHelper {
    
	private final static Logger LOGGER = LoggerFactory.getLogger(MetadataHelper.class);
    
    public static String getValues(Tag[] list, String tagPartial) {
    	String matchingTags = "";
    	for (int index = 0; index < list.length; index++) {
    		Tag tag = list[index];
    		String path = tag.getPath();
    		if (path.contains(tagPartial)) {
    			matchingTags = tag.getTitle();
    		}
    	}
    	
    	return matchingTags;
    }
    
    public static String getValues(String path, String metadataPath, ResourceResolver resourceResolver) {
    	String metadataValue = "";
    	try {
    		TagManager tagMgr = resourceResolver.adaptTo(TagManager.class);
    		
	    	if (StringUtils.isNotBlank(path) && StringUtils.isNotBlank(metadataPath)) {
	    		Node assetNode = resourceResolver.getResource(path).adaptTo(Node.class);
	    		if (!assetNode.getProperty(metadataPath).isMultiple()) {
	    			metadataValue = assetNode.getProperty(metadataPath).getString();
	    			Tag tag = tagMgr.resolve(metadataValue);
	    			if (tag != null) {
	    				metadataValue = tag.getTitle();
	    			}
	    		} else {
	    			Value[] value = assetNode.getProperty(metadataPath).getValues();
	    			metadataValue = value[0].getString();
	    			Tag tag = tagMgr.resolve(metadataValue);
	    			if (tag != null) {
	    				metadataValue = tag.getTitle();
	    			}
	    		}
	    	}
    	
    	} catch (Exception e) {
			LOGGER.info("getSingleValue() :: Property Doesn't Exist");
			return "";
		}
    	return metadataValue;
    }
   
}
