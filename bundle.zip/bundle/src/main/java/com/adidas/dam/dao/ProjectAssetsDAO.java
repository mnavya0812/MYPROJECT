package com.adidas.dam.dao;

import java.util.ArrayList;
import java.util.List;

import javax.jcr.Session;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adidas.dam.dao.filter.DamDAOFilter;
import com.adidas.dam.dao.filter.NonCoverImageFilter;
import com.adidas.dam.dao.filter.NonSubAssetFilter;
import com.adidas.dam.dao.filter.PendingAssetFilter;
import com.adidas.dam.dao.jcr.NodeRetriever;
import com.day.cq.dam.api.Asset;

public class ProjectAssetsDAO {

	private final Logger LOG = LoggerFactory.getLogger(ProjectAssetsDAO.class);
	
	public List<Resource> getProjectAssets(ResourceResolver resourceResolver, String projectPath) {
		try {
			List<DamDAOFilter> filters = new ArrayList<DamDAOFilter>();
			filters.add(new NonSubAssetFilter());		
			filters.add(new NonCoverImageFilter());		
			
			NodeRetriever retriever = new NodeRetriever(resourceResolver, filters);
			
			return retriever.getResourcesDeep(projectPath);
		} catch (Exception e) {
			LOG.error("Unable to retrieve pending assets for " + projectPath, e);
			return new ArrayList<Resource>();
		}
	}
	
	public List<Resource> getPendingAssets(ResourceResolver resourceResolver, String projectPath) {
		try {
			List<DamDAOFilter> filters = new ArrayList<DamDAOFilter>();
			filters.add(new PendingAssetFilter());		
			filters.add(new NonCoverImageFilter());		
			
			NodeRetriever retriever = new NodeRetriever(resourceResolver, filters);
			
			return retriever.getResourcesDeep(projectPath);
		} catch (Exception e) {
			LOG.error("Unable to retrieve pending assets for " + projectPath, e);
			return new ArrayList<Resource>();
		}
	}
	
	public int getPendingAssetCount(ResourceResolver resourceResolver, String projectPath) {
		int pendingAssetCount = getPendingAssets(resourceResolver, projectPath).size();
		LOG.debug("Found " + pendingAssetCount + " pending assets for " + projectPath);
		return pendingAssetCount;
	}
	
	public void createDeleteAsset(ResourceResolver resolver, Asset asset, String destinationAssetPath) throws Exception {
		resolver.refresh();
		com.day.cq.dam.api.AssetManager cqAssetManager = resolver.adaptTo(com.day.cq.dam.api.AssetManager.class);
        com.adobe.granite.asset.api.AssetManager graniteAssetManager = resolver.adaptTo(com.adobe.granite.asset.api.AssetManager.class);
        
        if (graniteAssetManager.assetExists(destinationAssetPath)) {
        	Asset destinationAsset = resolver.getResource(destinationAssetPath).adaptTo(Asset.class);
        	cqAssetManager.createRevision(destinationAsset, null, null);
        }

        cqAssetManager.createAsset(destinationAssetPath, asset.getOriginal().getStream(), asset.getMimeType(), true);
        graniteAssetManager.removeAsset(asset.getPath());
	}
	
	public void moveAsset(ResourceResolver resolver, Asset asset, String destinationAssetPath) throws Exception {
		resolver.refresh();
        com.adobe.granite.asset.api.AssetManager graniteAssetManager = resolver.adaptTo(com.adobe.granite.asset.api.AssetManager.class);

        if (graniteAssetManager.assetExists(destinationAssetPath)) {
        	createDeleteAsset(resolver, asset, destinationAssetPath);
        } else {
            graniteAssetManager.moveAsset(asset.getPath(), destinationAssetPath);
        }
        
        resolver.adaptTo(Session.class).save();
        
        LOG.debug("Moved " + asset.getPath() + " to " + destinationAssetPath + ".");
	}
}
