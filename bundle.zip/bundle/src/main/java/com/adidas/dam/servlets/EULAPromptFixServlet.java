package com.adidas.dam.servlets;

import com.adidas.dam.util.SLDConstants;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.request.RequestParameter;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.jcr.*;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;
import javax.servlet.ServletException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;

@SlingServlet(paths="/bin/eulafix", methods = "GET", metatype=true)
public class EULAPromptFixServlet extends SlingAllMethodsServlet{

    private static final Logger log = LoggerFactory.getLogger(EULAPromptFixServlet.class);
    @Reference
    ResourceResolverFactory resolverFactory;

    @Override
    protected void doGet(@Nonnull SlingHttpServletRequest request, @Nonnull SlingHttpServletResponse response) throws ServletException, IOException {

        RequestParameter cmd = request.getRequestParameter("cmd");
        PrintWriter out = response.getWriter();
        response.setContentType("text/html");

        if (cmd != null && cmd.getString().equals("runfix")) {
            runFix();
        }

        out.println("<form>" +
                "<input type='hidden' value='runfix' name='cmd'/><button type='submit'>Apply EULA Fix</a>" +
                "</form>");
    }

    private void runFix() {
        String sqlStatement = "SELECT * FROM [dam:Asset] WHERE ISDESCENDANTNODE([/content/dam/sld])";
        Calendar startTime = Calendar.getInstance();

        try {
            ResourceResolver adminResolver = resolverFactory.getAdministrativeResourceResolver(null);
            Session adminSession = adminResolver.adaptTo(Session.class);
            QueryManager queryManager = adminSession.getWorkspace().getQueryManager();
            Query query = queryManager.createQuery(sqlStatement, Query.JCR_SQL2);

            QueryResult queryResult = query.execute();
            NodeIterator nodeIterator = queryResult.getNodes();
            log.info("Processing " + nodeIterator.getSize() + " assets.");
            long updateAssets = 0;
            while (nodeIterator.hasNext()) {
                Node assetNode = nodeIterator.nextNode();
                Node metadataNode = assetNode.getNode("jcr:content/metadata");
                if (metadataNode.hasProperty("xmpRights:webStatement")) {
                    log.info("Updating " + assetNode.getPath());
                    metadataNode.setProperty("xmpRights:webStatement", (Value) null);
                    metadataNode.setProperty(SLDConstants.ASSET_DRM, SLDConstants.ASSET_DRM_PATH);
//                    adminSession.save();
                    updateAssets++;
                }
            }

            Calendar endTime = Calendar.getInstance();

            long milliseconds = endTime.getTime().getTime() - startTime.getTime().getTime();
            log.info("Updated " + updateAssets + " assets in " + milliseconds/1000.00 + " seconds.");
        } catch (LoginException e) {
            log.error("Cannot login as admin. " + e.getMessage());
        } catch (RepositoryException e) {
            log.error("Repository error. " + e.getMessage());
        }
    }
}
