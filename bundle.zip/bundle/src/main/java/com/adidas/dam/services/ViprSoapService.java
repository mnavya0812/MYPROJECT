package com.adidas.dam.services;

import com.adidas.dam.models.ViprServiceData;
import java.util.Dictionary;
import javax.net.ssl.SSLContext;
import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.ConfigurationPolicy;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.PropertyUnbounded;
import org.apache.felix.scr.annotations.Service;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.HttpClientConnectionManager;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.BasicHttpClientConnectionManager;
import org.apache.http.util.EntityUtils;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(immediate = true, metatype = true, policy = ConfigurationPolicy.REQUIRE)
@Service(ViprSoapService.class)
@Properties({
    @Property(name = "soap.endpoint.uri", unbounded = PropertyUnbounded.DEFAULT, label = "SOAP Endpoint URL", description = "SOAP Endpoint to invoke VIPR Service for rejected assets"),
    @Property(name = "soap.endpoint.username", unbounded = PropertyUnbounded.DEFAULT, label = "SOAP Endpoint Username", description = "SOAP Endpoint Username to invoke VIPR Service for rejected assets"),
    @Property(name = "soap.endpoint.password", unbounded = PropertyUnbounded.DEFAULT, label = "SOAP Endpoint Password", description = "SOAP Endpoint Password invoke VIPR Service for rejected assets"),
    @Property(name = "soap.endpoint.authUserXmlns", unbounded = PropertyUnbounded.DEFAULT, label = "SOAP Endpoint AuthenticatedUser", description = "SOAP Endpoint AuthenticatedUser XMLNS to invoke VIPR Service for rejected assets"),
    @Property(name = "soap.endpoint.reqSampleXmlns", unbounded = PropertyUnbounded.DEFAULT, label = "SOAP Endpoint RequeSample", description = "SOAP Endpoint RequeSample XMLNS invoke VIPR Service for rejected assets")
})
public class ViprSoapService {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    private String soapEndpointUri = "";
    private String soapUserName = "";
    private String soapPassword = "";
    private String authUserXmlns = "";
    private String reqSampleXmlns = "";

    /**
     * *
     *
     * @param rejectedAssetName
     */
    public void SendSoapMessageToVipr(String rejectedAssetName) {

        try {
            //log.debug( "adi-soap-->" +vsd.getSOAPxml(soapUsername, soapPassword, assetName, authUserXmlns, reqSampleXmlns) );
            sendHTTPpostXml(new ViprServiceData().getSOAPxml(soapUserName, soapPassword, rejectedAssetName, authUserXmlns, reqSampleXmlns));

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * *
     * Send SOAP XML via HTTP post
     *
     * @param soapXml
     */
    private void sendHTTPpostXml(String soapXml) {
        try {

            /**
             * *
             * This works too but most of methods are deprecated HttpClient
             * httpClient = new DefaultHttpClient(); SSLSocketFactory
             * sslSocketFactory = new SSLSocketFactory( SSLContext.getDefault(),
             * SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER); Scheme scheme =
             * new Scheme("https", 443, sslSocketFactory);
             * httpClient.getConnectionManager().getSchemeRegistry().register(scheme);
			**
             */
            // This will suppress internally signed certificate that are not trusted 
            HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();
            SSLConnectionSocketFactory sslConnectionFactory = new SSLConnectionSocketFactory(
                    SSLContext.getDefault(), SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);

            // Assign the ssl connection context
            httpClientBuilder.setSSLSocketFactory(sslConnectionFactory);

            // Registers http + https scheme
            Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
                    .register("https", sslConnectionFactory)
                    .register("http", new PlainConnectionSocketFactory())
                    .build();
            HttpClientConnectionManager ccm = new BasicHttpClientConnectionManager(registry);
            httpClientBuilder.setConnectionManager(ccm);

            CloseableHttpClient httpClient = httpClientBuilder.build();

            StringEntity strEntity = new StringEntity(soapXml, "text/xml", "UTF-8");

            HttpPost post = new HttpPost(soapEndpointUri);
            post.setEntity(strEntity);

            // Execute the request
            HttpResponse response = httpClient.execute(post);
            HttpEntity respEntity = response.getEntity();

            if (respEntity != null) {
                String responseStringEntity = EntityUtils.toString(respEntity);
                log.debug("VIPR Success Response:" + responseStringEntity);
            } else {
                log.error("VIPR Failed No Response");
            }

            response = null;
            respEntity = null;
            httpClientBuilder = null;
            httpClient.close();
        } catch (ClientProtocolException cpe) {
            log.error("VIPR client Protocol Exception = " + cpe.toString(), cpe);
        } catch (Exception e) {
            log.error("VIPR post exception = " + e.toString(), e);
        }
    }

    /**
     * *
     * Get the configuration via the OSGI runmode
     *
     * @param componentContext
     */
    @Activate
    protected void activate(ComponentContext componentContext) {
        final Dictionary<?, ?> props = componentContext.getProperties();
        this.soapEndpointUri = PropertiesUtil.toString(props.get("soap.endpoint.uri"), "https://usindamap64.am.adsint.biz/websvcmgr.php");
        this.soapUserName = PropertiesUtil.toString(props.get("soap.endpoint.username"), "div");
        this.soapPassword = PropertiesUtil.toString(props.get("soap.endpoint.password"), "pwfdIvAdIdAs");
        this.authUserXmlns = PropertiesUtil.toString(props.get("soap.endpoint.authUserXmlns"), "http://usindamap64.am.adsint.biz");
        this.reqSampleXmlns = PropertiesUtil.toString(props.get("soap.endpoint.reqSampleXmlns"), "http://usindamap64.am.adsint.biz/OrderTracking");
    }

    /**
     * * SAMPLE Request and Response from VIPR Service via SOAP //REQUEST
     * <Envelope xmlns="http://schemas.xmlsoap.org/soap/envelope/">
     * <Header>
     * <AuthenticatedUser xmlns="http://usindamap64.am.adsint.biz">
     * <username>div</username>
     * <password>pwfdIvAdIdAs</password>
     * </AuthenticatedUser>
     * </Header>
     * <Body>
     * <RequeSample xmlns="http://usindamap64.am.adsint.biz/OrderTracking">
     * <FileName>4352W_UJA_TKUWUJA_010_F.psd</FileName>
     * </RequeSample>
     * </Body>
     * </Envelope>
     *
     * 4352W_UJA_TKUWUJA_010_F.psd 4353W_SAS_THRWSAS_FWK_F.psd
     * 309FA_LAL_PPJ7LAL_BHT_MF.psd 3404A_FPA_DEM815_004_MB.psd
     * 4795A_COC_QME9COC_C3D_MF.psd
     *
     *
     * //RESPONSE
     * <soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
     * <soap:Body>
     * <RequeSampleResponse xmlns="http://usindamap64/OrderTracking">
     * <ArrayOfWebService>
     * <WebService>
     * <Result>0</Result>
     * <ResultDescription xsi:nil="true"/>
     * <Input>&lt;FileName&gt;4352W_UJA_TKUWUJA_010_F.psd&lt;/FileName&gt;</Input>
     * </WebService>
     * </ArrayOfWebService>
     * </RequeSampleResponse>
     * </soap:Body>
     * </soap:Envelope>
     *
     ***
     */
}
