package com.adidas.dam.workflows;

import com.adidas.dam.util.Helper;
import com.adidas.dam.util.SLDConstants;
import com.day.cq.replication.ReplicationActionType;
import com.day.cq.replication.ReplicationException;
import com.day.cq.replication.Replicator;
import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.exec.WorkflowProcess;
import com.day.cq.workflow.metadata.MetaDataMap;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.framework.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import java.util.Collections;

@Component(metatype=true)
@Service
@Properties({
        @org.apache.felix.scr.annotations.Property(name = Constants.SERVICE_DESCRIPTION, value = "Checks Confidential status and sets to no if it is not already set."),
        @org.apache.felix.scr.annotations.Property(name = Constants.SERVICE_VENDOR, value = "3|Share"),
        @org.apache.felix.scr.annotations.Property(name = "process.label",value="Adidas Check Confidential Status",propertyPrivate = true)
})
public class CheckConfidentialProperty implements WorkflowProcess{

    private static final Logger log = LoggerFactory.getLogger(CheckConfidentialProperty.class);

    @Reference
    ResourceResolverFactory resolverFactory;

    @Override
    public void execute(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap metaDataMap) throws WorkflowException {

        Session session = workflowSession.getSession();
        ResourceResolver resolver = null;
        try {
            resolver = resolverFactory.getResourceResolver(Collections.singletonMap("user.jcr.session",(Object)workflowSession.getSession()));
            Resource payloadResource = Helper.getResourceFromPayload(workItem, session, resolver);
            Node metadataNode = payloadResource.adaptTo(Node.class).getNode("jcr:content/metadata");

            String confidential = metadataNode.hasProperty(SLDConstants.DI_CONFIDENTIAL) ? metadataNode.getProperty(SLDConstants.DI_CONFIDENTIAL).getString() : "";

            if (confidential.trim().equals("")) {
                metadataNode.setProperty(SLDConstants.DI_CONFIDENTIAL,"no");
                metadataNode.getSession().save();
            }


        } catch (LoginException e) {
            log.error("Unable to get resolver. " + e.getMessage());
        } catch (PathNotFoundException e) {
            log.error("Cannot find path. " + e.getMessage());
        } catch (RepositoryException e) {
            log.error("Unable to access node. " + e.getMessage() );
        }

    }
}
