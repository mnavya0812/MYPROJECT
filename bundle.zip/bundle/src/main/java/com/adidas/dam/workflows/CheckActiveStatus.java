package com.adidas.dam.workflows;

import com.adidas.dam.util.Helper;
import com.adidas.dam.util.SLDConstants;
import com.day.cq.replication.ReplicationActionType;
import com.day.cq.replication.ReplicationException;
import com.day.cq.replication.Replicator;
import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.exec.WorkflowProcess;
import com.day.cq.workflow.metadata.MetaDataMap;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.framework.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.*;
import java.util.Collections;

@Component(metatype=true)
@Service
@Properties({
        @org.apache.felix.scr.annotations.Property(name = Constants.SERVICE_DESCRIPTION, value = "Deactivates assets that are inactive, but were published. Reactivates activated assets."),
        @org.apache.felix.scr.annotations.Property(name = Constants.SERVICE_VENDOR, value = "3|Share"),
        @org.apache.felix.scr.annotations.Property(name = "process.label",value="Adidas Check Active Status for Deactivation",propertyPrivate = true)
})
public class CheckActiveStatus implements WorkflowProcess{

    private static final Logger log = LoggerFactory.getLogger(CheckActiveStatus.class);

    @Reference
    ResourceResolverFactory resolverFactory;

    @Reference
    Replicator replicator;

    @Override
    public void execute(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap metaDataMap) throws WorkflowException {

        Session session = workflowSession.getSession();
        ResourceResolver resolver = null;
        try {
            resolver = resolverFactory.getResourceResolver(Collections.singletonMap("user.jcr.session",(Object)workflowSession.getSession()));
            Resource payloadResource = Helper.getResourceFromPayload(workItem, session, resolver);
            Node metadataNode = payloadResource.adaptTo(Node.class).getNode("jcr:content/metadata");

            // only check items within /content/dam/sld
            if (payloadResource.getPath().startsWith("/content/dam/sld")) {
                String active = metadataNode.hasProperty(SLDConstants.ACTIVE) ? metadataNode.getProperty(SLDConstants.ACTIVE).getString() : "";
                String lastReplicationAction = metadataNode.getParent().hasProperty("cq:lastReplicationAction") ? metadataNode.getParent().getProperty("cq:lastReplicationAction").getString() : "";

                log.debug("active: " + active + ", lastReplicationAction: " + lastReplicationAction);
                if (active.equals("false") && lastReplicationAction.toLowerCase().equals("activate")) {
                    // deactivate assets that are marked 'inactive' and have been activated
                    log.info("DEACTIVATING " + payloadResource.getPath());
                    replicator.replicate(session, ReplicationActionType.DEACTIVATE,payloadResource.getPath());
                } else if ( lastReplicationAction.toLowerCase().equals("activate") ) {
                    // re/activate active assets that have already been activated
                    log.info("ACTIVATING " + payloadResource.getPath());
                    replicator.replicate(session, ReplicationActionType.ACTIVATE,payloadResource.getPath());
                } else {
                    log.debug("No action taken on " + payloadResource.getPath());
                }
            }

        } catch (LoginException e) {
            log.error("Unable to get resolver. " + e.getMessage());
        } catch (PathNotFoundException e) {
            log.error("Cannot find path. " + e.getMessage());
        } catch (RepositoryException e) {
            log.error("Unable to access node. " + e.getMessage() );
        } catch (ReplicationException e) {
            log.error("Unable to deactivate. " + e.getMessage());
        }

    }
}
