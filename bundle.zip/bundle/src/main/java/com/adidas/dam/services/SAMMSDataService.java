package com.adidas.dam.services;

import com.adidas.dam.models.SAMMSData;
import com.adidas.dam.util.ExportForSAMMS;
import com.adidas.dam.util.ImportForSAMMS;
import com.adidas.dam.util.SLDConstants;
import java.util.Collection;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Map;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.PropertyIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.ValueFactory;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;
import org.apache.felix.scr.annotations.*;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(immediate = true, metatype = true)
@Service(SAMMSDataService.class)
@Properties({
    @Property(name = "samms.data.node", unbounded = PropertyUnbounded.DEFAULT, label = "SAMMS Data Node", description = "Node to store imported data"),
    @Property(name = "export.location", label = "Export Location", unbounded = PropertyUnbounded.DEFAULT),
    @Property(name = "import.location", label = "Import Location", unbounded = PropertyUnbounded.DEFAULT)
})
public class SAMMSDataService {

    private static final Logger log = LoggerFactory.getLogger(SAMMSDataService.class);

    @Reference
    ResourceResolverFactory resolverFactory;
    private String sammsDataNodePath;
    private String exportLocation;
    private String importLocation;

    public void importData(String dataFileLocation) {
        ResourceResolver resolver = null;
        try {
            resolver = resolverFactory.getAdministrativeResourceResolver(null);
            // This prevents some workflows from triggering
            resolver.adaptTo(Session.class).getWorkspace().getObservationManager().setUserData("changedByWorkflowProcess");
            ImportForSAMMS importer = new ImportForSAMMS(resolver, dataFileLocation, sammsDataNodePath);
            Collection<SAMMSData> data = importer.runImport();
            updateAssetsAffectedByImport(data, resolver);
        } catch (LoginException e) {
            log.error("Cannot get admin resolver");
        } catch (RepositoryException ex) {
            log.error("Cannot update workspace user data");
        } finally {
            if (resolver != null && resolver.isLive()) {
                resolver.close();
            }
        }
    }

    public void importData() {
        importData(this.importLocation);
    }

    public void applyDataToAssets() {
        ResourceResolver resolver = null;
        int updatedAssets = 0;
        try {
            resolver = resolverFactory.getAdministrativeResourceResolver(null);
            Session session = resolver.adaptTo(Session.class);
            Node sammsNode = resolver.getResource(sammsDataNodePath).adaptTo(Node.class);

            //Get Styles
            NodeIterator styleNodes = sammsNode.getNodes();
            while (styleNodes.hasNext()) {
                Node styleNode = styleNodes.nextNode();
                String styleNumber = styleNode.getName().toUpperCase();

                //Get color codes
                NodeIterator colorNodes = styleNode.getNodes();
                while (colorNodes.hasNext()) {
                    Node colorNode = colorNodes.nextNode();
                    String colorCode = colorNode.getName().toUpperCase();

                    //Get graphic codes
                    NodeIterator graphicNodes = colorNode.getNodes();
                    while (graphicNodes.hasNext()) {
                        Node graphicNode = graphicNodes.nextNode();
                        String graphicCode = graphicNode.getName().toUpperCase();
                        updatedAssets += updateNodesByStyleColorGraphic(styleNumber, colorCode, graphicCode, resolver);
                    }
                }
            }

            log.info("Updated metadata for " + updatedAssets + " assets");
        } catch (LoginException e) {
            log.error("Cannot login as admin. " + e.getMessage());
        } catch (RepositoryException e) {
            log.error("Error accessing repository. " + e.getMessage());
        } finally {
            if (resolver != null && resolver.isLive()) {
                resolver.close();
            }
        }
    }

    private int updateAssetsAffectedByImport(Collection<SAMMSData> importedData, ResourceResolver resolver) {
        int total = 0;
        for (SAMMSData data : importedData) {
            try {
                total += updateNodesByStyleColorGraphic(
                        data.getStyleNumber().toUpperCase(),
                        data.getColorCode().toUpperCase(),
                        data.getGraphicNumber().toUpperCase(),
                        resolver);
            } catch (LoginException e) {
                log.error("Unable to update nodes for " + data.getStyleNumber() + ";" + data.getColorCode() + ";" + data.getGraphicNumber(), e.getMessage());
            } catch (RepositoryException e) {
                log.error("Unable to update nodes for " + data.getStyleNumber() + ";" + data.getColorCode() + ";" + data.getGraphicNumber(), e.getMessage());
            }
        }
        log.info("Finished applying metadata for "+total+" nodes.");
        return total;
    }

    private int updateNodesByStyleColorGraphic(String styleNumber, String colorCode, String graphicCode, ResourceResolver resolver) throws LoginException, RepositoryException {
        int count = 0;
        log.info("Applying metadata for " + styleNumber + "|" + colorCode + "|" + graphicCode);
        HashMap<String, String> props = getPropertiesForKey(styleNumber, colorCode, graphicCode);
        //Get all nodes for this style/color/graphic
        NodeIterator matchingNodes = getAllNodesForKey(styleNumber, colorCode, graphicCode, resolver);
        while (matchingNodes.hasNext()) {
            Node matchedNode = matchingNodes.nextNode();
            try {
                updateNodeProperties(matchedNode, props);
                resolver.commit();
                count++;
            } catch (RepositoryException e) {
                log.error("Unable to update " + matchedNode.getPath() + ". " + e.getMessage());
            } catch (PersistenceException e) {
                log.error("Unable to update " + matchedNode.getPath() + ". " + e.getMessage());
            }
        }
        return count;
    }

    public void updateNodeProperties(Node matchedNode, HashMap<String, String> props) throws RepositoryException {
        Node metadataNode = matchedNode.getNode("jcr:content/metadata");
        log.info("Updating " + matchedNode.getPath());
        //save properties to metadata node for the asset
        for (Map.Entry<String, String> prop : props.entrySet()) {
            String propName = prop.getKey();
            String propValue = prop.getValue().equals("") ? null : prop.getValue();
            log.debug("Prop - " + propName + ": " + propValue);
            metadataNode.setProperty(propName, propValue);
        }
        log.debug("Saving updated asset");
    }

    private NodeIterator getAllNodesForKey(String style, String color, String graphic, ResourceResolver resolver) throws RepositoryException {
        Session session = resolver.adaptTo(Session.class);
        ValueFactory vf = session.getValueFactory();

        String relStyleProp = "jcr:content/metadata/" + SLDConstants.STYLE_NUMBER;
        String relColorProp = "jcr:content/metadata/" + SLDConstants.COLOR_CODE;
        String relGraphicProp = "jcr:content/metadata/" + SLDConstants.GRAPHIC_CODE;

        String sqlStatement = "SELECT * FROM [dam:Asset] WHERE ISDESCENDANTNODE([/content/dam]) AND "
                + "[" + relStyleProp + "] = $style AND "
                + "[" + relColorProp + "] = $color AND "
                + "[" + relGraphicProp + "] = $graphic";
        QueryManager queryManager = session.getWorkspace().getQueryManager();
        Query query = queryManager.createQuery(sqlStatement, Query.JCR_SQL2);

        query.bindValue("style", vf.createValue(style.toUpperCase()));
        query.bindValue("color", vf.createValue(color.toUpperCase()));
        query.bindValue("graphic", vf.createValue(graphic.toUpperCase()));

        QueryResult result = query.execute();

        return result.getNodes();

    }

    protected void activate(ComponentContext componentContext) {
        Dictionary<?, ?> props = componentContext.getProperties();
        this.sammsDataNodePath = PropertiesUtil.toString(props.get("samms.data.node"), "/content/appdata/samms");
        this.exportLocation = PropertiesUtil.toString(props.get("export.location"), null);
        this.importLocation = PropertiesUtil.toString(props.get("import.location"), null);
    }

    /**
     *
     * @param styleNumber
     * @param colorCode
     * @param graphicCode
     * @return a map of property names and their values
     * @throws LoginException
     */
    public HashMap<String, String> getPropertiesForKey(String styleNumber, String colorCode, String graphicCode) throws LoginException {
        HashMap<String, String> props = new HashMap<String, String>();
        ResourceResolver resolver = resolverFactory.getAdministrativeResourceResolver(null);
        Resource dataRes = resolver.getResource(sammsDataNodePath + "/" + styleNumber + "/" + colorCode + "/" + graphicCode);
        if (dataRes == null) {
            log.info("No matching data for " + styleNumber + "|" + colorCode + "|" + graphicCode);
        } else {
            Node dataNode = dataRes.adaptTo(Node.class);
            if (dataNode != null) {
                try {
                    PropertyIterator properties = dataNode.getProperties();
                    while (properties.hasNext()) {
                        javax.jcr.Property prop = properties.nextProperty();
                        if (!prop.getName().startsWith("jcr:")) {
                            props.put(prop.getName(), prop.getString());
                        }
                    }
                } catch (RepositoryException e) {
                    log.error("Cannot access properties. " + e.getMessage(), e);
                }
            }
        }
        return props;
    }

    public void exportData(String exportPath, boolean exportAllAssets) {
        ResourceResolver resolver = null;

        try {
            resolver = resolverFactory.getAdministrativeResourceResolver(null);
            if (exportPath != null) {
                ExportForSAMMS.exportSAMMSData(exportPath, resolver, exportAllAssets);
            }
        } catch (LoginException e) {
            log.error("Cannot export data " + e.getMessage(), e);
        } finally {
            if (resolver != null && resolver.isLive()) {
                resolver.close();
            }
        }
    }

    public void exportData(boolean exportAllAssets) {
        exportData(this.exportLocation, exportAllAssets);
    }
}
