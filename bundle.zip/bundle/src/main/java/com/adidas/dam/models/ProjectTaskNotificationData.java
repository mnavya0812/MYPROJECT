package com.adidas.dam.models;

public class ProjectTaskNotificationData {
	
	String title = "";
	String assetCount = "";
	String projectName = "";
	String assignee = "";
	String priority = "";
	String priorityDueDate = "";
	String league = "";
	String artist = "";
	
	public ProjectTaskNotificationData(String projectName, String priority, 
			String priorityDueDate, String assignee, long assetcount) {
		
		this.projectName = projectName;
		this.priority = priority;
		this.priorityDueDate = priorityDueDate;
		this.assignee = assignee;
		this.assetCount = String.valueOf(assetcount);
	}
	
	public ProjectTaskNotificationData() {}

	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getAssetCount() {
		return assetCount;
	}
	
	public void setAssetCount(long assetCount) {
		this.assetCount = String.valueOf(assetCount);
	}

	public String getAssignee() {
		return assignee;
	}
	
	public void setAssignee(String assignee) {
		this.assignee = assignee; 
	}
	
	public String getPriority() {
		return priority;
	}
	
	public void setPriority(String priority) {
		this.priority = priority;
	}
	
	public String getPriorityDueDate() {
		return priorityDueDate;
	}
	
	public void setPriorityDueDate(String priorityDueDate) {
		this.priorityDueDate = priorityDueDate;
	}
	
	public String getLeague() {
		return league;
	}
	
	public void setLeague(String league) {
		this.league = league;
	}
	
	
	public String getArtist() {
		return artist;
	}
	
	public void setArtist(String artist) {
		this.artist = artist;
	}
}
