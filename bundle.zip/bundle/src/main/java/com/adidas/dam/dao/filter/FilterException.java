package com.adidas.dam.dao.filter;

public class FilterException extends RuntimeException {

	private static final long serialVersionUID = 317608894381019981L;

	public FilterException(Exception e) {
		super(e);
	}
}
