package com.adidas.dam.workflows;

import com.adidas.dam.util.Helper;
import com.adidas.dam.util.SLDConstants;
import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.exec.WorkflowProcess;
import com.day.cq.workflow.metadata.MetaDataMap;
import org.apache.felix.scr.annotations.*;
import org.apache.jackrabbit.api.JackrabbitSession;
import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.jackrabbit.api.security.user.UserManager;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.framework.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.*;
import java.util.Collections;

@Component(metatype=true)
@Service
@Properties({
        @org.apache.felix.scr.annotations.Property(name = Constants.SERVICE_DESCRIPTION, value = "Adidas - Add User Info to Metadata"),
        @org.apache.felix.scr.annotations.Property(name = Constants.SERVICE_VENDOR, value = "3|Share"),
        @org.apache.felix.scr.annotations.Property(name = "process.label",value="Adidas Add User Info to Metadata",propertyPrivate = true)
})
public class AddUserMetadata implements WorkflowProcess{

    private static final Logger log = LoggerFactory.getLogger(AddUserMetadata.class);

    @Reference
    ResourceResolverFactory resolverFactory;

    @Override
    public void execute(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap metaDataMap) throws WorkflowException {

        Session session = workflowSession.getSession();
        ResourceResolver resolver = null;
        try {
            resolver = resolverFactory.getResourceResolver(Collections.singletonMap("user.jcr.session",(Object)workflowSession.getSession()));
            Resource payloadResource = Helper.getResourceFromPayload(workItem, session, resolver);
            Node metadataNode = payloadResource.adaptTo(Node.class).getNode("jcr:content/metadata");

            //get user. lastModeUser = art document creator
            String lastModUser = metadataNode.hasProperty(SLDConstants.ART_DOC_EDITOR) ? metadataNode.getProperty(SLDConstants.ART_DOC_EDITOR).getString() : null;

            if (lastModUser == null || lastModUser.equals("admin")) {
                Node originalNode = payloadResource.adaptTo(Node.class).getNode("jcr:content/renditions/original/jcr:content");
                lastModUser = originalNode.hasProperty(SLDConstants.ASSET_LASTMOD_BY) ? originalNode.getProperty(SLDConstants.ASSET_LASTMOD_BY).getString() : null;
                log.debug("Setting Art Document Editor: " + lastModUser);
                metadataNode.setProperty(SLDConstants.ART_DOC_EDITOR,lastModUser);
                metadataNode.getSession().save();
                resolver.refresh();
            }

            if (lastModUser != null) {
                UserManager userManager = ((JackrabbitSession) session).getUserManager();
                Authorizable authorizable = userManager.getAuthorizable(lastModUser);
                String location = "";
                String department = "";
                if (authorizable == null) {
                    log.error("Unable to find User with id '" + lastModUser + "'");
                    return;
                }
                if (!authorizable.isGroup() && authorizable.hasProperty("profile/department")) {

                    Value[] departmentVals = authorizable.getProperty("profile/department");
                    if (departmentVals.length > 0) {
                        department = departmentVals[0].getString();
                    }

                    String principal = authorizable.getPrincipal().getName();
                    String[] tokens = principal.split(",");
                    for (String token : tokens) {
                        if (token.startsWith("OU")) {
                            String[] ou = token.split("=");
                            location = ou[1];
                            break;
                        }
                    }
                }

                log.debug("Department: " + department);
                log.debug("Location: " + location);

                metadataNode.setProperty(SLDConstants.ART_DOC_EDITOR_DEPT,department);
                metadataNode.setProperty(SLDConstants.ART_DOC_EDITOR_LOC,location);

                session.save();

            }

        } catch (LoginException e) {
            log.error("Unable to get resolver. " + e.getMessage());
        } catch (PathNotFoundException e) {
            log.error("Cannot find path. " + e.getMessage());
        } catch (RepositoryException e) {
            log.error("Unable to access node. " + e.getMessage() );
        }

    }
}
