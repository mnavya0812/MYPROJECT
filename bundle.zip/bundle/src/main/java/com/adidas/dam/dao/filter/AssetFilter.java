package com.adidas.dam.dao.filter;

import java.util.Arrays;

import org.apache.sling.api.resource.Resource;

public class AssetFilter implements DamDAOFilter {
	
	private PrimaryTypeFilter primaryTypeFilter;
	
	public AssetFilter() {
		this.primaryTypeFilter = new PrimaryTypeFilter(Arrays.asList("dam:Asset"));
	}

	@Override
	public boolean matches(Resource resource) {
		return this.primaryTypeFilter.matches(resource);
	}

}
