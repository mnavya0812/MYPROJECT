package com.adidas.dam.dao.filter;

import javax.jcr.RepositoryException;

import org.apache.sling.api.resource.Resource;

public class NonCoverImageFilter implements DamDAOFilter {

	@Override
	public boolean matches(Resource resource) {
		try {
			return (!isCoverImage(resource));
		} catch (Exception e) {
			throw new FilterException(e);
		}
	}
	
	private boolean isCoverImage(Resource resource) throws RepositoryException {
		return resource.getName().endsWith("cover");
	}
}
