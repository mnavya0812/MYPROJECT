package com.adidas.dam.servlets;

import com.adidas.dam.services.ILUExportService;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import javax.servlet.ServletException;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.request.RequestParameter;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;

@SlingServlet(paths="/bin/iluexport", methods = "GET", metatype=true)
public class ILUServlet extends SlingAllMethodsServlet {

    @Reference
    ILUExportService iluExportService;

    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {

        PrintWriter out = response.getWriter();

        RequestParameter cmd = request.getRequestParameter("cmd");
        response.setContentType("text/html");

        if ( cmd != null) {

            if (cmd.getString().equals("export") ) {
                out.println(iluExportService.exportLastWeeksAssets());

            }

        }

        out.println("<h1>Export ILU Data</h1>");
        out.println("<form method='get'>");
        out.println("<input type='hidden' name='cmd' value='export'/>");
        out.println("<button type='submit'>Submit</button>");
        out.println("</form>");

        SimpleDateFormat week = new SimpleDateFormat("YYYY/ww");
        Calendar now = Calendar.getInstance();

        out.println("<pre>");
        now.setFirstDayOfWeek(Calendar.SUNDAY);
        out.println("First day of week: " + now.getFirstDayOfWeek());
        out.println("Days in week: " );

        now.set(2015,Calendar.NOVEMBER,22,1,0);
        out.println("Sunday 11/22: " + now.toString());
        out.println("Week: " + week.format(now.getTime()));

        now.set(2015, Calendar.NOVEMBER,21,1,0);
        out.println("Saturday 11/21: " + now.toString());
        out.println("Week: " + week.format(now.getTime()));

        now.set(2015, Calendar.JANUARY,1,1,0);
        out.println("Jan 1, 2015: " + now.toString());
        out.println("Week: " + week.format(now.getTime()));

        now.set(2014, Calendar.DECEMBER,31,1,0);
        out.println("Dec 31, 2014: " + now.toString());
        out.println("Week: " + week.format(now.getTime()));

        out.println("</pre>");

    }
}
