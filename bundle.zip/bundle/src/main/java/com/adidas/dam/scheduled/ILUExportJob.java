package com.adidas.dam.scheduled;

import com.adidas.dam.services.ILUExportService;
import org.apache.felix.scr.annotations.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

@Component(label = "Adidas Inventory Lookup Tool Export Scheduled Job",immediate = true, enabled = true, metatype = true, policy = ConfigurationPolicy.REQUIRE)
@Service(ILUExportJob.class)
@Properties({
        @Property(name = "scheduler.expression", label = "Cron Expression",
                description = "Provide cron expression for the time you want to reschedule ILU Export.",
                value = "0 15 2 ? * SUN")
})
public class ILUExportJob implements Runnable {

    private static final Logger log = LoggerFactory.getLogger(ILUExportJob.class);

    @Reference
    ILUExportService iluExportService;

    @Override
    public void run() {
        String[] runModes = System.getProperty("sling.run.modes").split(",");
        List<String> runModesList = Arrays.asList(runModes);
        if (!runModesList.contains("author") || runModesList.contains("offload")) {
            log.info("Runs on primary author only");
            return; //Not author, so exit
        }
        log.info("Export started");
        Calendar startTime = Calendar.getInstance();
        iluExportService.exportLastWeeksAssets();
        Calendar endTime = Calendar.getInstance();
        long elapsedMills = endTime.getTime().getTime() - startTime.getTime().getTime();
        log.info("Completed in " + (elapsedMills/1000.0) + " seconds");
    }
}
