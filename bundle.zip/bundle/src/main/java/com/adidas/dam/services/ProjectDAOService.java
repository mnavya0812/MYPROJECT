package com.adidas.dam.services;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;

import com.adidas.dam.hotFolder.HotFolderConfiguration;

public interface ProjectDAOService {
	public Resource getHotfolderProject(ResourceResolver resourceResolver, String hotfolderPath);
	public void createHotFolderProject(ResourceResolver resourceResolver, HotFolderConfiguration config, String userName, String userPassword);
}
