package com.adidas.dam.services;

import org.apache.poi.ss.usermodel.Workbook;

public interface AssetCheckService {
	
	

	public Workbook checkAssets() throws Exception;
}