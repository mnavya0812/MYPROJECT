package com.adidas.dam.hotFolder;

import java.util.HashMap;

/**
 * Configuration object for hot folders
 */
public class HotFolderConfiguration {

    private String path;
    private String name;
    private String priority;
    private String diFolderType;
    private String league;
    private String brand;
    private String artDocumentType;
    private HashMap<String,String> defaultMetadata = new HashMap<String, String>();
    private String proofingGroup;

    public HotFolderConfiguration(){

    }

    public void addDefaultMetadata(String metadataField, String value){
        defaultMetadata.put(metadataField,value);
    }

    public HashMap<String,String> getDefaultMetadata(){
        return this.defaultMetadata;
    }


    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getDiFolderType() {
        return diFolderType;
    }

    public void setDiFolderType(String diFolderType) {
        this.diFolderType = diFolderType;
    }

    public String getLeague() {
        return league;
    }

    public void setLeague(String league) {
        this.league = league;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getArtDocumentType() {
        return artDocumentType;
    }

    public void setArtDocumentType(String artDocumentType) {
        this.artDocumentType = artDocumentType;
    }

    public String getProofingGroup() {
        return proofingGroup;
    }

    public void setProofingGroup(String proofingGroup) {
        this.proofingGroup = proofingGroup;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
