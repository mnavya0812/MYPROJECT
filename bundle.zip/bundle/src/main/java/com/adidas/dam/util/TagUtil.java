package com.adidas.dam.util;

import com.adobe.acs.uncommons.functions.Consumer;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TagUtil {

    private static final Logger log = LoggerFactory.getLogger(TagUtil.class);

    /**
     *
     * @param tagRootPath Tag path to search under for the tag
     * @param value Title of the tag to find
     * @param resolver resolver with access to read and create tags
     * @param createTag true if the tag should be created. If false, the tag will not be created, but an value will be returned
     * @return a tag id (namespace:tag/value)
     */
    public static String findTagIDByTitle(String tagRootPath, String value, ResourceResolver resolver, boolean createTag) {
        try {
            QueryManager queryManager = resolver.adaptTo(Session.class).getWorkspace().getQueryManager();
            String sql = "SELECT * FROM [cq:Tag] WHERE ISDESCENDANTNODE([" + tagRootPath + "]) and [jcr:title] LIKE '" + value + "'";
            Query query = queryManager.createQuery(sql,Query.JCR_SQL2);
            QueryResult result = query.execute();

            NodeIterator nodes = result.getNodes();

            if (nodes.getSize() <= 0 && createTag) {
                String tagPath = TagUtil.createTag(tagRootPath,value,resolver);
                return TagUtil.convertTagPathToId(tagPath);
            } else {
                // only get the first result. If more than one, something isn't right
                Node tagNode = nodes.nextNode();
                String tagPath = tagNode.getPath();
                return TagUtil.convertTagPathToId(tagPath);
            }
        } catch (RepositoryException e) {
            log.error("Cannot query for tag. " + e.getMessage());
        }

        log.warn("Tag not found or created for " + value + " under " + tagRootPath);
        return TagUtil.convertTagPathToId(tagRootPath + "/" + value);
    }

    /**
     * Makes sure a tag exists at a given path
     * @param tagRootPath root path the tag should exist in (e.g., /etc/tags/geometrixx)
     * @param tagName relPath of the tag
     * @param resolver resolver that can read and create the tag
     * @return tagId of the tag
     */
    public static String ensureTagExists(String tagRootPath, String tagName, ResourceResolver resolver) {
        Resource tagRes = resolver.getResource(tagRootPath + "/" + tagName);
        String tagPath;
        if (tagRes == null) {
            tagPath = createTag(tagRootPath,tagName,resolver);
        } else {
            tagPath = tagRes.getPath();
        }

        return TagUtil.convertTagPathToId( tagPath );
    }

    public static String convertTagPathToId(String tagPath) {
        return tagPath.replace("/etc/tags/","").replaceFirst("/",":");
    }

    /**
     *
     * @param tagRootPath root path to create the tag under(e.g., /etc/tags/geometrixx)
     * @param value Title of the tag to create
     * @param resolver resolver used to get the tag
     * @return path to new tag
     */
    public static String createTag(String tagRootPath, String value, ResourceResolver resolver) {
        String tagName = value.toLowerCase().replaceAll("[^a-z0-9-]","-");
        Resource tagRes = resolver.getResource(tagRootPath);

        if (tagRes != null) {
            Node tagRoot = tagRes.adaptTo(Node.class);
            try {
                Node newTagNode = tagRoot.getNode(tagName);
                return newTagNode.getPath();
            } catch (RepositoryException e) {
                log.debug("Tag does not exist. Creating. " + e.getMessage());
                try {
                    Node newTag = tagRoot.addNode(tagName,"cq:Tag");
                    newTag.setProperty("jcr:title",value);
                    newTag.setProperty("sling:resourceType","cq/tagging/components/tag");
                    resolver.commit();
                    return newTag.getPath();
                } catch (RepositoryException ex) {
                    log.error("Cannot create tag. " + ex.getMessage());
                } catch (PersistenceException ex) {
                    log.error("Cannot save new tag. " + ex.getMessage());
                }
            }
        }

        return tagRootPath + "/" + tagName;
    }
    
    public static Consumer<ResourceResolver> rename(final String tagId, final String newName) {
        return new Consumer<ResourceResolver>() {
            @Override
            public void accept(ResourceResolver resolver) throws Exception {
                TagManager tm = resolver.adaptTo(TagManager.class);
                Tag tag = tm.resolve(tagId);
                if (tag != null) {
                    Node tagNode = tag.adaptTo(Node.class);
                    tagNode.setProperty("jcr:title", newName);
                    resolver.commit();
                    resolver.refresh();
                } else {
                    throw new RepositoryException("Tag doesn't exist; "+tagId);
                }
            }
        };
    }
    
    public static Consumer<ResourceResolver> merge(final String tagIdFrom, final String tagIdTo) {
        return new Consumer<ResourceResolver>() {
            @Override
            public void accept(ResourceResolver resolver) throws Exception {
                TagManager tm = resolver.adaptTo(TagManager.class);
                Tag from = tm.resolve(tagIdFrom);
                Tag to = tm.resolve(tagIdTo);
                if (from != null && to != null) {
                    tm.mergeTag(from, to);
                    resolver.commit();
                    resolver.refresh();
                } else {
                    throw new RepositoryException("Source and destination tags should both exist; "+tagIdFrom+";"+tagIdTo);
                }
            }
        };
    }

}
