package com.adidas.dam.workflows.cleanup;



import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.exec.WorkflowProcess;
import com.day.cq.workflow.metadata.MetaDataMap;
import java.util.Collections;


import javax.jcr.Node;
import javax.jcr.RepositoryException;
import org.apache.felix.scr.annotations.*;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.framework.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(description = "Adidas Asset pdf Rendition rename/cleanup process Step", metatype = true, immediate = true, enabled = true)
@Service
@Properties({
        @Property(name = Constants.SERVICE_DESCRIPTION, value = "Adidas Asset pdf Rendition rename/cleanup process Step"),
        @Property(name = Constants.SERVICE_VENDOR, value = "Adobe"),
        @Property(name = "process.label",value="Adidas Asset pdf Rendition rename process Step",propertyPrivate = true)
})
public class AssetsRenditionRenameProcess implements WorkflowProcess {

	@Reference
    ResourceResolverFactory resolverFactory;

    private Logger log = LoggerFactory.getLogger(AssetsRenditionRenameProcess.class);
    public static final String RENDITION_PATH_PREFIX = "/jcr:content/renditions/";

    @Override
    public void execute(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap metaDataMap) throws WorkflowException {
        ResourceResolver resolver = null; 
       
        
        try {
            resolver = resolverFactory.getResourceResolver(Collections.singletonMap("user.jcr.session",(Object)workflowSession.getSession()));
            String payloadPath = workItem.getWorkflowData().getPayload().toString();
           
            log.info("Asset rendition rename/cleanup started on payload::::" + payloadPath);
            Node assetNode = resolver.getResource(payloadPath).adaptTo(Node.class);
            
            String assetNameExcludingExtention = assetNode.getName().substring(0, assetNode.getName().indexOf('.')); 
            String assetExtention = assetNode.getName().substring(assetNode.getName().indexOf('.')+1, assetNode.getName().length());
            
           if(assetExtention.equalsIgnoreCase("ai") || assetExtention.equalsIgnoreCase("eps")){
            
        	String wrongPdfRenditionName = assetNameExcludingExtention.substring(0,assetNameExcludingExtention.length()-1)+".pdf";
            String correctPdfRenditionName =  assetNameExcludingExtention+".pdf";          
                        
            if (assetExtention.equalsIgnoreCase("ai")){
            	correctWrongPdfRenditionName(resolver ,payloadPath, wrongPdfRenditionName,correctPdfRenditionName);
            } else if(assetExtention.equalsIgnoreCase("eps")){        	
            	removeRendition(resolver ,payloadPath,wrongPdfRenditionName); 
            	removeRendition(resolver ,payloadPath,correctPdfRenditionName); 
            	
            }
            workflowSession.getSession().save();          
            log.info("Asset rendition rename/cleanup finished for "+payloadPath);
           }
           
        } catch (RepositoryException e) {
            log.error("Unable to access  rendition node. " + e.getMessage());
        } catch (LoginException e) {
            log.error("Unable to login. " + e.getMessage());
        }
        
        
    }
    
   
    
    void correctWrongPdfRenditionName(ResourceResolver resolver, String payloadPath , String wrongPdfRenditionName ,String correctPdfRenditionName)throws RepositoryException{
    	 
    	String fullRenditionPath = payloadPath+RENDITION_PATH_PREFIX;
    	
    	if(resolver.getResource(fullRenditionPath+wrongPdfRenditionName) != null && resolver.getResource(fullRenditionPath+correctPdfRenditionName) == null){
    		 Node wrongPdfRenditionAssetNode = resolver.getResource(fullRenditionPath+wrongPdfRenditionName).adaptTo(Node.class);
    		 log.info("Correcting wrong pdf rendition for :  "+fullRenditionPath+wrongPdfRenditionName);
    	     rename(wrongPdfRenditionAssetNode,correctPdfRenditionName);	
    	 }else if (resolver.getResource(fullRenditionPath+wrongPdfRenditionName) != null && resolver.getResource(fullRenditionPath+correctPdfRenditionName) != null){
    		 removeRendition(resolver,payloadPath,wrongPdfRenditionName); 
    	 }
    }
    
    void removeRendition(ResourceResolver resolver, String payloadPath , String renditionName) throws RepositoryException{
    	String fullRenditionPath = payloadPath+RENDITION_PATH_PREFIX;
    	if(resolver.getResource(fullRenditionPath+renditionName) != null ){
    		Node renditionAssetNode = resolver.getResource(fullRenditionPath+renditionName).adaptTo(Node.class); 
    		log.info("Removing rendition for :  "+ fullRenditionPath+renditionName);
    		renditionAssetNode.remove();
    		
    	}
    }
    
    void rename(Node node, String newName) throws RepositoryException 
    {
     
    	node.getSession().move(node.getPath(), node.getParent().getPath() + "/" + newName);       
       
    }
}
