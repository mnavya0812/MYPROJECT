package com.adidas.dam.dao.jcr;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import javax.jcr.RepositoryException;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;

import com.adidas.dam.dao.filter.DamDAOFilter;
import com.adidas.dam.dao.filter.PrimaryTypeFilter;

public class NodeRetriever {
	
	private ResourceResolver resourceResolver;
	private PrimaryTypeFilter folderFilter;
	private List<DamDAOFilter> filters;

	//When searching, an AND comparison will be made across filters to return only results that match all specified filters
	public NodeRetriever(ResourceResolver resourceResolver, List<DamDAOFilter> filters) {
		this.resourceResolver = resourceResolver;
		folderFilter = new PrimaryTypeFilter(Arrays.asList("sling:OrderedFolder","sling:Folder"));
		this.filters = filters;
	}
	
	public List<Resource> getResourcesDeep(String path) throws RepositoryException {
		resourceResolver.refresh();
		Resource pathResource = resourceResolver.resolve(path);
		return getChildren(pathResource);
	}
	
	private List<Resource> getChildren(Resource parentResource) throws RepositoryException {
		List<Resource> children = new ArrayList<Resource>();
		
		Iterator<Resource> parentIterator = parentResource.listChildren();
		
		while (parentIterator.hasNext()) {
			Resource currResource = parentIterator.next();
			
			if (folderFilter.matches(currResource)) {
				children.addAll(getChildren(currResource));
			} else if (filtersMatch(currResource)){
				children.add(currResource);
			}
		}
		
		return children;
	}
	
	private boolean filtersMatch(Resource resource) {
		boolean filtersMatch = true;
		
		for (DamDAOFilter filter:filters) {
			if (!filter.matches(resource)) {
				filtersMatch = false;
			}
		}
		
		return filtersMatch;
	}
}
