package com.adidas.dam.servlets;

import com.adidas.dam.services.SAMMSDataService;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.request.RequestParameter;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;

import javax.servlet.ServletException;
import java.io.IOException;
import java.io.PrintWriter;

@SlingServlet(paths="/bin/samms", methods = "GET", metatype=true)
public class SAMMSServlet extends SlingAllMethodsServlet {

    @Reference
    SAMMSDataService sammsDataService;

    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();

        RequestParameter cmd = request.getRequestParameter("cmd");
        response.setContentType("text/html");

        if ( cmd != null) {
            if ( cmd.getString().equals("import") ) {
                RequestParameter importPath = request.getRequestParameter("importPath");
                if (importPath != null) {
                    String importPathString = importPath.getString();
                    sammsDataService.importData(importPathString);
                    out.println("Data Imported");
                }

            } else if (cmd.getString().equals("export") ) {
                RequestParameter exportPath = request.getRequestParameter("exportPath");
                RequestParameter exportAllAssets = request.getRequestParameter("exportAll");

                if (exportPath != null) {
                    sammsDataService.exportData(exportPath.getString(), exportAllAssets != null);
                    out.println("Exported data to " + exportPath.getString());
                }

            } else if (cmd.getString().equals("applyMetadata")) {
                sammsDataService.applyDataToAssets();
                out.println("Metadata applied to assets.");
            }

        }

        out.println("<h1>Import Data</h1>");
        out.println("<form method='get'>");
        out.println("<input type='hidden' name='cmd' value='import'/>");
        out.println("Import File location: <input type='text' name='importPath' value=''/><br/>");
        out.println("<button type='submit'>Submit</button>");
        out.println("</form>");

        out.println("<h1>Apply Metadata</h1>");
        out.println("<form method='get'>");
        out.println("<input type='hidden' name='cmd' value='applyMetadata'/>");
        out.println("<button type='submit'>Submit</button>");
        out.println("</form>");

        out.println("<h1>Export Data</h1>");
        out.println("<form method='get'>");
        out.println("<input type='hidden' name='cmd' value='export'/>");
        out.println("Export location: <input type='text' name='exportPath' value=''/><br/>");
        out.println("Export All assets (ignore last update date): <input type='checkbox' name='exportAll' value='true'/><br/>");
        out.println("<button type='submit'>Submit</button>");
        out.println("</form>");

    }
}
