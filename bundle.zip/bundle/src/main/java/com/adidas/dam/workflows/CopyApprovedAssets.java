package com.adidas.dam.workflows;

import java.util.Iterator;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.osgi.framework.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adidas.dam.dao.ProjectAssetsDAO;
import com.adidas.dam.services.ViprSoapService;
import com.adidas.dam.util.Helper;
import com.adidas.dam.util.SLDConstants;
import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.AssetManager;
import com.day.cq.replication.ReplicationActionType;
import com.day.cq.replication.Replicator;
import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.exec.WorkflowProcess;
import com.day.cq.workflow.metadata.MetaDataMap;

/**
 * @author Pravin Bathija
 * @modified JN: copy approved assets to weekly/confidential/neutrals folders
 * send rejected assets to VIPR service (SOAP)
 *
 */
@Component
@Service
@Properties({
    @Property(name = Constants.SERVICE_DESCRIPTION, value = "Adidas Copy Approved or Rejected Assets", propertyPrivate = true),
    @Property(name = Constants.SERVICE_VENDOR, value = "3|Share"),
    @Property(name = "process.label", value = "Adidas Copy Approved or Rejected Assets", propertyPrivate = true)})

public class CopyApprovedAssets implements WorkflowProcess {

    private static final Logger LOG = LoggerFactory.getLogger(CopyApprovedAssets.class);
    private ProjectAssetsDAO projectAssetsDao = new ProjectAssetsDAO();

    @Reference
    ResourceResolverFactory resourceResolverFactory;

    @Reference
    Replicator replicator;

    @Reference
    ViprSoapService viprSoapService;

    public void execute(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap metaDataMap) throws WorkflowException {

        Session session = workflowSession.getSession();
        ResourceResolver resolver = null;
        String projectPath = "";
        LOG.debug("In Copy Approved Asset workflow process");
      
        try {
            resolver = resourceResolverFactory.getAdministrativeResourceResolver(null);
        } catch (LoginException e) {
            LOG.error("err in CopyApprovedAssets.execute -->" + e.getMessage(), e);
        }

        // get the resource from the payload
        Resource payloadResource = Helper.getResourceFromPayload(workItem, session, resolver);
        if (payloadResource != null) {
            MetaDataMap workflowMetaDataMap = workItem.getWorkflow().getWorkflowData().getMetaDataMap();
            projectPath = workflowMetaDataMap.get("projectPath").toString();
            String destPath = "";

            Iterator<Resource> allResources = Helper.getProjectAssetsSelection4Proofing(resolver, projectPath);

            // if no assets to review/approve then exit
            if (null == allResources) {
            	 LOG.debug("In Copy Approved Asset workflow process :: No asset found");
                return;
            }

            AssetManager assetManager = resolver.adaptTo(AssetManager.class);

            while (allResources.hasNext()) {
                Resource assetResource = allResources.next();

                try {
                    Asset asset = assetResource.adaptTo(Asset.class);
                    Resource metadataResource = assetResource.getChild(SLDConstants.ASSET_JCR_METADATA);
                    Node metadataNode = assetResource.adaptTo(Node.class).getNode(SLDConstants.ASSET_JCR_METADATA);
                    ModifiableValueMap map = metadataResource.adaptTo(ModifiableValueMap.class);

                    // Check if property exist 
                    if (metadataNode.hasProperty(SLDConstants.DAM_STATUS) && metadataNode.hasProperty(SLDConstants.DI_PROPS_FOLDER)) {

                        // Move only approved assets
                        if (map.get(SLDConstants.DAM_STATUS).toString().equalsIgnoreCase(SLDConstants.DAM_STATUS_APPROVE)) {
                            // confidential images
                            if ((map.get(SLDConstants.DI_PROPS_FOLDER).toString().equalsIgnoreCase(SLDConstants.DI_CONFIDENTIAL))
                                    || (metadataNode.hasProperty(SLDConstants.DI_CONFIDENTIAL)
                                    && map.get(SLDConstants.DI_CONFIDENTIAL).toString().equalsIgnoreCase("yes"))) {

                                destPath = Helper.getDiFolderPath(resolver, SLDConstants.DI_CONFIDENTIAL);
                            } // neutral images
                            else if (map.get(SLDConstants.DI_PROPS_FOLDER).toString().equalsIgnoreCase(SLDConstants.DI_NEUTRALS)) {
                                destPath = Helper.getDiFolderPath(resolver, SLDConstants.DI_NEUTRALS);
                            } // weekly images
                            else {
                                destPath = Helper.getWeekofYearPath(resolver);
                            }

                            try {
                                // Add drm/eula/restrictions to asset metadata when asset is approved
                                if (!metadataNode.hasProperty(SLDConstants.ASSET_DRM)) {
                                    map.put(SLDConstants.ASSET_DRM, SLDConstants.ASSET_DRM_PATH + ".html");
                                    Resource rex = resolver.getResource(SLDConstants.ASSET_DRM_PATH + "/jcr:content/par/text");
                                    String eulaText = (String) rex.adaptTo(ValueMap.class).get("text");
                                    map.put(SLDConstants.ASSET_DRM_RESTRICT, eulaText);
                                }
                            } catch (RepositoryException rex) {
                                LOG.error("DRM EULA exception", rex);
                            }

                            try {

                                String destinationAssetPath = destPath + "/" + assetResource.getName();
                                projectAssetsDao.moveAsset(resolver, asset, destinationAssetPath);

                                LOG.info("Activating " + destinationAssetPath);
                                replicator.replicate(session, ReplicationActionType.ACTIVATE, destinationAssetPath);

                            } catch (Exception rex) {
                                LOG.error("Move Approved assets Exception->" + rex, rex);
                            }

                        } // Rejected Assets
                        else if (map.get(SLDConstants.DAM_STATUS).toString().equalsIgnoreCase(SLDConstants.DAM_STATUS_REJECT)) {
                            if (!metadataNode.hasProperty("dam:vipr")) {
                            	LOG.debug("Rejected asset processing start");
                                viprSoapService.SendSoapMessageToVipr(assetResource.getName());
                                map.put("dam:vipr", "sent");
                                assetResource.getResourceResolver().commit();
                                LOG.debug("Rejected asset processing End");
                            }
                        }
                    }else {
                    	 LOG.debug("No Property ::  dam:status and diFolder for asset ::"+ asset.getPath());
                    }
                } catch (Exception e) {
                    LOG.error("CopyApprovedAssets.ERROR ### " + e.getMessage(), e);
                }
            }
            
            trackPendingAssets(resolver, workflowMetaDataMap);
        }
    }

	private void trackPendingAssets(ResourceResolver resolver, MetaDataMap workflowMetaDataMap) {
		String projectAssetFolder = workflowMetaDataMap.get(SLDConstants.WF_PROJ_ASSET_FOLDER).toString();
		int pendingAssets = projectAssetsDao.getPendingAssetCount(resolver, projectAssetFolder);
		workflowMetaDataMap.put("pendingAssets", pendingAssets);
	}
}
