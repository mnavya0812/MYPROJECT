package com.adidas.dam.models;


import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement
public class ContactSheetData {

	String title;
	  String description;
	  String username;
	  String heading;
	  int id;
	
	  String results;
	  String header;
	  String cell;
	  String row;
	  
	public String getTitle() {
		return title;
	}

	@XmlElement
	public void setTitle(String name) {
		this.title = name;
	}

	public String getDescription() {
		return description;
	}

	@XmlElement
	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getUsername() {
		return description;
	}

	@XmlElement
	public void setUsername(String username) {
		this.username = username;
	}


	public String getHeading() {
		return heading;
	}


	@XmlElement
	public void setHeading(String heading) {
		this.heading = heading;
	}

	
	public String getHeader() {
		return results;
	}

	@XmlElement
	public void setHeader(String header) {
		this.header = header;
	}
	
	public String getRow() {
		return row;
	}

	@XmlElement
	public void setRow(String row) {
		this.row = row;
	}

	public String getCell() {
		return cell;
	}

	@XmlElement
	public void setCell(String cell) {
		this.cell = cell;
	}
	

	public int getId() {
		return id;
	}

	@XmlAttribute
	public void setId(int id) {
		this.id = id;
	}

}