package com.adidas.dam.scheduled;

import com.adidas.dam.services.SAMMSDataService;
import org.apache.felix.scr.annotations.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.List;


@Component(immediate = true, enabled = true, metatype = true, policy = ConfigurationPolicy.REQUIRE)
@Service(value = Runnable.class)
@Properties({
        @Property(name = "scheduler.expression", label = "Cron Expression",
                description = "Provide cron expression for the time you want to reschedule this Metadata export.",
                value = "0 0 1 * * ? * ")
})

public class SAMMSExportJob implements Runnable{
    private static final Logger log = LoggerFactory.getLogger(SAMMSExportJob.class);

    @Reference
    SAMMSDataService sammsDataService;

    @Override
    public void run() {
        String[] runModes = System.getProperty("sling.run.modes").split(",");
        List<String> runModesList = Arrays.asList(runModes);
        if (!runModesList.contains("author") || runModesList.contains("offload")) {
            log.info("Runs on primary author only");
            return; //Not author, so exit
        }

        log.info("Starting export");
        sammsDataService.exportData(false);
    }

}
