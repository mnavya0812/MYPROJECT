package com.adidas.dam.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.annotation.Nonnull;
import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.request.RequestParameter;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;

import com.adidas.dam.services.AssetUpdateNotificationService;

@Component(immediate = true)
@Service
public class TestAssetNotificationServlet extends SlingSafeMethodsServlet {

    @Property(value="/bin/assetNotification")
    static final String SERVLET_PATH="sling.servlet.paths";

    @Reference
    AssetUpdateNotificationService assetUpdateNotificationService;

    @Override
    protected void doGet(@Nonnull SlingHttpServletRequest request, @Nonnull SlingHttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        response.setContentType("text/html");

        RequestParameter cmd = request.getRequestParameter("cmd");
        RequestParameter assetParam = request.getRequestParameter("asset");
        if (cmd != null && cmd.getString().equals("notify")) {
            if (assetParam == null || "".equals(assetParam.getString())) {
                assetUpdateNotificationService.notifyUsers();
            } else {
//                assetUpdateNotificationService.notifyUsers(assetParam.getString());
            }
        }

        out.println("<form>" +
                "<label for='asset'>Asset to send notification for: <input type='text' name='asset'/><small>empty for all assets</small></label>" +
                "<input type='hidden' value='notify' name='cmd'/><button type='submit'>Send Notifications</a>");
    }
}
