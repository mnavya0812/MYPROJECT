package com.adidas.barnesnoble;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.ServletException;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adidas.dam.services.BarnesNobleConfigService;
import com.adidas.dam.util.AEMHttp;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;
/**
 * @author prabathi
 * Servlet used to
 *  1) parses the Request,
 *  2)generate Barnes Noble Asset rendition and 
 *  3) transfers via FTP
 */
@SlingServlet(paths="/bin/adidas/bnftp", methods = "POST", metatype=true)
public class BarnesNobleFTPServlet extends SlingAllMethodsServlet {

	
	private static final Logger log = LoggerFactory.getLogger(BarnesNobleFTPServlet.class);

	String host = "";
	private String ftpErrorMsg = "";
	private boolean ftpSuccess = false;
	private StringBuilder imageRenditionComments;
	private int fileGeneratedCount;
	@Reference
	BarnesNobleConfigService bnConfigService;
	
	protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
		
		log.info("Barnes Noble Request Received ");
		host = "http://" + request.getServerName() + ":" + request.getServerPort();
		imageRenditionComments = new StringBuilder();
		BarnesNobleRequestObject requestObject = parseBarnesNobleRequest(request);
		
		if (requestObject != null) {
			
			// Get BN rendition for each asset
			HashMap<BarnesNobleAssetObject, InputStream> bnImageRenditionMap = getBarnesNobleImageRendition(requestObject);
			
			
			// If fileGeneratedCount > 0, 
			// 1. Prepare excel report
			// 2. Transfer excel sheet and BN via FTP

			if (fileGeneratedCount > 0) {
				InputStream summaryExcelStream = prepareExcelSummarySheet(requestObject);

				// put excel file stream in bnImageRenditionMap
				String excelFileName = requestObject.getVendorNumber() + "_" + requestObject.getOrderNumber() + "_"
						+ requestObject.getOrderDate() + ".xls";
				BarnesNobleAssetObject excelFileObj = new BarnesNobleAssetObject(excelFileName, excelFileName);

				bnImageRenditionMap.put(excelFileObj, summaryExcelStream);

//				if (bnConfigService.getFtpServer().startsWith("sftp")) {
//                    performSFTPOperation(bnImageRenditionMap);
//                } else {
//                    performFTPOperation(bnImageRenditionMap);
//                }
                performSFTPOperation(bnImageRenditionMap);

			}
			  	  
			
		}
		
		//send response back to user
		  PrintWriter out = response.getWriter();
		  if (ftpSuccess) {
			  
			  	
		    	out.println(imageRenditionComments.toString());
		    	out.println("FTP Process completed");
		    	out.flush();
		    	log.info("Barnes Noble Request Processed ");
		}
		  else{
			  out.println(imageRenditionComments.toString());
			  out.println("Files could not be transferred");
			  out.println(ftpErrorMsg);
			  
		  }
		
		
	}




	/** Parse Request and convert into object
	 * @param request
	 * @return 
	 */
	private BarnesNobleRequestObject parseBarnesNobleRequest(SlingHttpServletRequest request) {

		BarnesNobleRequestObject bnReqObj = null;
		Gson gson = new GsonBuilder().create();

		try {
			bnReqObj = gson.fromJson(new InputStreamReader(request.getInputStream()), BarnesNobleRequestObject.class);
		} catch (JsonSyntaxException e) {
			log.error(e.getMessage());
		} catch (JsonIOException e) {
			log.error(e.getMessage());
		} catch (IOException e) {
			log.error(e.getMessage());
		}

		return bnReqObj;
	}
	
	/**
	 *  For each asset in the request, calls the URL <hotsname>:<port#>/<image_path>?$bn_export$ to get the Barnes & Noble rendition format
	 * @param requestObject
	 * @return
	 */
	private HashMap<BarnesNobleAssetObject, InputStream> getBarnesNobleImageRendition(BarnesNobleRequestObject requestObject) {
		
		BarnesNobleAssetObject[] barnesNobleAssets = requestObject.getBarnesNobleAssets();
		
		HashMap<BarnesNobleAssetObject,InputStream> map = new HashMap<BarnesNobleAssetObject,InputStream>();
		
		CloseableHttpResponse httpResponse;
		
		for (int i = 0; i < barnesNobleAssets.length; i++) {
			
			String aemPath = "/is/image"+barnesNobleAssets[i].getFilepath()+"?" + bnConfigService.getBnImagePreset();
			log.info("Request Barnes Noble rendition for: "+host+aemPath);
			try {
				httpResponse = AEMHttp.sendHttpGet(host, aemPath, bnConfigService.getAemUser(),  bnConfigService.getAemPwd());
				int statusCode = httpResponse.getStatusLine().getStatusCode();
				
				if (statusCode == 200) {
					//increment generated count
					fileGeneratedCount += 1;
					imageRenditionComments.append("Barnes Noble Rendition for  "+barnesNobleAssets[i].getFilename() +" found \n ");
					map.put(barnesNobleAssets[i], httpResponse.getEntity().getContent());
					
					//String fileExtension = barnesNobleAssets[i].getFilename().substring(barnesNobleAssets[i].getFilename().indexOf("."));
					int sequenceNumber= i+1;
					String ftpFileName = requestObject.getVendorNumber()+"_"+requestObject.getStoreNumber()+"_"+requestObject.getSendDate()+"_"+sequenceNumber+".jpg";
					barnesNobleAssets[i].setFtpFileName(ftpFileName);
				}
				
				else {
					log.error("Unable to get Barnes Noble Rendition for  "+barnesNobleAssets[i].getFilename() +" "+ statusCode + httpResponse.getStatusLine().getReasonPhrase());
					imageRenditionComments.append("Barnes Noble Rendition for  "+barnesNobleAssets[i].getFilename() +" Not found \n ");
				}
				
			} catch (IOException e) {
				log.error(e.getMessage());
			}
			 
		}
		
		return map;
	}
	
	

	/**
	 *  Prepares a summary excel sheet containing details of all the asset files
	 * @param requestObject
	 * @return 
	 */
	private InputStream prepareExcelSummarySheet(BarnesNobleRequestObject requestObject) {
		
		
		WriteExcel summaryReport = new WriteExcel();
		InputStream summaryExcelStream = summaryReport.exportExcel(requestObject,bnConfigService);
		
		return summaryExcelStream;
	}
	
	

	/** Transfers Barnes Noble renditions of the assets and the summary excel file using FTP
	 * @param bnImageRenditionMap
	 */
	private void performFTPOperation(HashMap<BarnesNobleAssetObject, InputStream> bnImageRenditionMap) {

		String server =  bnConfigService.getFtpServer();
		String user =  bnConfigService.getFtpUser();
		String password =  bnConfigService.getFtpPassword();

		FTPClient ftp = new FTPClient();

		try {
			ftp.connect(server);
			ftp.login(user, password);

			ftp.setDataTimeout(60000);

			int reply = ftp.getReplyCode();

			if (FTPReply.isPositiveCompletion(reply)) {
				log.info("FTP Connection Successful");

				ftp.enterLocalPassiveMode();
				ftp.setUseEPSVwithIPv4(true);

				boolean directoryExists = ftp.changeWorkingDirectory(bnConfigService.getFtpUploadDirectory());
				boolean directoryCreated = false;
				if (! directoryExists) {
					
					log.info("Creating directory: "+bnConfigService.getFtpUploadDirectory() +" on FTP server");
					directoryCreated = ftp.makeDirectory(bnConfigService.getFtpUploadDirectory());
				}
				
				
				if (directoryExists ||  directoryCreated) {
					
					log.info("FTP server directory found");
					
					ftp.setFileType(FTP.BINARY_FILE_TYPE);
				    //ftp.setFileTransferMode(0);
				    
					String upPath = "";

					Iterator it = bnImageRenditionMap.entrySet().iterator();

					while (it.hasNext()) {
						Map.Entry pair = (Map.Entry) it.next();

						BarnesNobleAssetObject bnObj = (BarnesNobleAssetObject) pair.getKey();
						upPath = bnConfigService.getFtpUploadDirectory()+"/" + bnObj.getFtpFileName();
						log.info("FTp Upload Path : "+upPath);
						ftp.storeFile(upPath, (InputStream) pair.getValue());
						log.info("File "+bnObj.getFtpFileName()+ " uploaded successfully");	
					}
					
					ftpSuccess = true;
				}
				else {
					log.error("Cannot find or create FTP Upload Directory ");
					ftpErrorMsg = "Cannot find or create FTP Upload Directory ";
				}

			} else{
				ftp.disconnect();
				ftpErrorMsg = "Error occured durng FTP Transfer";
			}

		} catch (IOException e) {
			log.error("Error occured durng FTP Transfer "+e.getMessage());
			ftpErrorMsg = "Error occured durng FTP Transfer " + e.getMessage();
		}
	}

    /** Transfers Barnes Noble renditions of the assets and the summary excel file using FTP
     * @param bnImageRenditionMap
     */
    private void performSFTPOperation(HashMap<BarnesNobleAssetObject, InputStream> bnImageRenditionMap) {

        String server =  bnConfigService.getFtpServer();
        String user =  bnConfigService.getFtpUser();
        String password =  bnConfigService.getFtpPassword();

        Session session = null;
        Channel channel = null;
        ChannelSftp channelSftp = null;

        try {
            JSch jsch = new JSch();
            session = jsch.getSession(user, server, 22);
            session.setPassword(password);

            java.util.Properties config = new java.util.Properties();
            config.put("StrictHostKeyChecking", "no");

            session.setConfig(config);
            session.connect();
            System.out.println("Host connected.");

            channel = session.openChannel("sftp");
            channel.connect();
            System.out.println("SFTP channel opened and connected.");

            channelSftp = (ChannelSftp) channel;
            channelSftp.cd(bnConfigService.getFtpUploadDirectory());

            String upPath = "";

            Iterator it = bnImageRenditionMap.entrySet().iterator();

            while (it.hasNext()) {
                Map.Entry pair = (Map.Entry) it.next();

                BarnesNobleAssetObject bnObj = (BarnesNobleAssetObject) pair.getKey();
                upPath = bnObj.getFtpFileName();
                log.info("SFTP Upload Path : " + upPath);
                channelSftp.put((InputStream) pair.getValue(), upPath);
                log.info("File "+bnObj.getFtpFileName()+ " uploaded successfully");
            }

            ftpSuccess = true;

        } catch (Exception e) {
            log.error("Error occured durng FTP Transfer "+e.getMessage());
            ftpErrorMsg = "Error occured durng FTP Transfer " + e.getMessage();
        } finally {
            channelSftp.exit();
            channelSftp.disconnect();
        }
    }
	

	

}
