package com.adidas.barnesnoble;

import com.adidas.dam.services.BarnesNobleConfigService;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;
import jxl.CellView;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.format.UnderlineStyle;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WriteExcel {

    private static final Logger log = LoggerFactory.getLogger(WriteExcel.class);
    private WritableCellFormat timesBoldUnderline;
    private WritableCellFormat times;
    private BarnesNobleConfigService bnConfigService;

    public InputStream exportExcel(BarnesNobleRequestObject requestObject, BarnesNobleConfigService bnConfigService) {

        this.bnConfigService = bnConfigService;
        try {
            InputStream is = write(requestObject.getBarnesNobleAssets(), requestObject);
            return is;
        } catch (Exception e) {
            log.error("Fatal error while exporting excel file ", e);
        }
        return null;
    }

    public InputStream write(BarnesNobleAssetObject[] barnesNobleAssetObjects, BarnesNobleRequestObject requestObject) throws IOException, WriteException {

        OutputStream os = new java.io.ByteArrayOutputStream();
        WorkbookSettings wbSettings = new WorkbookSettings();

        wbSettings.setLocale(new Locale("en", "EN"));

        // Create a Workbook - pass the OutputStream
        WritableWorkbook workbook = Workbook.createWorkbook(os, wbSettings);
        workbook.createSheet("Barnes Noble FTP Transfer Report", 0);
        WritableSheet excelSheet = workbook.getSheet(0);
        createLabel(excelSheet);
        int size = createContent(excelSheet, barnesNobleAssetObjects, requestObject);

        //Close the workbook               
        workbook.write();
        workbook.close();

        // Get an inputStram that represents the Report
        java.io.ByteArrayOutputStream stream = new java.io.ByteArrayOutputStream();
        stream = (java.io.ByteArrayOutputStream) os;
        byte[] myBytes = stream.toByteArray();
        java.io.InputStream is = new java.io.ByteArrayInputStream(myBytes);

        return is;
    }

    private void createLabel(WritableSheet sheet)
            throws WriteException {
        //Create a times font 
        WritableFont times10pt = new WritableFont(WritableFont.TIMES, 10);
        //Define the cell format
        times = new WritableCellFormat(times10pt);
        //  Lets automatically wrap the cells
        times.setWrap(true);

        //create create a bold font with unterlines
        WritableFont times10ptBoldUnderline = new WritableFont(WritableFont.TIMES, 10, WritableFont.BOLD, false,
                UnderlineStyle.SINGLE);
        timesBoldUnderline = new WritableCellFormat(times10ptBoldUnderline);
        // Lets automatically wrap the cells
        timesBoldUnderline.setWrap(true);

        CellView cv = new CellView();
        cv.setFormat(times);
        cv.setFormat(timesBoldUnderline);
        cv.setAutosize(true);

        // Write a few headers
        addCaption(sheet, 0, 0, bnConfigService.getExcelHeader1());
        addCaption(sheet, 1, 0, bnConfigService.getExcelHeader2());
        addCaption(sheet, 2, 0, bnConfigService.getExcelHeader3());
        addCaption(sheet, 3, 0, bnConfigService.getExcelHeader4());
        addCaption(sheet, 4, 0, bnConfigService.getExcelHeader5());
        addCaption(sheet, 5, 0, bnConfigService.getExcelHeader6());
        addCaption(sheet, 6, 0, bnConfigService.getExcelHeader7());
        addCaption(sheet, 7, 0, bnConfigService.getExcelHeader8());
        addCaption(sheet, 8, 0, bnConfigService.getExcelHeader9());
    }

    private int createContent(WritableSheet sheet, BarnesNobleAssetObject[] barnesNobleAssetObjects, BarnesNobleRequestObject requestObject)
            throws WriteException, RowsExceededException {

        String storeNumber = requestObject.getStoreNumber();
        String shipDate = requestObject.getShipDate();
        int size = barnesNobleAssetObjects.length;

        for (int i = 0; i < barnesNobleAssetObjects.length; i++) {

            String ftpFileName = "";
            if (barnesNobleAssetObjects[i].getFtpFileName() != null) {
                ftpFileName = barnesNobleAssetObjects[i].getFtpFileName().replace(".jpg", "");
            }

            String sldStyleNumber = barnesNobleAssetObjects[i].getSldStyleNumber();
            String colorCode = barnesNobleAssetObjects[i].getColorCode();
            String graphicCode = barnesNobleAssetObjects[i].getGraphicCode();
            String intrepidStyleNumber = barnesNobleAssetObjects[i].getIntrepidStyleNumber();

            addLabel(sheet, 0, i + 2, ftpFileName);

            addLabel(sheet, 2, i + 2, storeNumber);

            addLabel(sheet, 3, i + 2, sldStyleNumber);

            addLabel(sheet, 4, i + 2, colorCode);

            addLabel(sheet, 5, i + 2, graphicCode);

            addLabel(sheet, 6, i + 2, intrepidStyleNumber);

            addLabel(sheet, 8, i + 2, shipDate);
        }

        return size;
    }

    private void addCaption(WritableSheet sheet, int column, int row, String s)
            throws RowsExceededException, WriteException {
        Label label;
        label = new Label(column, row, s, timesBoldUnderline);
        sheet.addCell(label);
    }

    private void addLabel(WritableSheet sheet, int column, int row, String s)
            throws WriteException, RowsExceededException {
        Label label;
        label = new Label(column, row, s, times);
        sheet.addCell(label);
    }
}
