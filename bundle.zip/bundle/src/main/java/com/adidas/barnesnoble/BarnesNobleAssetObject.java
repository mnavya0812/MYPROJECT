package com.adidas.barnesnoble;

/**
 * @author prabathi
 * Represents an Asset in the Barnes Noble request
 */
public class BarnesNobleAssetObject {

	protected String filename;
	protected String filepath;
	protected String colorCode;
	protected String graphicCode;
	protected String intrepidStyleNumber;
	protected String sldStyleNumber;
	protected String ftpFileName;
	
	
	public BarnesNobleAssetObject(String filename,String ftpFileName){
		this.filename = filename;
		this.ftpFileName = ftpFileName;
	}
	
	public String getFilename() {
		
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	public String getFilepath() {
		return filepath;
	}
	public void setFilepath(String filepath) {
		this.filepath = filepath;
	}
	public String getColorCode() {
		return colorCode;
	}
	public void setColorCode(String colorCode) {
		this.colorCode = colorCode;
	}
	public String getGraphicCode() {
		return graphicCode;
	}
	public void setGraphicCode(String graphicCode) {
		this.graphicCode = graphicCode;
	}
	public String getIntrepidStyleNumber() {
		return intrepidStyleNumber;
	}
	public void setIntrepidStyleNumber(String intrepidStyleNumber) {
		this.intrepidStyleNumber = intrepidStyleNumber;
	}
	public String getSldStyleNumber() {
		return sldStyleNumber;
	}
	public void setSldStyleNumber(String sldStyleNumber) {
		this.sldStyleNumber = sldStyleNumber;
	}
	

	public String getFtpFileName() {
		return ftpFileName;
	}
	public void setFtpFileName(String ftpFileName) {
		this.ftpFileName = ftpFileName;
	}
	public boolean equals(Object obj) {
		boolean result = false;

		if (obj == null || obj.getClass() != this.getClass()) {
			result = false;
		} else {

			BarnesNobleAssetObject bnAssetObj = (BarnesNobleAssetObject) obj;
			if (bnAssetObj.getFilename() == this.filename) {
				result = true;
			}
		}
		return result;
	}
	
	public int hashCode() {
		
		return this.filename.hashCode();
	}

}
