package com.adidas.barnesnoble;

/**
 * @author prabathi
 * 
 */
public class BarnesNobleRequestObject {

	BarnesNobleAssetObject[] barnesNobleAssets;
	String orderNumber;
	String orderDate;
	String vendorNumber;
	String storeNumber;
	String sendDate;
	String shipDate;

	public BarnesNobleAssetObject[] getBarnesNobleAssets() {
		return barnesNobleAssets;
	}

	public void setBarnesNobleAssets(BarnesNobleAssetObject[] barnesNobleAssets) {
		this.barnesNobleAssets = barnesNobleAssets;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public String getVendorNumber() {
		return vendorNumber;
	}

	public void setVendorNumber(String vendorNumber) {
		this.vendorNumber = vendorNumber;
	}

	public String getStoreNumber() {
		return storeNumber;
	}

	public void setStoreNumber(String storeNumber) {
		this.storeNumber = storeNumber;
	}

	public String getSendDate() {
		return sendDate;
	}

	public void setSendDate(String sendDate) {
		this.sendDate = sendDate;
	}

	public String getShipDate() {
		return shipDate;
	}

	public void setShipDate(String shipDate) {
		this.shipDate = shipDate;
	}
}
