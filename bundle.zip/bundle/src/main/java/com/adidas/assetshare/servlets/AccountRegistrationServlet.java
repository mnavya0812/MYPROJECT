package com.adidas.assetshare.servlets;

import com.adidas.assetshare.services.AccountRegistrationConfigurationService;
import com.day.cq.commons.mail.MailTemplate;
import com.day.cq.mailer.MessageGateway;
import com.day.cq.mailer.MessageGatewayService;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.jcr.Session;
import javax.mail.internet.InternetAddress;
import javax.servlet.ServletException;
import org.apache.commons.lang.text.StrLookup;
import org.apache.commons.mail.HtmlEmail;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Paul Legan
 * Receives account registration information and send an email to the superadministrators
 */

@SlingServlet(paths="/bin/adidas/account/register", methods = "POST", metatype=true)
public class AccountRegistrationServlet extends SlingAllMethodsServlet {

    private static final Logger log = LoggerFactory.getLogger(AccountRegistrationServlet.class);

    private static final String ACCOUNT_ORDER_TEMPLATE = "/etc/notification/AssetShareAccountRegistrationTemplate.txt";

    @Reference
    private ResourceResolverFactory resourceResolverFactory;

    @Reference
    private MessageGatewayService messageGatewayService;

    @Reference
    private AccountRegistrationConfigurationService accountRegistrationConfigurationService;

    private ResourceResolver resourceResolver = null;

    protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {

        try {
            resourceResolver = resourceResolverFactory.getAdministrativeResourceResolver(null);
            Session session = resourceResolver.adaptTo(Session.class);

            String redirectUri = request.getParameter("__redirectUri__");

            // add the HTML extension if it isn't already on there
            if (!redirectUri.endsWith(".html")) {
                redirectUri += ".html";
            }

            // grab the Author URL from the OSGI service
            String serverPrefix = accountRegistrationConfigurationService.getAuthorUrl();

            // send the email here
            sendEmail(request, serverPrefix);

            response.sendRedirect(redirectUri);

            log.info("ACCOUNT REGISTRATION PROCESS COMPLETE");

        } catch (LoginException e) {
            log.error(e.getMessage());
        }


    }

    private void sendEmail(SlingHttpServletRequest request, String serverPrefix) {

        ArrayList<InternetAddress> emailRecipients = new ArrayList<InternetAddress>();

        // Getting the Email template.
        Resource templateResource = resourceResolver.getResource(ACCOUNT_ORDER_TEMPLATE);
        Session session = resourceResolver.adaptTo(Session.class);

        if (templateResource.getChild("file") != null) {
            templateResource = templateResource.getChild("file");
        }
        if (templateResource == null) {
            log.error("Missing template: " + ACCOUNT_ORDER_TEMPLATE);
        }

        MailTemplate mailTemplate = MailTemplate.create(templateResource.getPath(),session);
        Map<String, String> properties = buildPropertiesMapForEmail(request, serverPrefix);

        try {
            MessageGateway<HtmlEmail> messageGateway = messageGatewayService.getGateway(HtmlEmail.class);
            // Creating the Email.
            HtmlEmail email = new HtmlEmail();
            email.setCharset("UTF-8");

            // build the actual email content
            email = mailTemplate.getEmail(StrLookup.mapLookup(properties), HtmlEmail.class);

            String[] recipients = accountRegistrationConfigurationService.getRecipients().trim().split("\\s*,\\s*");
            for (int i = 0; i < recipients.length; i++) {
                emailRecipients.add(new InternetAddress(recipients[i]));
            }

            email.setTo(emailRecipients);
            email.setFrom(accountRegistrationConfigurationService.getEmailFrom());
            email.setSubject("Account Registration");

            messageGateway.send(email);

        } catch (Exception e) {
            log.error("Fatal error while sending email: ", e);
        }

    }

    private String getDefault(String value, String defaultValue) {
        return (value != null) ? value : defaultValue;
    }

    private Map<String, String> buildPropertiesMapForEmail(SlingHttpServletRequest request, String serverPrefix) {

        Map<String, String> properties = new HashMap<String, String>();
        properties.put("firstName", getDefault(request.getParameter("firstName"), "[n/a]"));
        properties.put("lastName", getDefault(request.getParameter("lastName"), "[n/a]"));
        properties.put("passcode", getDefault(request.getParameter("passcode"), "[n/a]"));
        properties.put("streetAddress", getDefault(request.getParameter("streetAddress"), "[n/a]"));
        properties.put("city", getDefault(request.getParameter("city"), "[n/a]"));
        properties.put("state", getDefault(request.getParameter("state"), "[n/a]"));
        properties.put("zip", getDefault(request.getParameter("zip"), "[n/a]"));
        properties.put("email", getDefault(request.getParameter("email"), "[n/a]"));
        properties.put("username", getDefault(request.getParameter("username"), "[n/a]"));
        properties.put("password", getDefault(request.getParameter("password"), "[n/a]"));
        properties.put("company", getDefault(request.getParameter("company"), "[n/a]"));
        properties.put("department", getDefault(request.getParameter("department"), "[n/a]"));
        properties.put("phone", getDefault(request.getParameter("phone"), "[n/a]"));
        properties.put("title", getDefault(request.getParameter("title"), "[n/a]"));
        properties.put("customerNumber", getDefault(request.getParameter("customerNumber"), "[n/a]"));
        properties.put("reason", getDefault(request.getParameter("reason"), "[n/a]"));
        properties.put("countryPicker", getDefault(request.getParameter("countryPicker"), "[n/a]"));
        properties.put("serverPrefix", serverPrefix);
        return properties;
    }

}
