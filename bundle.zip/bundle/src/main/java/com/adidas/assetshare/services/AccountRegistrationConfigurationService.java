package com.adidas.assetshare.services;

import java.util.Map;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.PropertyUnbounded;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(metatype = true, immediate = true,label = "Adidas Account Registration Service")
@Service(AccountRegistrationConfigurationService.class)
@Properties({
        @Property(name = "ar.author.url", label = "Author URL", unbounded = PropertyUnbounded.DEFAULT),
        @Property(name = "ar.email.from", label = "Email From Address", unbounded = PropertyUnbounded.DEFAULT),
        @Property(name = "ar.email.subject", label = "Email Subject Line", unbounded = PropertyUnbounded.DEFAULT),
        @Property(name = "ar.email.recipients", label = "Email Recipients (Separated by commas)", unbounded = PropertyUnbounded.DEFAULT)
})
public class AccountRegistrationConfigurationService {

    private String authorUrl;
    private String recipients;
    private String emailFrom;
    private String emailSubject;


    private static final Logger LOG = LoggerFactory.getLogger(AccountRegistrationConfigurationService.class);

    @Activate
    protected void activate(Map<String, Object> properties)
    {

        readProperties(properties);
    }

    protected void readProperties(Map<String, Object> properties)
    {
        LOG.info(properties.toString());
        this.authorUrl = PropertiesUtil.toString(properties.get("ar.author.url"), "http://usindamap100:4502");
        this.recipients = PropertiesUtil.toString(properties.get("ar.email.recipients"), "ryan.scott@adidas-group.com,kim.dowell@adidas-group.com");
        this.emailFrom = PropertiesUtil.toString(properties.get("ar.email.from"), "info@adidas-group.com");
        this.emailSubject = PropertiesUtil.toString(properties.get("ar.email.subject"), "Account Registration");
    }

    public String getEmailSubject() {
        return emailSubject;
    }

    public void setEmailSubject(String emailSubject) {
        this.emailSubject = emailSubject;
    }

    public String getRecipients() {
        return recipients;
    }

    public void setRecipients(String recipients) {
        this.recipients = recipients;
    }

    public String getAuthorUrl() {
        return authorUrl;
    }

    public void setAuthorUrl(String authorUrl) {
        this.authorUrl = authorUrl;
    }

    public String getEmailFrom() {
        return emailFrom;
    }

    public void setEmailFrom(String emailFrom) {
        this.emailFrom = emailFrom;
    }
}
