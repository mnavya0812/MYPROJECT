package com.adidas.sos.util;

import java.lang.reflect.Type;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

/**
 * @author prabathi
 * Converts SOSQueryRequestResponse object to  JSON response that is sent to SOS
 */
public class SOSQueryRequestResponseSerializer  implements JsonSerializer<SOSQueryRequestResponse>{

	@Override
	public JsonElement serialize(SOSQueryRequestResponse sosReqResp, Type arg1, JsonSerializationContext context) {
	
		JsonObject jsonObject = new JsonObject();
		
		jsonObject.addProperty("asset_status", sosReqResp.getAssetStatus());
			
		JsonElement asset = context.serialize(sosReqResp.getAsset());
		jsonObject.add("asset", asset);
		
		JsonElement assetComponents = context.serialize(sosReqResp.getAssetComponents());
		jsonObject.add("components", assetComponents);
		
		jsonObject.addProperty("color", sosReqResp.getColor());
		jsonObject.addProperty("team", sosReqResp.getTeam());
		jsonObject.addProperty("league", sosReqResp.getLeague());
		jsonObject.addProperty("graphic_code", sosReqResp.getGraphic_code());
		jsonObject.addProperty("playerNumber", sosReqResp.getPlayerNumber());
		jsonObject.addProperty("style", sosReqResp.getStyle());
		jsonObject.addProperty("pose", sosReqResp.getPose());
		
		return jsonObject;
	}

}
