package com.adidas.sos.servlets;

import com.adidas.dam.util.SLDConstants;
import com.adidas.dam.util.SLDConstants.ArtDocumentType;
import com.adidas.sos.util.SOSAsset;
import com.adidas.sos.util.SOSComponent;
import com.adidas.sos.util.SOSQueryRequestResponse;
import com.adidas.sos.util.SOSQueryRequestResponseSerializer;
import com.day.cq.mailer.MessageGatewayService;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;
import javax.servlet.ServletException;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Pravin Bathija
 * <br> Logic to query JCR based on request from SOS system
 */
@SlingServlet(paths = "/bin/adidas/status", methods = "POST", metatype = true)
public class SOSOrderProcessingServlet extends SlingAllMethodsServlet {

    private static final Logger LOG = LoggerFactory.getLogger(SOSOrderProcessingServlet.class);

    @Reference
    private ResourceResolverFactory resourceResolverFactory;

    @Reference
    private MessageGatewayService messageGatewayService;

    private ResourceResolver resourceResolver = null;

    private Session session = null;

    private String respMessage = "";

    @Override
    protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)
            throws ServletException, IOException {

        PrintWriter out = response.getWriter();

        LOG.info("SOS ASSET SEARCH PROCESS START");

        try {

            resourceResolver = resourceResolverFactory.getAdministrativeResourceResolver(null);
            session = resourceResolver.adaptTo(Session.class);

            //Prepare Request objects from JSON request
            List<SOSQueryRequestResponse> sosRequestObjects = prepareSOSRequestObjects(request);

            // Search for Assets/Components
            // Populate each SOSQueryRequestResponse based on search result
            searchAssetOrComponents(sosRequestObjects, session);

            response.setContentType("application/json");
            StringBuilder respJson = new StringBuilder();
            GsonBuilder gsonBuilder = new GsonBuilder();
            gsonBuilder.registerTypeAdapter(SOSQueryRequestResponse.class, new SOSQueryRequestResponseSerializer());

            Gson gson = gsonBuilder.setPrettyPrinting().create();
            respJson.append(gson.toJson(sosRequestObjects.toArray()));
            respMessage = respJson.toString();

            LOG.info("SOS ASSET SEARCH PROCESS COMPLETE");

        } catch (LoginException e) { 
            LOG.error("Error occured during SOS ASSET SEARCH PROCESS ");
            LOG.error(e.getMessage());
            respMessage = "{ \"status\": \"" + "An Error has occured\n " + e.getMessage() + "\" }";
        } catch (RepositoryException e) {
            LOG.error("Error occured during SOS ASSET SEARCH PROCESS ");
            LOG.error(e.getMessage());
            respMessage = "{ \"status\": \"" + "An Error has occured\n " + e.getMessage() + "\" }";
        } finally {

            out.print(respMessage);
            out.flush();
        }

    }

    /**
     * Creates a list of SOS Request Objects from the JSON Request
     *
     * @param request
     * @return
     */
    private List<SOSQueryRequestResponse> prepareSOSRequestObjects(SlingHttpServletRequest request) {

        SOSQueryRequestResponse[] reqObjects = null;

        try {

            Gson gson = new GsonBuilder().create();
            reqObjects = gson.fromJson(new InputStreamReader(request.getInputStream()), SOSQueryRequestResponse[].class);
            for (int i = 0; i < reqObjects.length; i++) {
                LOG.info("***Parse json success. File name " + i + " = " + reqObjects[i].getAssetFileName());
            }

        } catch (Exception e) {
            LOG.error(e.getMessage());
        }

        return new ArrayList<SOSQueryRequestResponse>(Arrays.asList(reqObjects));
    }

    private static String getConfidentialProperty(Node node) throws RepositoryException {
        if (node.hasProperty(SLDConstants.METADATA_CONFIDENTIAL)) {
            return node.getProperty(SLDConstants.METADATA_CONFIDENTIAL).getString();
        } else {
            return SLDConstants.NOT_CONFIDENTIAL;
        }
    }

    /**
     * For each Request object in List:<br>
     * 1) Searches for Asset based on filename. <br>
     * 2) If Asset not found, calls method to search for components
     *
     * @param sosRequestObjects
     * @param session
     * @return
     * @throws RepositoryException
     */
    private void searchAssetOrComponents(List<SOSQueryRequestResponse> sosRequestObjects, Session session)
            throws RepositoryException {

        for (SOSQueryRequestResponse sosRequest : sosRequestObjects) {
            SOSAsset asset = searchByFilename(sosRequest.getFilename(), session);
            if (asset != null) {
                sosRequest.setAssetStatus("found");
                sosRequest.setAsset(asset);
            } else {
                LOG.info("Asset NOT found for filename " + sosRequest.getFilename() + ".Looking for components");
                sosRequest.setAssetStatus("not found");
                searchForComponents(sosRequest, session);
            }
        }

    }

    private SOSAsset searchByFilename(String filename, Session session) throws RepositoryException {
        String assetFinderSql = getSQLAssetCompByFileName(filename, false);
        LOG.info("Query to search for Asset by filename: " + assetFinderSql);

        // Do not execute blank sql query. (If blank filename was received from SOS req, sql query would be blank)
        if (!assetFinderSql.isEmpty()) {

            QueryManager queryManager = session.getWorkspace().getQueryManager();
            Query query = queryManager.createQuery(assetFinderSql, "JCR-SQL2");
            QueryResult queryResult = query.execute();

            NodeIterator nodeIterator = queryResult.getNodes();
            
            while (nodeIterator.hasNext()) {
                LOG.info("Asset found for filename " + filename);

                Node node = nodeIterator.nextNode();
                if (!node.getName().equalsIgnoreCase(filename)) {
                    continue;
                }
                SOSAsset asset = new SOSAsset();

                asset.setFileName(node.getName());
                asset.setFilePath(node.getPath());
                asset.setConfidential(getConfidentialProperty(node));
//						asset.setPublicationStatus("published");
//						asset.setReveiewStatus("approved");
                //TODO Add other metadata
                return asset;
            }
        }
        return null;
    }

    /**
     * Search for Components and populate sosRequest object
     *
     * @param sosRequest
     * @param session
     * @throws RepositoryException
     */
    private void searchForComponents(SOSQueryRequestResponse sosRequest, Session session) throws RepositoryException {

        List<SOSAsset> assetComponentList = new ArrayList<SOSAsset>();
        String[] components = sosRequest.getComponents();

        for (String component : components) {
            if (component.equals("neutral")) {

                String neutralCompQuery = getSQLForNeutralCompMap(sosRequest);
                executeNeutralComponentQuery(assetComponentList, neutralCompQuery, session, component);

            } else if (component.equals("art")) {

                buildAndExecuteArtCompQuery(sosRequest, assetComponentList, session, component);

            } else if (component.equals("apa_apparel")) {

                String apaCompSql = getSQLAPACompByFileNameMap(sosRequest, "apa_apparel");
                LOG.info("Searching for APA Apparel Component . The  search query is : " + apaCompSql);
                executeComponentQuery(assetComponentList, apaCompSql, session, component);

            } else if (component.equals("apa_headwear")) {

                String apaCompSql = getSQLAPACompByFileNameMap(sosRequest, "apa_headwear");
                LOG.info("Searching for APA HEADWEAR Component . The  search query is : " + apaCompSql);
                executeComponentQuery(assetComponentList, apaCompSql, session, component);

            } else {
                SOSComponent assetComponent = new SOSComponent();
                assetComponent.setComponentType(component);
                assetComponent.setComponentStatus("not found");
                assetComponentList.add(assetComponent);
            }
        }

        SOSAsset[] componentsArray = assetComponentList.toArray(new SOSAsset[assetComponentList.size()]);
        sosRequest.setAssetComponents(componentsArray);
    }

    /**
     * Prepares Map to search for ART component
     *
     * @param sosRequest
     * @param component
     * @param session
     * @param assetComponentList
     * @return
     * @throws RepositoryException
     */
    private void buildAndExecuteArtCompQuery(SOSQueryRequestResponse sosRequest, List<SOSAsset> assetComponentList, Session session, String componentType) throws RepositoryException {

        String artCompSql;

        //Check if blank parameters were received from SOS
        if (!sosRequest.getGraphic_code().equals("") && !sosRequest.getFamilyColor().equals("")) {

            artCompSql = getSQLByGraphicColorAndType(sosRequest.getGraphic_code(), sosRequest.getFamilyColor());

            LOG.info("Searching for ART Component using graphic code and familyColor. The ART component search query is : " + artCompSql);

            QueryManager queryManager = session.getWorkspace().getQueryManager();
            Query query = queryManager.createQuery(artCompSql, "JCR-SQL2");
            QueryResult queryResult = query.execute();

            // If comp not found with <graphic_code>_<familyColor>.ai; search with <graphic_code>_<color>.ai
            if (queryResult.getNodes().getSize() <= 0 && !sosRequest.getColor().isEmpty()) {
                artCompSql = getSQLByGraphicColorAndType(sosRequest.getGraphic_code(), sosRequest.getColor());

                LOG.info("Searching for ART Component using graphic code and color. The ART component search query is : " + artCompSql);
                query = queryManager.createQuery(artCompSql, "JCR-SQL2");
                queryResult = query.execute();

                if (queryResult.getNodes().getSize() <= 0) {
                    SOSComponent assetComponent = new SOSComponent();
                    assetComponent.setComponentType(componentType);
                    assetComponent.setComponentStatus("not found");
                    assetComponentList.add(assetComponent);
                    return;
                }

                populateAssetComponentsList(queryResult, componentType, assetComponentList);
            } else {

                populateAssetComponentsList(queryResult, componentType, assetComponentList);

            }

        } else {
            SOSComponent assetComponent = new SOSComponent();
            assetComponent.setComponentType(componentType);
            assetComponent.setComponentStatus("not found");
            assetComponentList.add(assetComponent);
        }

    }

    /**
     * Executes component search Query
     *
     * @param assetComponentList
     * @param apaCompSql
     * @param session
     * @throws RepositoryException
     */
    private void executeComponentQuery(List<SOSAsset> assetComponentList, String apaCompSql, Session session,
            String componentType) throws RepositoryException {

        if (!apaCompSql.equals("")) {
            QueryManager queryManager = session.getWorkspace().getQueryManager();
            Query query = queryManager.createQuery(apaCompSql, "JCR-SQL2");
            QueryResult queryResult = query.execute();

            // When component not found, create an empty component and add in
            // the list
            if (queryResult.getNodes().getSize() <= 0) {
                SOSComponent assetComponent = new SOSComponent();
                assetComponent.setComponentType(componentType);
                assetComponent.setComponentStatus("not found");
                assetComponentList.add(assetComponent);
            } else {
                populateAssetComponentsList(queryResult, componentType, assetComponentList);
            }
        } else {
            SOSComponent assetComponent = new SOSComponent();
            assetComponent.setComponentType(componentType);
            assetComponent.setComponentStatus("not found");
            assetComponentList.add(assetComponent);
        }

    }

    /**
     * Executes Neutral component search Query. updated to return first match in
     * case multiple records found
     *
     * @param assetComponentList
     * @param neutralCompMap
     * @param session
     * @param componentType
     * @throws RepositoryException
     */
    private void executeNeutralComponentQuery(List<SOSAsset> assetComponentList, String neutralCompQuery, Session session, String componentType) throws RepositoryException {

        LOG.info("Searching for Neutral Component.The neutral component search query is :" + neutralCompQuery);

        if (!neutralCompQuery.equals("")) {

            QueryManager queryManager = session.getWorkspace().getQueryManager();
            Query query = queryManager.createQuery(neutralCompQuery, "JCR-SQL2");
            QueryResult queryResult = query.execute();

            // When component not found, create an empty component and add in the list
            if (queryResult.getNodes().getSize() <= 0) {
                SOSComponent assetComponent = new SOSComponent();
                assetComponent.setComponentType(componentType);
                assetComponent.setComponentStatus("not found");
                assetComponentList.add(assetComponent);
            } else {

                Node node = queryResult.getNodes().nextNode();

                SOSComponent assetComponent = new SOSComponent();
                assetComponent.setComponentType(componentType);
                assetComponent.setComponentStatus("found");
                assetComponent.setFileName(node.getName());
                assetComponent.setFilePath(node.getPath());
                assetComponent.setConfidential(getConfidentialProperty(node));
//	        assetComponent.setPublicationStatus("not published");
//	        assetComponent.setReveiewStatus("pending");
                //TODO Add other metadata

                assetComponentList.add(assetComponent);
            }
        } else {
            SOSComponent assetComponent = new SOSComponent();
            assetComponent.setComponentType(componentType);
            assetComponent.setComponentStatus("not found");
            assetComponentList.add(assetComponent);
        }

    }

    private void populateAssetComponentsList(QueryResult queryResult, String componentType, List<SOSAsset> assetComponentList) throws RepositoryException {

        NodeIterator nodeIterator = queryResult.getNodes();

        while (nodeIterator.hasNext()) {

            Node node = nodeIterator.nextNode();

            SOSComponent assetComponent = new SOSComponent();
            assetComponent.setComponentType(componentType);
            assetComponent.setComponentStatus("found");
            assetComponent.setFileName(node.getName());
            assetComponent.setFilePath(node.getPath());
            assetComponent.setConfidential(getConfidentialProperty(node));
//		           assetComponent.setPublicationStatus("not published");
//		           assetComponent.setReveiewStatus("pending");
            //TODO Add other metadata

            assetComponentList.add(assetComponent);
        }
    }

    //------ SQL Statements
    /**
     * Prepares Map to search for NEUTRAL component
     *
     * @param assetFileName
     * @return
     */
    private String getSQLForNeutralCompMap(SOSQueryRequestResponse sosRequest) {
        String pose = sosRequest.getPose();
        String style = sosRequest.getStyle();
        if (pose != null && !pose.isEmpty()
                && style != null && !style.isEmpty()) {
            return String.format(
                    "select * from [dam:Asset] AS s WHERE ISDESCENDANTNODE(s, '%s') "
                    + " AND [jcr:content/metadata/%s] = '%s'"
                    + " AND [jcr:content/metadata/%s] = 'adidas-picklists:pose/%s'"
                    + " AND [jcr:content/metadata/%s] = '%s'"
                    + " AND [jcr:content/metadata/%s] LIKE '%s'",
                    SLDConstants.SLD_ROOT_PATH,
                    SLDConstants.STYLE_NUMBER,
                    style.toUpperCase(),
                    SLDConstants.POSE,
                    pose.toUpperCase(),
                    SLDConstants.ART_DOCUMENT_TYPE,
                    ArtDocumentType.NEUTRAL.code,
                    SLDConstants.FILE_NAME,
                    "%.PSD"
            );
        } else {
            return "";
        }
    }

    /**
     * Prepares Map to search asset/component with File Name
     *
     * @param assetFileName
     * @return
     */
    private String getSQLAssetCompByFileName(String assetFileName, boolean wildcard) {
        if (assetFileName != null && !assetFileName.equals("")) {
            String searchName = assetFileName.toUpperCase();
            if (wildcard) {
                return String.format("select * from [dam:Asset] as s WHERE ISDESCENDANTNODE (s,'%s')"
                        + " AND [jcr:content/metadata/%s] like '%s'",
                        SLDConstants.SLD_ROOT_PATH, SLDConstants.FILE_NAME, searchName);
            } else {
                return String.format("select * from [dam:Asset] as s WHERE ISDESCENDANTNODE (s,'%s')"
                        + " AND [jcr:content/metadata/%s] = '%s'",
                        SLDConstants.SLD_ROOT_PATH, SLDConstants.FILE_NAME, searchName);
            }
        }
        return "";
    }

    private String getSQLByFilenameAndType(String filename, boolean wildcard, ArtDocumentType type) {
        String base = getSQLAssetCompByFileName(filename, wildcard);
        if (base == null || base.isEmpty()) {
            return base;
        } else {
            return base + String.format(" AND [jcr:content/metadata/%s] = '%s'", SLDConstants.ART_DOCUMENT_TYPE, type.code);
        }
    }

    private String getSQLByGraphicColorAndType(String graphic_code, String color) {
        if (graphic_code != null && !graphic_code.isEmpty()
                && color != null && !color.isEmpty()) {
            return String.format(
                    "select * from [dam:Asset] AS s WHERE ISDESCENDANTNODE(s, '%s') "
                    + " AND [jcr:content/metadata/%s] = '%s'"
                    + " AND [jcr:content/metadata/%s] = '%s'"
                    + " AND [jcr:content/metadata/%s] = '%s'",
                    SLDConstants.SLD_ROOT_PATH,
                    SLDConstants.GRAPHIC_CODE,
                    graphic_code.toUpperCase(),
                    SLDConstants.COLOR_CODE,
                    color.toUpperCase(),
                    SLDConstants.ART_DOCUMENT_TYPE,
                    ArtDocumentType.FORMAT_PAGE.code
            );
        } else {
            return "";
        }
    }

    /**
     * Prepares Map to search for APA Apparel/Headwear component
     *
     * @param sosRequest
     * @param string
     * @return
     */
    private String getSQLAPACompByFileNameMap(SOSQueryRequestResponse sosRequest, String type) {
        if (!sosRequest.getStyle().equals("") && !sosRequest.getTeam().equals("") && !sosRequest.getColor().equals("")) {
            String extension = type.equals("apa_apparel") ? "ai" : "eps";
            String fileName = sosRequest.getStyle() + "_" + sosRequest.getTeam() + "_" + sosRequest.getColor() + "." + extension;
            return getSQLByFilenameAndType(fileName, false, ArtDocumentType.APPAREL_PRODUCTION);
        }
        return "";
    }
}
