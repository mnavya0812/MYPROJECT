package com.adidas.sos.util;

/**
 * @author prabathi <br>
 * Represents the Asset Order JSON request/response that will received/sent to SOS
 */
public class SOSAssetOrderReqResp {

	String assets[];
	String order_number;
	String order_date;
	String expirationDate;
	SOSPerson requester;
	String emailRecipients[];
	String templates[];

	public String[] getAssets() {
		return assets;
	}

	public void setAssets(String[] assets) {
		this.assets = assets;
	}

	public String getOrder_number() {
		return order_number;
	}

	public void setOrder_number(String order_number) {
		this.order_number = order_number;
	}

	public String getOrder_date() {
		return order_date;
	}

	public void setOrder_date(String order_date) {
		this.order_date = order_date;
	}

	public String getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}

	public SOSPerson getRequester() {
		return requester;
	}

	public void setRequester(SOSPerson requester) {
		this.requester = requester;
	}

	public String[] getEmailRecipients() {
		return emailRecipients;
	}

	public void setEmailRecipients(String[] emailRecipients) {
		this.emailRecipients = emailRecipients;
	}

	public String[] getTemplates() {
		return templates;
	}

	public void setTemplates(String[] template) {
		this.templates = template;
	}
}
