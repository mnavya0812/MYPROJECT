package com.adidas.sos.util;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;

import com.day.cq.dam.api.Asset;

public class SOSCustomTag extends SimpleTagSupport{
	
	private String confidentialAsset = "no";
	private Asset assetObject;

	public Asset getAssetObject() {
		return assetObject;
	}

	public void setAssetObject(Asset assetObject) {
		this.assetObject = assetObject;
	}
	
	public void doTag() throws JspException, IOException {
		
		Resource resource = assetObject.adaptTo(Resource.class);
		
		ValueMap valueMap = resource.getValueMap();
		
		String confidential = (String) valueMap.get("jcr:content/metadata/confidential");

	if (confidential!= null) {
			confidentialAsset = confidential;
		}
		
		
		getJspContext().setAttribute("confidentialAsset", confidentialAsset);
		
		getJspBody().invoke(null);
	}
}