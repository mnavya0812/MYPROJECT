package com.adidas.sos.util;

import java.util.Calendar;
import java.util.List;

import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.Session;

import org.apache.commons.lang.ArrayUtils;
import org.apache.jackrabbit.commons.JcrUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adidas.sos.util.SOSAssetOrderReqResp;

public class RegisterSOSOrder {
	
	private final static Logger LOGGER = LoggerFactory.getLogger(RegisterSOSOrder.class);

	private static final String SOS_ORDER_PATH = "/content/usergenerated/sosorders";
	public String createNodesAndGetName(SOSAssetOrderReqResp orderRequest, Session session) {


		String result = null;
		try {
			
			Node root = JcrUtils.getOrCreateByPath(SOS_ORDER_PATH, "nt:unstructured", session);
			Node sosoredernode = JcrUtils.getOrCreateUniqueByPath(root, "sosorder", "nt:unstructured");
			
			sosoredernode.setProperty("assetPaths", orderRequest.getAssets());
			sosoredernode.setProperty("orderNumber", orderRequest.getOrder_number());
			sosoredernode.setProperty("orderDate", orderRequest.getOrder_date());
			sosoredernode.setProperty("expirationDate", orderRequest.getExpirationDate());
			
			//Save Requester info in node
			sosoredernode.setProperty("requesterName", orderRequest.getRequester().getName());
			sosoredernode.setProperty("requesterDivision", orderRequest.getRequester().getDivision());
			sosoredernode.setProperty("requesterTeam", orderRequest.getRequester().getTeam());
			sosoredernode.setProperty("requesterAddress1", orderRequest.getRequester().getAddress1());
			sosoredernode.setProperty("requesterAddress2", orderRequest.getRequester().getAddress2());
			sosoredernode.setProperty("requesterPhone", orderRequest.getRequester().getPhone());
			sosoredernode.setProperty("requesterEmail", orderRequest.getRequester().getEmail());
			
			
			sosoredernode.setProperty("emailRecepients", orderRequest.getEmailRecipients());
			sosoredernode.setProperty("requestedTemplates", orderRequest.getTemplates());
			
			
			sosoredernode.setProperty("firstViewedDate", Calendar.getInstance());
			sosoredernode.setProperty("lastViewedDate", Calendar.getInstance());
			
			// Add property for reverse replication
			sosoredernode.setProperty("cq:distribute", true);
			sosoredernode.setProperty("source", "publish");
			
			session.save();

			result = sosoredernode.getName();
		} catch (PathNotFoundException e) {
			LOGGER.info("The node does not exist.");
			LOGGER.info(e.getMessage());
		} catch (Exception e) {
			LOGGER.info(e.getMessage());
		} finally {
			// session.logout();
		}
		return result;
	}

}
