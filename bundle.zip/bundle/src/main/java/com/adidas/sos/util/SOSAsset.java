package com.adidas.sos.util;

/**
 * @author prabathi
 * Represents the information present in the "assets" section of the "Asset Query" JSON Response
 */
public class SOSAsset {

	String fileName;
	String filePath;
	String confidential;
	String reveiewStatus;
	String publicationStatus;


	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public String getConfidential() {
		return confidential;
	}

	public void setConfidential(String confidential) {
		this.confidential = confidential;
	}

	public String getReveiewStatus() {
		return reveiewStatus;
	}

	public void setReveiewStatus(String reveiewStatus) {
		this.reveiewStatus = reveiewStatus;
	}

	public String getPublicationStatus() {
		return publicationStatus;
	}

	public void setPublicationStatus(String publicationStatus) {
		this.publicationStatus = publicationStatus;
	}

}
