package com.adidas.sos.servlets;

import com.adidas.dam.services.SOSAdidasService;
import com.adidas.sos.util.RegisterSOSOrder;
import com.adidas.sos.util.SOSAssetOrderReqResp;
import com.day.cq.commons.mail.MailTemplate;
import com.day.cq.mailer.MessageGateway;
import com.day.cq.mailer.MessageGatewayService;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.jcr.Session;
import javax.mail.internet.InternetAddress;
import javax.servlet.ServletException;
import org.apache.commons.lang.text.StrLookup;
import org.apache.commons.mail.HtmlEmail;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.jackrabbit.util.Base64;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@SlingServlet(paths = "/bin/adidas/order", methods = "POST", metatype = true)
public class SOSAssetPickUpServlet extends SlingAllMethodsServlet {

    private static final Logger log = LoggerFactory.getLogger(SOSAssetPickUpServlet.class);

    private static final String SOS_ORDER_TEMPLATE = "/etc/notification/SOSOrderTemplate.txt";

    @Reference
    private ResourceResolverFactory resourceResolverFactory;

    @Reference
    private MessageGatewayService messageGatewayService;

    private ResourceResolver resourceResolver = null;

    @Reference
    SOSAdidasService sosService;

    private String respMessage = "{ \"status\": \"ok\" }";

    protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {

        try {
            resourceResolver = resourceResolverFactory.getAdministrativeResourceResolver(null);
            Session session = resourceResolver.adaptTo(Session.class);
            RegisterSOSOrder saveOrder = new RegisterSOSOrder();
            SOSAssetOrderReqResp orderRequest = parseJsonOrder(request);

            // Create a new node and save order request as properties of this node.
            String sosNodeName = saveOrder.createNodesAndGetName(orderRequest, session);

            //create URL to the newly created node
            //String assetUrl =  String.format("http://" + request.getServerName() + ":" + request.getServerPort() +"/editor.html/content/adidas-demo/sampleorder.html?sosOrderNum=%s",sosNodeName) ; 
            //String assetUrl =  String.format("http://" + request.getServerName() + ":" + request.getServerPort() +sosService.getSiteRootFolder()+"/sosordereula.html?sosOrderNum=%s",Base64.encode(sosNodeName)) ; 
            // Need to make it configurable after release
            String assetUrl = String.format("https://" + "aem.adidas-group.com" + sosService.getSiteRootFolder() + "/sosordereula.html?sosOrderNum=%s", Base64.encode(sosNodeName));

            sendEmail(sosNodeName, assetUrl, orderRequest);

            response.setContentType("application/json");
            PrintWriter out = response.getWriter();

            out.print(respMessage);
            out.flush();

            log.info("SOS ASSET PICKUP PROCESS COMPLETE");

        } catch (LoginException e) {
            log.error(e.getMessage());
        }

    }

    /**
     * Converts SOS Asset Order Json request to Java Object
     *
     * @param request
     * @return
     */
    private SOSAssetOrderReqResp parseJsonOrder(SlingHttpServletRequest request) {

        SOSAssetOrderReqResp orderRequest = null;
        Gson gson = new GsonBuilder().create();

        try {
            orderRequest = gson.fromJson(new InputStreamReader(request.getInputStream()), SOSAssetOrderReqResp.class);
        } catch (JsonIOException e) {
            log.error(e.getMessage());
        } catch (JsonSyntaxException e) {
            log.error(e.getMessage());
        } catch (IOException e) {
            log.error(e.getMessage());
        }

        return orderRequest;
    }

    /**
     * Method to email the Asset Pick up Page link
     *
     * @param sosNodeName
     * @param assetUrl
     * @param orderRequest
     *
     */
    private void sendEmail(String sosNodeName, String assetUrl, SOSAssetOrderReqResp orderRequest) {

        ArrayList<InternetAddress> emailRecipients = new ArrayList<InternetAddress>();
        // Getting the Email template.
        Resource templateRsrc = resourceResolver.getResource(SOS_ORDER_TEMPLATE);
        Session session = resourceResolver.adaptTo(Session.class);
        if (templateRsrc.getChild("file") != null) {
            templateRsrc = templateRsrc.getChild("file");
        }
        if (templateRsrc == null) {
            log.error("Missing template: " + SOS_ORDER_TEMPLATE);
        }

        MailTemplate mailTemplate = MailTemplate.create(templateRsrc.getPath(), session);

        Map<String, String> properties = buildPropertiesMapForEmail(orderRequest, assetUrl);

        try {
            MessageGateway<HtmlEmail> messageGateway = messageGatewayService.getGateway(HtmlEmail.class);
            // Creating the Email.
            HtmlEmail email = new HtmlEmail();
            email.setCharset("UTF-8");
            email = mailTemplate.getEmail(StrLookup.mapLookup(properties), HtmlEmail.class);

            String[] recipients = orderRequest.getEmailRecipients();
            for (int i = 0; i < recipients.length; i++) {
                emailRecipients.add(new InternetAddress(recipients[i]));
            }

            email.setTo(emailRecipients);

            //email.setFrom(orderRequest.getRequester().getEmail());
            email.setFrom("digital.images@adidas-group.com");

            email.setSubject(" Adidas assets for order# " + orderRequest.getOrder_number() + " are ready for pick up");
            messageGateway.send(email);
        } catch (Exception e) {
            log.error("Fatal error while sending email: ", e);
            respMessage = "{ \"status\": \"Error occured while sending email\" }";
        }

    }

    /**
     * Populates placeholders present in /etc/notification/SOSOrderTemplate.txt
     * with values from json request object
     *
     * @param orderRequest
     * @param assetUrl
     * @return
     */
    private Map<String, String> buildPropertiesMapForEmail(SOSAssetOrderReqResp orderRequest, String assetUrl) {

        Map<String, String> properties = new HashMap<String, String>();
        properties.put("requesterName", orderRequest.getRequester().getName());
        properties.put("sosOrderUrl", assetUrl);
        properties.put("orderDate", orderRequest.getOrder_date());
        properties.put("orderExpDate", orderRequest.getExpirationDate());

        properties.put("requesterName", orderRequest.getRequester().getName());
        properties.put("requesterEmail", orderRequest.getRequester().getEmail());
        properties.put("requesterPhone", orderRequest.getRequester().getPhone());

        StringBuilder sb = new StringBuilder(" <ul style=\"margin: 0; padding: 0;\">");
        String[] templates = orderRequest.getTemplates();
        for (int i = 0; i < templates.length; i++) {
            sb.append("<li style=\"list-style: square inside none; margin: 0; padding: 0;\">").append(templates[i]).append("</li>");
        }
        sb.append("</ul>");
        properties.put("formatsRequested", sb.toString());

        StringBuilder assetsList = new StringBuilder("<ul style=\"margin: 0; padding: 0;\">");
        String[] assets = orderRequest.getAssets();
        for (int i = 0; i < assets.length; i++) {
            assetsList.append("<li style=\"list-style: square inside none; margin: 0; padding: 0;\">").append(assets[i].substring(assets[i].lastIndexOf("/") + 1)).append("</li>");
        }
        assetsList.append("</ul>");
        properties.put("assetsOrdered", assetsList.toString());
        return properties;
    }
}
