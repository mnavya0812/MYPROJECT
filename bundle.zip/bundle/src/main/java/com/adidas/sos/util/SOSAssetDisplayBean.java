package com.adidas.sos.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.Value;
import javax.jcr.ValueFormatException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.dam.api.Asset;

public class SOSAssetDisplayBean implements java.io.Serializable {

	private static final Logger log = LoggerFactory.getLogger(SOSAssetDisplayBean.class);
	private static final String SOS_ORDER_PATH = "/content/usergenerated/sosorders/";
	protected String sosOrderNum;
	protected SlingHttpServletRequest slingRequest;
	protected Session session;
	protected Node sosOrderNode;
	public String[] requestedFormats;
	
	private static final String SOS_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss"; 

	public String getSosOrderNum() {
		return sosOrderNum;
	}

	public void setSosOrderNum(String sosOrderNum) {
		this.sosOrderNum = sosOrderNum;
	}

	public SlingHttpServletRequest getSlingRequest() {
		return slingRequest;
	}

	public void setSlingRequest(SlingHttpServletRequest slingRequest) throws PathNotFoundException, RepositoryException {
		this.slingRequest = slingRequest;
		setSession(slingRequest.getResourceResolver().adaptTo(Session.class));
		setSosOrderNode();
	}



	public Session getSession() {
		return session;
	}

	public void setSession(Session session){
		 this.session = session;
	}
	
	
	public Node getSosOrderNode() throws PathNotFoundException, RepositoryException{
		
		return session.getNode(SOS_ORDER_PATH + sosOrderNum);		
	}
	
	private void setSosOrderNode() throws PathNotFoundException, RepositoryException {
		sosOrderNode = session.getNode(SOS_ORDER_PATH + sosOrderNum);
		
	}
	
	
	
	public  ArrayList<Asset> getFetchAndDisplayAssets() {
		ArrayList<Asset> assetList = new ArrayList<Asset>();
		javax.jcr.Value[] values;

		try {
			values = sosOrderNode.getProperty("assetPaths").getValues();
			for (int i = 0; i < values.length; i++) {
				Resource assetRes = slingRequest.getResourceResolver().getResource(values[i].getString());
				if (assetRes != null) {
					Asset asset = assetRes.adaptTo(Asset.class);
					assetList.add(asset);
				}
			}
		} catch (ValueFormatException e) {

		} catch (PathNotFoundException e) {

		} catch (RepositoryException e) {

		}
		return assetList;
	}
	
	
	public String[] getRequestedFormats() throws ValueFormatException, PathNotFoundException, RepositoryException{
		
		Value[] values  = sosOrderNode.getProperty("requestedTemplates").getValues();
		String[] requestedTemplates = new String[values.length];
		
		for (int i = 0; i < values.length; i++) {
			requestedTemplates[i] = values[i].getString();
		}
		return requestedTemplates;		
	}
	
	public String getEditedFormats() throws ValueFormatException, IllegalStateException, RepositoryException{
		Value[] values  = sosOrderNode.getProperty("requestedTemplates").getValues();
		StringBuffer editedFormats = new StringBuffer();
		
		for (int i = 0; i < values.length; i++) {
			
			if (i == values.length ) {
				editedFormats.append(values[i].getString());
			}
			else
			editedFormats.append(values[i].getString()).append(",")  ;
		}
		
		return editedFormats.toString();
	}
	
	public String getOrderDate() throws PathNotFoundException, RepositoryException{
		
		return sosOrderNode.getProperty("orderDate").getString();
	}
	
	public String getRequesterName() throws PathNotFoundException, RepositoryException{
		
		return sosOrderNode.getProperty("requesterName").getString();
	}
	
	public String getRequesterAddress1() throws PathNotFoundException, RepositoryException{
		
		return sosOrderNode.getProperty("requesterAddress1").getString();
	}
	public String getRequesterAddress2() throws PathNotFoundException, RepositoryException{
		
		return sosOrderNode.getProperty("requesterAddress2").getString();
	}
	
	public String getRequesterPhone() throws PathNotFoundException, RepositoryException{
		
		return sosOrderNode.getProperty("requesterPhone").getString();
	}
	
	public String getRequesterEmail() throws PathNotFoundException, RepositoryException{
		
		return sosOrderNode.getProperty("requesterEmail").getString();
	}
	public String getOrderNumber() throws PathNotFoundException, RepositoryException{
		
		return sosOrderNode.getProperty("orderNumber").getString();
	}
	public String getExpirationDate() throws PathNotFoundException, RepositoryException{
		
		return sosOrderNode.getProperty("expirationDate").getString();
	}
	
	public String getRequesterDivision() throws PathNotFoundException, RepositoryException{
		
		return sosOrderNode.getProperty("requesterDivision").getString();
	}
	public String getRequesterTeam() throws PathNotFoundException, RepositoryException{
		
		return sosOrderNode.getProperty("requesterTeam").getString();
	}
	
	public boolean getOrderExpiredFlag(){
		
		boolean orderExpiredFlag = false;
		SimpleDateFormat sdf = new SimpleDateFormat(SOS_DATE_FORMAT);
		try {
			Date expDateFromRequest = sdf.parse(getExpirationDate());
			
			if(expDateFromRequest.before(Calendar.getInstance().getTime())){
				orderExpiredFlag =  true;
			}
		} catch (PathNotFoundException e) {
			log.error(e.getMessage());
		} catch (ParseException e) {
			log.error(e.getMessage());
		} catch (RepositoryException e) {
			log.error(e.getMessage());
		}
		return orderExpiredFlag;
		
	}
	
}
