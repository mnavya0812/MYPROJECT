package com.adidas.sos.servlets;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.UnsupportedRepositoryOperationException;
import javax.jcr.ValueFormatException;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;

import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.jackrabbit.api.security.user.User;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adidas.dam.services.SOSAdidasService;
import com.day.cq.dam.api.Asset;

/**
 * @author prabathi
 *  Contains methods to download Assets when user clicks on any link on the Asset Display Page
 */

@SlingServlet(paths="/bin/adidas/downloadAsset", methods = "POST", metatype=true)
public class SOSDownloadAssetServlet extends SlingAllMethodsServlet {

	private static final Logger log = LoggerFactory.getLogger(SOSDownloadAssetServlet.class);

	
	private static final String SOS_ORDER_PATH = "/content/usergenerated/sosorders/";
			

	@Reference
	private ResourceResolverFactory resourceResolverFactory;
	
	 private     	ResourceResolver resourceResolver = null;
	 
	 private Map<String, InputStream> dataMap ;
	 
	 private Resource rs = null;
	 
	 HashMap<String, String> formatMapper = null;
	 
	    @Reference
	    SOSAdidasService sosService;
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {


		formatMapper = new HashMap<String, String>();
		formatMapper.put("high_resolution_jpeg", sosService.getHighResJpeg());
		formatMapper.put("low_resolution_jpeg", sosService.getLowResJpeg());
		formatMapper.put("cmyk_tff", sosService.getCmykTff());
		formatMapper.put("rgb_tff", sosService.getRgbTff());
		formatMapper.put("pdf", sosService.getPdf());
		formatMapper.put("png", sosService.getPng());
		
		
		dataMap = new HashMap<String, InputStream>();
		
		try {
			
			resourceResolver = request.getResourceResolver();
			
			String assetPath = request.getParameter("asset");
			String format = request.getParameter("format");
			String sosOrderNum = request.getParameter("sosOrderNum");		 
			
			
			// Download all the assets if asset path is null
			if (assetPath == null) {
				fetchAllAssets(sosOrderNum,format,request);
			}
			else {
				
				rs = resourceResolver.getResource(assetPath);
				
				Asset asset = rs.adaptTo(Asset.class);   
             
				InputStream data = null;
			 
			 //check if the required rendition exists in rep
				String renditionName = asset.getName().replaceAll(".psd", "") + formatMapper.get(format);
				if (asset.getRendition(renditionName) != null) {
				 data = asset.getRendition(renditionName).getStream();
					
		            String name =renditionName; 
		                         
		           //Add to map
		            dataMap.put(name, data); // key is fileName and value is inputStream - this will all be placed in ZIP file
		            
		            //Increase download count by 1
		            incrementUserDownloadCount(sosOrderNum,1);
			 	}
				
			}
			
	            byte[] zip = zipFiles(dataMap);
				ServletOutputStream sos = response.getOutputStream();
		         
		        response.setContentType("application/zip");
		        response.setHeader("Content-Disposition", "attachment;filename=dam.zip");
		         
		         
		        // Write bytes to tmp file.
		        sos.write(zip);
		        sos.flush();    
		        log.info("The ZIP is sent" ) ;  
		
			
		} catch (Exception e) {
			log.error("SOSDownloadAssetServlet.java###"+e.getMessage());
		}

		//response.getWriter().write("<h1>The request Parameters recvd from JSP</h1>"+ request.getParameter("asset")+"<br>"+request.getParameter("media"));
		
		
	}
	
	
	private void fetchAllAssets(String sosOrderNum, String format, SlingHttpServletRequest request) {
		
		ArrayList<Asset> assetList = null;
        if (sosOrderNum != null) 
         {
			Session session = resourceResolver.adaptTo(Session.class);
			try {
				Node sosOrderNode = session.getNode( SOS_ORDER_PATH + sosOrderNum);
				
				 if (sosOrderNode != null) 
	              { 
					 prepareAssetsForDownload(sosOrderNode,request,format );
	              }
			} catch (PathNotFoundException e) {
				log.error(e.getMessage());
			} catch (RepositoryException e) {
				log.error(e.getMessage());
			}
         }
		
	}
	
	
	private ArrayList<Asset> prepareAssetsForDownload(Node sosOrderNode,SlingHttpServletRequest slingRequest, String format ) 
    
    {
	// out.write("Inside fetchAndDisplayAssets method" );
     ArrayList<Asset> assetList = new ArrayList<Asset>();
	 javax.jcr.Value[] values;
	 long downloadCount = 0;
	
    try 
      {
		values = sosOrderNode.getProperty("assetPaths").getValues();
		for ( int i = 0; i < values.length; i++ ) 
         {
             Resource assetRes =  resourceResolver.getResource(values[i].getString());
             if (assetRes != null ) 
                {
                 Asset asset = assetRes.adaptTo(Asset.class);
                 
    			 InputStream data = null;
    	           
    			//check if the required rendition exists in rep
    			 String renditionName = asset.getName().replaceAll(".psd", "") + formatMapper.get(format);
 					if (asset.getRendition(renditionName) != null){
 					 data = asset.getRendition(renditionName).getStream();
 	    			
 					 String name =renditionName; 
     	                         
 					 //Add to map
 					 dataMap.put(name, data);
 					 downloadCount+=1;
 					}
    				
                }
		 }
		
		incrementUserDownloadCount(sosOrderNode.getName(),downloadCount);
	  } 
    catch (ValueFormatException e) {
    	log.error(e.getMessage());
	} catch (PathNotFoundException e) {
		log.error(e.getMessage());
	} catch (RepositoryException e) {
		log.error(e.getMessage());
	}
      return    assetList;                                  
   }


	/**
	 * Method to zip files
	 * @param data
	 * @return
	 * @throws IOException
	 */
	private byte[] zipFiles(Map data) throws IOException {
        
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ZipOutputStream zos = new ZipOutputStream(baos);
        byte bytes[] = new byte[2048];
        Iterator<Map.Entry<String, InputStream>> entries = data.entrySet().iterator();
         
        while (entries.hasNext()) {
            Map.Entry<String, InputStream> entry = entries.next();
             
            String fileName =(String) entry.getKey(); 
            InputStream is1 =(InputStream) entry.getValue(); 
             
            BufferedInputStream bis = new BufferedInputStream(is1);
 
            //populate the next entry of the ZIP with the AEM DAM asset
            zos.putNextEntry(new ZipEntry(fileName));
 
            int bytesRead;
            while ((bytesRead = bis.read(bytes)) != -1) {
                zos.write(bytes, 0, bytesRead);
                
            }
            zos.closeEntry();
            bis.close();
            is1.close();
       
        }
         
       zos.flush();
        baos.flush();
        zos.close();
        baos.close();
 
        return baos.toByteArray();
    }
    
	  
	//setFilesDownloaded(currentUser.getProperty(sosOrderNum+"_"+"filesDownloaded")[0].getLong());	
	/**
	 * Increments the asset download count (for current asset page) for the currently logged in user
	 * @param sosOrderNum
	 * @param downloadCount
	 */
	private void incrementUserDownloadCount(String sosOrderNum,long downloadCount)
	{
		User currentUser = resourceResolver.adaptTo(User.class);
		 Session session = this.resourceResolver.adaptTo(Session.class);
		 try {

			 Node userNode = session.getNode(currentUser.getPath());
			 Node parentSOS = userNode.getNode("sosorders");
			 
			if ( parentSOS.hasProperty(sosOrderNum+"_"+"filesDownloaded")) {
				
				long oldCount = parentSOS.getProperty(sosOrderNum+"_"+"filesDownloaded").getLong();
				  long updatedCount = oldCount + downloadCount;
				  parentSOS.setProperty(sosOrderNum+"_"+"filesDownloaded", String.valueOf(updatedCount));

			}
			else{
				parentSOS.setProperty(sosOrderNum+"_"+"filesDownloaded", String.valueOf(downloadCount));
			}
							  
			  session.save();
			
		} catch (UnsupportedRepositoryOperationException e) {
			log.error("SOSDownloadAssetServlet.java###"+e.getMessage());
		} catch (RepositoryException e) {
			log.error("SOSDownloadAssetServlet.java###"+e.getMessage());
		}
	}
}
