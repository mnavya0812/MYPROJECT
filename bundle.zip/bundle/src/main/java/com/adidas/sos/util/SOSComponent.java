package com.adidas.sos.util;

/**
 * @author prabathi
 * Represents the information present in the "components" section of the "Asset Query" JSON Response
 */
public class SOSComponent extends SOSAsset {

	String componentType;
	String componentStatus;
	
	public String getComponentType() {
		return componentType;
	}

	public void setComponentType(String componentType) {
		this.componentType = componentType;
	}

	public String getComponentStatus() {
		return componentStatus;
	}

	public void setComponentStatus(String componentStatus) {
		this.componentStatus = componentStatus;
	}
}
