package com.adidas.sos.util;

/**
 * @author prabathi Represents the JSON request/response that will received/sent
 * to SOS
 */
public class SOSQueryRequestResponse {

    String filename;
    String color;
    String team;
    String league;
    String graphic_code;
    String playerNumber;
    String optional;
    String style;
    String pose;
    String familyColor;
    String components[];

    String assetStatus;
    SOSAsset asset;
    SOSAsset assetComponents[];

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getTeam() {
        return team;
    }

    public void setTeam(String team) {
        this.team = team;
    }

    public String getLeague() {
        return league;
    }

    public void setLeague(String league) {
        this.league = league;
    }

    public String getGraphic_code() {
        return graphic_code;
    }

    public void setGraphic_code(String graphic_code) {
        this.graphic_code = graphic_code;
    }

    public String getPlayerNumber() {
        return playerNumber;
    }

    public void setPlayerNumber(String playerNumber) {
        this.playerNumber = playerNumber;
    }

    public String getOptional() {
        return optional;
    }

    public void setOptional(String optional) {
        this.optional = optional;
    }

    public String getStyle() {
        return style;
    }

    public void setStyle(String style) {
        this.style = style;
    }

    public String getPose() {
        return pose;
    }

    public void setPose(String pose) {
        this.pose = pose;
    }

    public String getFamilyColor() {
        return familyColor;
    }

    public void setFamilyColor(String familyColor) {
        this.familyColor = familyColor;
    }

    public String[] getComponents() {
        return components;
    }

    public void setComponents(String[] components) {
        this.components = components;
    }

    public String getAssetFileName() {

        StringBuilder assetName = new StringBuilder();
        assetName.append(style).append("_").append(team).append("_").append(graphic_code).append("_");
        assetName.append(color).append("_").append(pose).append(".psd");

        return assetName.toString();
    }

    public String getAssetStatus() {
        return assetStatus;
    }

    public void setAssetStatus(String asset_status) {
        this.assetStatus = asset_status;
    }

    public SOSAsset getAsset() {
        return asset;
    }

    public void setAsset(SOSAsset asset) {
        this.asset = asset;
    }

    public SOSAsset[] getAssetComponents() {
        return assetComponents;
    }

    public void setAssetComponents(SOSAsset[] assetComponents) {
        this.assetComponents = assetComponents;
    }

}
