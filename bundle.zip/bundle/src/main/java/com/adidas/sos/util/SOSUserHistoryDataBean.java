package com.adidas.sos.util;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.ValueFactory;

import org.apache.jackrabbit.api.security.user.User;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author prabathi
 *  Used to track User access to the Asset Pick Up Page
 */
public class SOSUserHistoryDataBean implements Serializable {

	private static final Logger log = LoggerFactory.getLogger(SOSUserHistoryDataBean.class);
	protected SlingHttpServletRequest slingRequest;
	protected String sosOrderNum;

	protected String viewStatus;
	protected String firstViewedDate;
	protected String lastViewedDate;
	protected String filesDownloaded = "No";
	
	protected ValueFactory  valueFactory;
	protected Session session;
	
	String SOS_DATE_FORMAT = "yyyy-MM-dd HH:mm z";
	SimpleDateFormat formatter = new SimpleDateFormat(SOS_DATE_FORMAT);

	public SlingHttpServletRequest getSlingRequest() {
		return slingRequest;
	}

	public void setSlingRequest(SlingHttpServletRequest slingRequest) {
		this.slingRequest = slingRequest;
		setValueFactory(slingRequest);
		recordUserAccessHistory(slingRequest);
	}

	private void setValueFactory(SlingHttpServletRequest slingRequest2) {
		 session = slingRequest.getResourceResolver().adaptTo(Session.class);
		try {
			valueFactory = session.getValueFactory();
		} catch (RepositoryException e) {
			log.error(e.getMessage());
		}
	}

	public String getSosOrderNum() {
		return sosOrderNum;
	}

	public void setSosOrderNum(String sosOrderNum) {
		this.sosOrderNum = sosOrderNum;
	}

	public String getFirstViewedDate() {
		return firstViewedDate;
	}

	public void setFirstViewedDate(String firstViewedDate) {
		this.firstViewedDate = firstViewedDate;
	}

	public String getLastViewedDate() {
		return lastViewedDate;
	}

	public void setLastViewedDate(String lastViewedDate) {
		this.lastViewedDate = lastViewedDate;
	}

	public String getViewStatus() {
		return viewStatus;
	}

	public void setViewStatus(String viewStatus) {
		this.viewStatus = viewStatus;
	}

	public String getFilesDownloaded() {
		return filesDownloaded;
	}

	public void setFilesDownloaded(String filesDownloaded) {
		this.filesDownloaded = filesDownloaded;
	}

	/**
	 * 
	 * @param slingRequest
	 */
	private void recordUserAccessHistory(SlingHttpServletRequest slingRequest) {

		ResourceResolver resourceResolver = slingRequest.getResourceResolver();

		User currentUser = resourceResolver.adaptTo(User.class);
		String currentTime = formatter.format(Calendar.getInstance().getTime());
		try {
			
			log.info("SOSUserHistoryDataBean.java : Current User path is "+currentUser.getPath());
			Node userNode = session.getNode(currentUser.getPath());
			//Create SOS Order node under User Node
			
			if (userNode.hasNode("sosorders")) {
				
				Node parentSOS = userNode.getNode("sosorders");
				
					if (parentSOS.hasProperty(sosOrderNum)) {
						setViewStatus("Viewed");
						setFirstViewedDate(parentSOS.getProperty(sosOrderNum+"_"+"firstViewedDate").getString());	
						setLastViewedDate(currentTime);
						parentSOS.setProperty(sosOrderNum+"_"+"lastViewedDate", currentTime);
						
						if (parentSOS.getProperty(sosOrderNum+"_"+"filesDownloaded") != null) {
							
							setFilesDownloaded(parentSOS.getProperty(sosOrderNum+"_"+"filesDownloaded").getString());	
						}
					}
					else{
						
						setViewStatus("Viewed");
						setFirstViewedDate(currentTime);
						setLastViewedDate(currentTime);
						parentSOS.setProperty(sosOrderNum, "viewed");
						parentSOS.setProperty(sosOrderNum+"_"+"firstViewedDate", currentTime);
						parentSOS.setProperty(sosOrderNum+"_"+"lastViewedDate", currentTime);
						
					}
				
			}
			else{
				Node parentSOS = userNode.addNode("sosorders");
				setViewStatus("Viewed");
				setFirstViewedDate(currentTime);
				setLastViewedDate(currentTime);
				parentSOS.setProperty(sosOrderNum, "viewed");
				parentSOS.setProperty(sosOrderNum+"_"+"firstViewedDate", currentTime);
				parentSOS.setProperty(sosOrderNum+"_"+"lastViewedDate", currentTime);
			
			}
			
			
			session.save();
			log.info("SOSUserHistoryDataBean.java ::: Successfully persisted SOS order related info to user node : "+currentUser.getPath());
		} catch (RepositoryException e) {
			log.error("SOSUserHistoryDataBean.java ::: Error occured while writing sosorder information to User node");
			log.error(e.getMessage());
		}
		catch(Exception e){
			log.error("SOSUserHistoryDataBean.java ::: Error occured while writing sosorder information to User node");
			log.error(e.getMessage()); 
		}

	}
}
