package com.adidas.aem.migration;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by bear on 12/24/15.
 */
public class Constants {

    public static final String PICKLIST_TAG_PATH = "/etc/tags/adidas-picklists";
    public static final String ADIDAS_TAG_PATH = "/etc/tags/adidas";
    public static final SimpleDateFormat weekBasedFolderFormat = new SimpleDateFormat("/YYYY/ww");
    public static final SimpleDateFormat versionDateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss z");
    public static final SimpleDateFormat commentDateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm z");
    public static final Calendar lastActiveDate = Calendar.getInstance();
    public static final Calendar lastVersionDate = Calendar.getInstance();
    public static final ArrayList<String> inactiveMigrations = new ArrayList<String>();
    public static final ArrayList<String> activeMigrations = new ArrayList<String>();
    // art document - asset group mappings
    public static final Map<String,String> artDocumentGroupMap = new HashMap<String,String>();

    static {
        lastActiveDate.add(Calendar.YEAR,-5);   //only active items within the last 5 years
        lastVersionDate.add(Calendar.YEAR,-7);  // only versions within the last 7 years
        activeMigrations.add("Adidas Branded Apparel".toLowerCase());
        activeMigrations.add("Adidas Branded Headwear".toLowerCase());
        activeMigrations.add("Adidas Golf Apparel".toLowerCase());
        activeMigrations.add("Code Blue Assets".toLowerCase());
        activeMigrations.add("Headwear Not Carryover Assets".toLowerCase());
        activeMigrations.add("Hold - Pending Styles".toLowerCase());
        activeMigrations.add("Mitchell and Ness".toLowerCase());
        activeMigrations.add("MLB Apparel".toLowerCase());
        activeMigrations.add("MLB Headwear".toLowerCase());
        activeMigrations.add("MLS Jerseys".toLowerCase());
        activeMigrations.add("MLS Jersey Players Specific".toLowerCase());
        activeMigrations.add("NBA Apparel".toLowerCase());
        activeMigrations.add("NBA Headwear".toLowerCase());
        activeMigrations.add("NBA Jersey Blank".toLowerCase());
        activeMigrations.add("NBA Jersey Any Name/Your Name".toLowerCase());
        activeMigrations.add("NBA Jersey - Player Specific".toLowerCase());
        activeMigrations.add("NCAA Apparel".toLowerCase());
        activeMigrations.add("NCAA Headwear".toLowerCase());
        activeMigrations.add("NCAA Jerseys".toLowerCase());
        activeMigrations.add("Neutrals".toLowerCase());
        activeMigrations.add("NHL Apparel".toLowerCase());
        activeMigrations.add("NHL Headwear".toLowerCase());
        activeMigrations.add("NHL Jersey blanks".toLowerCase());
        activeMigrations.add("NHL Jerseys - Player Specific".toLowerCase());
        activeMigrations.add("Reebok Branded Apparel".toLowerCase());
        activeMigrations.add("Reebok Branded Headwear".toLowerCase());
        activeMigrations.add("UFC Apparel".toLowerCase());
        activeMigrations.add("UFC Headwear".toLowerCase());

        inactiveMigrations.add("Apparel Carryover Assets".toLowerCase());
        inactiveMigrations.add("Apparel Not Carryover Assets".toLowerCase());
        inactiveMigrations.add("Atlantis Images".toLowerCase());
        inactiveMigrations.add(" Close Outs".toLowerCase());
        inactiveMigrations.add("COLLATERAL Images".toLowerCase());
        inactiveMigrations.add("Confidential Art and Tech Packs".toLowerCase());
        inactiveMigrations.add("Cowboys".toLowerCase());
        inactiveMigrations.add("Cricket Apparel".toLowerCase());
        inactiveMigrations.add("Cricket Headwear".toLowerCase());
        inactiveMigrations.add("GSI Only Lifestyle".toLowerCase());
        inactiveMigrations.add("Headwear Carryover Assets".toLowerCase());
        inactiveMigrations.add("High School Apparel".toLowerCase());
        inactiveMigrations.add("Hold - SAMMS (Art/Style Approval)".toLowerCase());
        inactiveMigrations.add("Lifestyle Specials".toLowerCase());
        inactiveMigrations.add("MLB Apparel".toLowerCase());
        inactiveMigrations.add("MLB Headwear".toLowerCase());
        inactiveMigrations.add("NFL Apparel".toLowerCase());
        inactiveMigrations.add("NFL Headwear".toLowerCase());
        inactiveMigrations.add("NFL Jersey".toLowerCase()); //TODO check this?
        inactiveMigrations.add("NFL Jerseys - Blank".toLowerCase());
        inactiveMigrations.add("NFL Jerseys - Player Specific".toLowerCase());
        inactiveMigrations.add("Outerstuff Specials".toLowerCase());
        inactiveMigrations.add("Purged Graphics".toLowerCase());
        inactiveMigrations.add("Rugby Apparel".toLowerCase());
        inactiveMigrations.add("Training Documents".toLowerCase());

        artDocumentGroupMap.put("Adidas Branded Apparel","adidas-picklists:art-document-type/digital-image-not-neutral");
        artDocumentGroupMap.put("Adidas Branded Headwear","adidas-picklists:art-document-type/digital-image-not-neutral");
        artDocumentGroupMap.put("Adidas Golf Apparel","adidas-picklists:art-document-type/digital-image-not-neutral");
        artDocumentGroupMap.put("Code Blue Assets","adidas-picklists:art-document-type/digital-image-not-neutral");
        artDocumentGroupMap.put("Headwear Not Carryover Assets","adidas-picklists:art-document-type/digital-image-not-neutral");
        artDocumentGroupMap.put("Hold - Pending Styles","adidas-picklists:art-document-type/digital-image-not-neutral");
        artDocumentGroupMap.put("Mitchell and Ness","adidas-picklists:art-document-type/digital-image-not-neutral");
        artDocumentGroupMap.put("MLS Apparel","adidas-picklists:art-document-type/digital-image-not-neutral");
        artDocumentGroupMap.put("MLS Headwear","adidas-picklists:art-document-type/digital-image-not-neutral");
        artDocumentGroupMap.put("MLS Jereys","adidas-picklists:art-document-type/digital-image-not-neutral");
        artDocumentGroupMap.put("MLS Jersey Player Specific","adidas-picklists:art-document-type/digital-image-not-neutral");
        artDocumentGroupMap.put("NBA Apparel","adidas-picklists:art-document-type/digital-image-not-neutral");
        artDocumentGroupMap.put("NBA Headwear","adidas-picklists:art-document-type/digital-image-not-neutral");
        artDocumentGroupMap.put("NBA Jersey - Blank","adidas-picklists:art-document-type/digital-image-not-neutral");
        artDocumentGroupMap.put("NBA Jerseys - Any Name/Your Name","adidas-picklists:art-document-type/digital-image-not-neutral");
        artDocumentGroupMap.put("NBA Jerseys - Player Specific","adidas-picklists:art-document-type/digital-image-not-neutral");
        artDocumentGroupMap.put("NCAA Apparel","adidas-picklists:art-document-type/digital-image-not-neutral");
        artDocumentGroupMap.put("NCAA Headwear","adidas-picklists:art-document-type/digital-image-not-neutral");
        artDocumentGroupMap.put("NCAA Jerseys","adidas-picklists:art-document-type/digital-image-not-neutral");
        artDocumentGroupMap.put("Neutrals","adidas-picklists:art-document-type/digital-image-neutral");
        artDocumentGroupMap.put("NHL Apparel","adidas-picklists:art-document-type/digital-image-not-neutral");
        artDocumentGroupMap.put("NHL Headwear","adidas-picklists:art-document-type/digital-image-not-neutral");
        artDocumentGroupMap.put("NHL Jersey Blanks","adidas-picklists:art-document-type/digital-image-not-neutral");
        artDocumentGroupMap.put("NHL Jerseys - Player Specific","adidas-picklists:art-document-type/digital-image-not-neutral");
        artDocumentGroupMap.put("Production Art Graphics","adidas-picklists:art-document-type/format-page");
        artDocumentGroupMap.put("Reebok Branded Apparel","adidas-picklists:art-document-type/digital-image-not-neutral");
        artDocumentGroupMap.put("Reebok Branded Headwear","adidas-picklists:art-document-type/digital-image-not-neutral");
        artDocumentGroupMap.put("TechPacks - Adidas","adidas-picklists:art-document-type/apparel-production-art");
        artDocumentGroupMap.put("Techpacks - Finished Goods","adidas-picklists:art-document-type/apparel-production-art");
        artDocumentGroupMap.put("Techpacks - Headwear","adidas-picklists:art-document-type/apparel-production-art");
        artDocumentGroupMap.put("Techpacks - Jerseys","adidas-picklists:art-document-type/apparel-production-art");
        artDocumentGroupMap.put("Techpacks Mitchell and Ness","adidas-picklists:art-document-type/apparel-production-art");
        artDocumentGroupMap.put("UFC Apparel","adidas-picklists:art-document-type/digital-image-not-neutral");
        artDocumentGroupMap.put("UFC Headwear","adidas-picklists:art-document-type/digital-image-not-neutral");

    }
}
