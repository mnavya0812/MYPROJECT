package com.adidas.aem.migration.process;

import java.util.concurrent.Callable;

public interface AssetProcessThread extends Callable{
}
