package com.adidas.aem.migration.widen;

import java.util.Calendar;

/**
 * Created by bear on 11/29/15.
 */
public class Order {

    private String number;

    private Calendar date;
    private String sender;
    private String recipient;
    public Order(String number, Calendar date, String sender, String recipient) {
        this.number = number;
        this.date = date;
        this.sender = sender;
        this.recipient = recipient;
    }

    public Order() {

    }

    public void setNumber(String number) {
        this.number = number;
    }

    public void setDate(Calendar date) {
        this.date = date;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getSender() {
        return sender;
    }

    public Calendar getDate() {
        return date;
    }

    public String getNumber() {
        return number;
    }
}
