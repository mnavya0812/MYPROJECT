package com.adidas.aem.migration;

import com.adidas.aem.migration.process.AssetProcessThread;
import com.adidas.dam.services.SAMMSDataService;
import com.adidas.dam.util.Helper;
import com.adidas.dam.util.SLDConstants;
import com.day.cq.commons.jcr.JcrUtil;
import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.AssetManager;
import com.day.cq.dam.api.Revision;
import com.day.cq.replication.ReplicationActionType;
import com.day.cq.replication.ReplicationException;
import com.day.cq.replication.Replicator;
import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowService;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.Workflow;
import com.day.cq.workflow.exec.WorkflowData;
import com.day.cq.workflow.model.WorkflowModel;
import com.google.common.base.Strings;
import org.apache.commons.lang3.SystemUtils;
import org.apache.sling.api.resource.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.activation.FileDataSource;
import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.UnsupportedRepositoryOperationException;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;

/**
 * Thread to process an asset
 */
public class OfflineAssetProcessThread implements AssetProcessThread {

    private static final String NEUTRAL_TEAM_CODE = "NEU";

    private static final String ART_DOC_TYPE_FORMAT_PAGE = "adidas-picklists:art-document-type/format-page";
    private static final String ART_DOC_TYPE_DETAIL_SHEET = "adidas-picklists:art-document-type/detail-sheet";
    private static final String ART_DOC_TYPE_SEPARATIONS = "adidas-picklists:art-document-type/separations";
    private static final String ART_DOC_TYPE_PRINT_GUIDE = "adidas-picklists:art-document-type/print-guide";
    private static final String ART_DOC_TYPE_WIRE_ART = "adidas-picklists:art-document-type/wire-art";
    private static final String ART_DOC_TYPE_NEUTRAL = SLDConstants.ArtDocumentType.NEUTRAL.code;
    private static final String ART_DOC_TYPE_NOT_NEUTRAL = SLDConstants.ArtDocumentType.NOT_NEUTRAL.code;
    private final String aemTargetFolder;
    private final String assetPath;
    private final MigrationService migrationService;
    private final String sourceRootPath;
    private final boolean publishAssets;
    private final SAMMSDataService sammsDataService;
    private final boolean runSimpleWorkflow;
    private final boolean isReRun ;
    private final String lastIngestionRunDate;
    private ResourceResolver resolver;
    private final WorkflowService workflowService;
    private final Replicator replicator;
    private final ResourceResolverFactory resolverFactory;
    private boolean sortByDate;
    private ProcessedResults results;
    private static final Logger log = LoggerFactory.getLogger(OfflineAssetProcessThread.class);

    private boolean invokeDamWorkflow = false;
    private boolean replaceExisting = false;

    public static final String B_SLASH = "\\";
    public static final String F_SLASH = "/";

    public static final String SLASH = SystemUtils.IS_OS_WINDOWS ? B_SLASH  : F_SLASH;

    private static final Object assetCreationLock = new Object();


    OfflineAssetProcessThread(ResourceResolverFactory resolverFactory, String assetPath, String aemTargetFolder,
                              boolean sortByDate, WorkflowService workflowService, Replicator replicator,
                              SAMMSDataService sammsDataService, boolean runDUA, boolean lastVersionOnly,
                              boolean replaceExisting, MigrationService migrationService,
                              String sourceRootPath, boolean publishAssets, boolean runSimpleWorkflow ,String lastIngestionRunDate ,boolean isReRun) {
        log.debug("Constructing...");
        this.resolverFactory = resolverFactory;
        this.aemTargetFolder = aemTargetFolder;
        this.sortByDate = sortByDate;
        this.assetPath = assetPath;
        this.workflowService = workflowService;
        this.replicator = replicator;
        this.invokeDamWorkflow = runDUA;
        this.replaceExisting = replaceExisting;
        this.migrationService = migrationService;
        this.sourceRootPath = sourceRootPath;
        this.publishAssets = publishAssets;
        this.sammsDataService = sammsDataService;
        this.runSimpleWorkflow = runSimpleWorkflow;
        this.lastIngestionRunDate = lastIngestionRunDate;
        this.isReRun = isReRun;
        log.debug("Thread created for " + assetPath);
    }

    @Override
    public ProcessedResults call() {

        log.info("File: " + assetPath);
        File asset = new File(assetPath);

        if (!asset.exists()) {
            log.error("Cannot find file " + assetPath);
            return null;
        }

        try {
            this.resolver = resolverFactory.getAdministrativeResourceResolver(null);
            Session session = resolver.adaptTo(Session.class);
            session.getWorkspace().getObservationManager().setUserData("changedByWorkflowProcess");
        } catch (LoginException e) {
            log.error("Cannot get resolver. " + e.getMessage());
            return results;
        }  catch (UnsupportedRepositoryOperationException e) {
        	log.error("Unsupported Repository Operation:::" + e.getMessage());
		} catch (RepositoryException e) {
			log.error("Repository Exception :::" + e.getMessage());
		}

        log.debug("Setting thread name");
        Thread thisThread = Thread.currentThread();
        thisThread.setName(asset.getName());

        results = new ProcessedResults();

        String updateAssetWorkflowModel = "/etc/workflow/models/simplified-migration-update-asset/jcr:content/model";
        String damUpdateAssetWorkflowModel = "/etc/workflow/models/dam/update_asset/jcr:content/model";

        String parentFolderPath = asset.getParentFile().getPath();

        String assetFileName;
        assetFileName = asset.getName();
        // remove starting $ from some files
        if (assetFileName.startsWith("$")) {
            assetFileName = assetFileName.replaceFirst("$", "");
        }

        Calendar lastModifiedDate = Calendar.getInstance();
        long timeInMills = asset.lastModified();
        lastModifiedDate.setTimeInMillis(timeInMills);
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyy HH:mm:ss");
        log.debug("Last Modified: " + sdf.format(lastModifiedDate.getTime()));

        // get the metadata map
        log.info("Getting metadata for AEM");
        HashMap<String, Object> metadataMap = null;
        boolean isDINeutral = false;
        try {
            metadataMap = Helper.getMetadataFromFileName(assetFileName, resolver);

            // Neutral team code needs art document tye for DI Neutral
            String teamCode = "";
            if (metadataMap != null) {
                // check if neutral or not neutral
                teamCode = (String) metadataMap.get(SLDConstants.TEAM);
                log.debug("teamCode: " + teamCode);
                isDINeutral = teamCode != null && teamCode.toLowerCase().equals(NEUTRAL_TEAM_CODE.toLowerCase());
                metadataMap.put(SLDConstants.DI_CONFIDENTIAL, SLDConstants.NOT_CONFIDENTIAL);
                metadataMap.put(SLDConstants.ACTIVE, "true");
                metadataMap.put("dc:title", assetFileName);
                metadataMap.put(SLDConstants.FILE_NAME, assetFileName.toUpperCase());
                metadataMap.put(SLDConstants.DAM_TAGS, new String[]{"adidas:everyone"});
                metadataMap.put(SLDConstants.ASSET_DRM, SLDConstants.ASSET_DRM_PATH + ".html");
            }
        } catch (Exception e) {
            log.error(e.getClass() + ": " + e.getMessage() + " | " + e.getCause().getMessage());
            return null;
        }


        String targetAEMFolder = aemTargetFolder;
        String artDocumentType = "";
        log.debug("Getting art document type");
        if (sortByDate) {
            // add everyone tag so that it is appears on the asset share page
            if (isDINeutral) {
                // DI Neutrals go to neutrals folder
                if (targetAEMFolder.contains("annual")) {
                    targetAEMFolder = targetAEMFolder.replace("annual", SLDConstants.DI_NEUTRALS);
                } else {
                    targetAEMFolder = targetAEMFolder + "/" + SLDConstants.DI_NEUTRALS;
                }
                artDocumentType = ART_DOC_TYPE_NEUTRAL;
            } else {
                // DI non Neutrals go to week based folder
                targetAEMFolder = targetAEMFolder + Constants.weekBasedFolderFormat.format(lastModifiedDate.getTime());
                artDocumentType = ART_DOC_TYPE_NOT_NEUTRAL;
            }

        } else {
            // Non-DI goes to same folder structure
            targetAEMFolder = targetAEMFolder + parentFolderPath.replace(sourceRootPath, "");
            metadataMap =  Helper.cleanMetadataForNonDi(metadataMap);
            if (assetFileName.endsWith("fmt.ai")) {
                artDocumentType = ART_DOC_TYPE_FORMAT_PAGE;
            } else if (assetFileName.endsWith("det.xlsx")) {
                artDocumentType = ART_DOC_TYPE_DETAIL_SHEET;
            } else if (assetFileName.endsWith("sep.ai") || assetFileName.endsWith("dcs.eps") || assetFileName.endsWith(".dst")) {
                artDocumentType = ART_DOC_TYPE_SEPARATIONS;
            } else if (assetFileName.endsWith("pg.pdf") || assetFileName.endsWith("eg.pdf")) {
                artDocumentType = ART_DOC_TYPE_PRINT_GUIDE;
            } else if (assetFileName.endsWith("wire.ai")) {
                artDocumentType = ART_DOC_TYPE_WIRE_ART;
            }
        }

        if (metadataMap != null && !Strings.isNullOrEmpty(artDocumentType)) {
            metadataMap.put(SLDConstants.ART_DOCUMENT_TYPE, artDocumentType);
        }

        if (targetAEMFolder.endsWith("/")) {
            targetAEMFolder = targetAEMFolder.substring(0, targetAEMFolder.lastIndexOf("/"));
        }

        String finalizedVersion = null;
        String assetPath = null;


        log.info("----- Processing -----");

        //upload version into AEM
        targetAEMFolder = cleanForAEM(targetAEMFolder.replace(B_SLASH, F_SLASH));
        assetFileName = cleanForAEM(assetFileName);
        log.debug("File name: " + assetFileName);
        log.info("Uploading to " + targetAEMFolder);
        Asset versionAsset = null;

        //if replaceExisting == false, then check if the file exists and exit if it exists.
        if (!replaceExisting) {
            Resource existingAsset = resolver.getResource(targetAEMFolder + "/" + assetFileName);
            if (existingAsset != null) {
                log.warn("Asset " + targetAEMFolder + "/" + assetFileName + " exists. Will not reprocess.");
                if (resolver.isLive()) {
                    resolver.close();
                }
                migrationService.addCompletedAsset();
                return results;
            }
        }

        //check/create folder
        try {
            synchronized (assetCreationLock) {
                resolver.refresh();
                //create parent folders
                log.debug("Ensuring " + targetAEMFolder);
                JcrUtil.createPath(targetAEMFolder, "sling:OrderedFolder", "sling:OrderedFolder", resolver.adaptTo(Session.class), true);
                resolver.commit();
            }
        } catch (javax.jcr.InvalidItemStateException e) {
            log.warn("Error ensuring path " + e.getMessage());
        } catch (RepositoryException e) {
            log.error("Could not create folder " + targetAEMFolder + ". " + e.getMessage());
        } catch (PersistenceException e) {
            log.error("Could not save folder changes. " + e.getMessage());
        }

        // Upload file
        synchronized (assetCreationLock) {
            resolver.refresh();
            versionAsset = importFile(targetAEMFolder, assetFileName, asset);
    
        }
        assetPath = versionAsset != null ? versionAsset.getPath() : null;
        log.info("Uploaded to " + assetPath);


        Node assetNode = null;
        if (versionAsset != null) {
            assetNode = versionAsset.adaptTo(Node.class);
            Node assetContentNode = null;
            Node assetMetadataNode = null;
            try {
                assetContentNode = assetNode.getNode("jcr:content");
                assetMetadataNode = assetContentNode.getNode("metadata");
            } catch (RepositoryException e) {
                log.error("Unable to access repository information. " + e.getMessage());
            }

            //save metadata for jcr:content node
            HashMap<String, Object> contentMetadataMap = new HashMap<String, Object>();
            contentMetadataMap.put(SLDConstants.ASSET_LASTMOD_DATE, lastModifiedDate);
            contentMetadataMap.put("cq:name", assetFileName);
            try {
                applyMetadata(assetContentNode, contentMetadataMap);
            } catch (RepositoryException e) {
                log.error("Unable to set content metadata. " + e.getMessage());
            } catch (PersistenceException e) {
                log.error("Cannot save content metadata. " + e.getMessage());
            }


            // save metadata for metadata node
            try {
                log.debug("Saving asset general metadata.");
                          
               if( versionAsset.getMetadata().isEmpty()){
                applyMetadata(assetMetadataNode, metadataMap);
               }
            } catch (PersistenceException e) {
                log.error("Unable to save metadata changes for " + assetPath + "/jcr:content/metadata. " + e.getMessage());
            } catch (RepositoryException e) {
                log.error("Unable to set metadata. " + e.getMessage());
            }

            // SAMMS data
            log.debug("Applying SAMMS/Data Warehouse data");
            String styleNumber = (String) metadataMap.get(SLDConstants.STYLE_NUMBER);
            String colorCode = (String) metadataMap.get(SLDConstants.COLOR_CODE);
            String graphicCode = (String) metadataMap.get(SLDConstants.GRAPHIC_CODE);
            if (!Strings.isNullOrEmpty(styleNumber) && !Strings.isNullOrEmpty(colorCode) && !Strings.isNullOrEmpty(graphicCode)) {
                try {
                    HashMap<String, String> props = sammsDataService.getPropertiesForKey(styleNumber, colorCode, graphicCode);
                    if (!props.isEmpty()) {
                        sammsDataService.updateNodeProperties(assetNode, props);
                        resolver.commit();
                    }
                } catch (LoginException e) {
                    log.error("Cannot login for SAMMS update. " + e.getMessage());
                } catch (RepositoryException e) {
                    log.error("Problem acessing SAMMS data. " + e.getMessage());
                } catch (PersistenceException e) {
                    log.error("Cannot save SAMMS data. " + e.getMessage());
                }
            }

            //start simple update asset workflow and wait for it to complete
            if (runSimpleWorkflow) {
                try {
                    WorkflowSession wfSession = workflowService.getWorkflowSession(resolver.adaptTo(Session.class));
                    WorkflowModel wfModel = wfSession.getModel(updateAssetWorkflowModel);
                    WorkflowData wfData = wfSession.newWorkflowData("JCR_PATH", assetPath);
                    Workflow workflow = wfSession.startWorkflow(wfModel, wfData);
                    log.debug("Workflow: " + workflow);
                    log.info("Simple Workflow started");
                    try {
                        while (workflow.isActive()) {
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException e) {
                                log.warn("Cannot sleep thread. " + e.getMessage());
                            }
                        }
                    } catch (Exception e) {
                        log.warn("Check for workflow failed. " + e.getMessage());
                        try {
                            Thread.sleep(10000);
                        } catch (InterruptedException e1) {
                            log.warn("Cannot sleep thread. " + e1.getMessage());
                        }
                    }
                    log.info("Simple Workflow completed");
                } catch (WorkflowException e) {
                    log.error("Unable to start simple workflow for " + assetPath + ". " + e.getMessage());
                }
            }
        } else {
            log.error("File upload failed for " + assetPath + ".");
        }

        log.info("----- Asset Processed\n");

        if (assetPath != null) {
            results.addFinalizedAsset(assetFileName, finalizedVersion);

            //start Standard DAM Update asset on final asset
            if (invokeDamWorkflow) {
                try {
                    WorkflowSession wfSession = workflowService.getWorkflowSession(resolver.adaptTo(Session.class));
                    WorkflowModel wfModel = wfSession.getModel(damUpdateAssetWorkflowModel);
                    WorkflowData wfData = wfSession.newWorkflowData("JCR_PATH", assetPath);
                    wfSession.startWorkflow(wfModel, wfData);
                } catch (WorkflowException e) {
                    log.error("Could not start workflow. " + e.getMessage());
                }
            }

            if (publishAssets) {
                try {
                    log.info("Publishing " + assetPath);
                    replicator.replicate(resolver.adaptTo(Session.class), ReplicationActionType.ACTIVATE, assetPath);
                } catch (ReplicationException e) {
                    log.error("Unable to publish " + assetPath + ". " + e.getMessage());
                }
            }
        }

        log.info("**** Finished processing " + asset.getPath() + "\n");

        if (this.resolver != null && this.resolver.isLive()) {
            log.debug("Closing resolver.");
            this.resolver.close();
        }

        migrationService.addCompletedAsset();
        return results;

    }

    private void applyMetadata(Node assetMetadataNode, HashMap<String, Object> genMetadataMap) throws RepositoryException, PersistenceException {
        synchronized (this) {
            resolver.refresh();
            Helper.updateNodeProperties(assetMetadataNode, genMetadataMap);
            resolver.commit();
        }
    }

    public String cleanForAEM(String name) {
        return name.replaceAll("[^a-zA-Z0-9._/-]","-");
    }

    private Asset importFile(String targetAEMFolder, String assetFileName, File assetVersionFile) {
        if (assetFileName.startsWith(".")) {
            return null;
        }

        log.info("Uploading {}", assetVersionFile.getAbsolutePath());

        AssetManager assetManager = resolver.adaptTo(AssetManager.class);
        String assetPath = targetAEMFolder + "/" + assetFileName;
        log.info("importFile Target path: " + assetPath);

        Node parentNode = resolver.getResource(targetAEMFolder).adaptTo(Node.class);

        try {

            //version the existing asset, if existing
            if (parentNode != null && parentNode.hasNode(assetFileName)) {
 
            	log.info("importFile Creating version for " + assetFileName);
                Asset existingAsset = assetManager.getAssetForBinary(assetPath.replace("/content/dam","/var/dam"));
                if (existingAsset!=null && isReRun ==true){
                ValueMap valueMap = existingAsset.getOriginal().getProperties();
                
                Calendar orginalAseetLastModifiedDate = valueMap.get("jcr:lastModified", Calendar.class);            
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                Date date = sdf.parse(lastIngestionRunDate);
                log.info("lastIngestionRunDateInMills::::"+ date.getTime());
             
                long orginalAseetLastModifiedTimeMillis = orginalAseetLastModifiedDate.getTimeInMillis();
                long lastIngestionRunTimeMillis = date.getTime();
               
                log.info("orginalAseetLastModifiedTimeMillis::::::" +orginalAseetLastModifiedTimeMillis);
                
                if(orginalAseetLastModifiedTimeMillis > lastIngestionRunTimeMillis ){
                	log.info("Skipping {} as this is imported in last run of same data set",assetPath);
                	return null;
                }
                }
              
               
                
                Collection<Revision> revisions = existingAsset.getRevisions(Calendar.getInstance());
                Calendar latesetRevisionDate = null;
                String latestRevisionLabel = "";
                for (Revision revision : revisions) {
                    if (latesetRevisionDate == null || latesetRevisionDate.getTimeInMillis() < revision.getCreated().getTimeInMillis() ) {
                        latesetRevisionDate = revision.getCreated();
                        latestRevisionLabel = revision.getLabel();
                    }
                }
                if (latestRevisionLabel.equals("")) {
                    latestRevisionLabel = "1.0";
                } else {
                    latestRevisionLabel += ".1";
                }
                existingAsset.createRevision(latestRevisionLabel,"Created during offline asset Migration");
            }

            //upload file
            FileInputStream assetFileStream = new FileInputStream(assetVersionFile);
            FileDataSource fds = new FileDataSource(assetVersionFile);
            String mimeType = fds.getContentType();
            log.info("importFile mime-type: " + mimeType);
            log.info("importFile Uploading to " + assetPath);
            return assetManager.createAsset(assetPath,assetFileStream,mimeType,true);
        } catch (RepositoryException e) {
            log.error("Unable to create file. " + e.getMessage());
        } catch (Exception e) {
            log.error("Unable to create version. " + e.getMessage());
        }
        return null;
    }

}
