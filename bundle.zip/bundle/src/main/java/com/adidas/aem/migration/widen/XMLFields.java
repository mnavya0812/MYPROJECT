package com.adidas.aem.migration.widen;

/**
 * Created by bear on 11/29/15.
 */
public class XMLFields {

    public static final String FILE_NAME = "fileName";
    public static final String FILE_PATH = "filePath";
    public static final String ASSET_DISTRIBUTED = "assetIsDistributed";
    public static final String ASSET_GROUPS = "assetGroups";
    public static final String ASSET_GROUP = "assetGroup";
    public static final String RELEASE_DATE = "releaseDate";
    public static final String EXPIRATION_DATE = "expirationDate";

    public static final String ORDERS = "orders";
    public static final String ORDER = "order";
    public static final String ORDER_NUMBER = "orderNumber";
    public static final String ORDER_DATE = "orderDate";
    public static final String ORDER_SENDER = "orderSender";
    public static final String ORDER_RECIPIENT = "orderRecipient";

    public static final String VERSIONS = "versions";

}
