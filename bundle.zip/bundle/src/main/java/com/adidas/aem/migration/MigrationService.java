package com.adidas.aem.migration;

import com.adidas.aem.migration.process.AssetProcessThread;
import com.adidas.dam.services.SAMMSDataService;
import com.adidas.dam.util.SLDConstants;
import com.day.cq.replication.Replicator;
import com.day.cq.workflow.WorkflowService;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

@Component(metatype = true, immediate = true,label = "Adidas - Widen Migration Service")
@Service(MigrationService.class)
public class MigrationService {

    private int processedFiles;
    private int completedAssets;
    private Integer maxAssets;
    private String aemTargetFolder;

    private ExecutorService pool;

    public static final String DEFAULT_TARGET_PATH = "/content/dam/sld";

    @Reference
    Replicator replicator;

    @Reference
    ResourceResolverFactory resolverFactory;

    @Reference
    WorkflowService workflowService;

    @Reference
    SAMMSDataService sammsDataService;

    private static final Logger log = LoggerFactory.getLogger(MigrationService.class);

    private boolean running;
    private Calendar startTime;

    public void runImport(String sourcePath, String targetPath, boolean sortByWeek, int maxAssets, int poolSize,
                          boolean runDUA, boolean lastVersionOnly, boolean replaceExisting, boolean offlineProcess,
                          String sourceRootPath, boolean publishAssets, boolean runSimpleWorkflow,String lastIngestionRunDate ,boolean isReRun) {
        running = true;
        processedFiles = 0;
        completedAssets = 0;
        this.maxAssets = maxAssets;
        SimpleDateFormat outDateFormat = new SimpleDateFormat("MM/dd/yyy HH:mm:ss");
        startTime = Calendar.getInstance();

        log.info("Started at " + outDateFormat.format(startTime.getTime()));
        log.debug("Default Charset=" + Charset.defaultCharset());

        // cleanup source path
        if (sourcePath.endsWith("/")) {
            sourcePath = sourcePath.substring(0, sourcePath.lastIndexOf("/"));
        }
        // validate path
        File sourceDir = new File(sourcePath);
        if (!sourceDir.exists() || !sourceDir.isDirectory()) {
            log.error("Not a valid directory: " + sourceDir.getAbsolutePath());
            running = false;
            return;
        }
        log.debug("source: " + sourceDir.getAbsolutePath());

        aemTargetFolder = targetPath;
        log.debug("target: " + aemTargetFolder);
        if ("".equals(aemTargetFolder) || !aemTargetFolder.startsWith(SLDConstants.DAM_ROOT_PATH)) {
            log.error("Invalid DAM target path. Target path should start with /content/dam");
            running = false;
            return;
        }

        log.info("source: " + sourcePath);
        log.info("sourceRootPath: " + sourceRootPath);
        log.info("aemTarget: " + aemTargetFolder);
        log.info("sortByWeek: " + sortByWeek);
        log.info("maxAssets: " + maxAssets);
        log.info("poolSize: " + poolSize);
        log.info("invokeDamWorkflow: " + runDUA);
        log.info("runSimpleWorkflow: " + runSimpleWorkflow);
        log.info("lastVersionOnly: " + lastVersionOnly);
        log.info("replaceExisting: " + replaceExisting);
        log.info("offlineProcess: " + offlineProcess);
        log.info("publishAssets: " + publishAssets);
        log.info("lastIngestionRunDate: " + lastIngestionRunDate);
        log.info("isReRun: " + isReRun);

        // Create a pool thread
        pool = Executors.newFixedThreadPool(poolSize);

        processFile(sourceDir,sortByWeek,runDUA,lastVersionOnly,replaceExisting, offlineProcess, sourceRootPath, publishAssets, runSimpleWorkflow,lastIngestionRunDate ,isReRun);

        log.debug("Shutting down pool");
        pool.shutdown();

        try {
            pool.awaitTermination(1L, TimeUnit.DAYS);
        } catch (InterruptedException e) {
            log.warn("Application killed before pool finished. " + e.getMessage());
        }

        log.info("Processed " + completedAssets + " of " + processedFiles + " assets");

        Calendar endTime = Calendar.getInstance();
        Long totalTime = endTime.getTime().getTime() - startTime.getTime().getTime();

        log.info("Finished at " + outDateFormat.format(endTime.getTime()));
        log.info("Completed in " + totalTime/1000.0 + " seconds");
        running = false;
        startTime = null;
    }

    public void processFile(File asset, boolean sortByDate, boolean runDUA, boolean lastVersionOnly, boolean replaceExisting, boolean offlineProcess, String sourceRootPath, boolean publishAssets, boolean runSimpleWorkflow ,String lastIngestionRunDate ,boolean isReRun) {
        if (maxAssets > 0 && processedFiles > maxAssets) {
            return;
        }
        String filePath = asset.getPath();
        String fileName = asset.getName();

        // Skip hidden UNIX type files that start with '.'
        if (fileName.startsWith(".")) {
            return;
        }

        // process only XML files, unless it is an offline process
        if ( !asset.isDirectory() && (offlineProcess || fileName.endsWith(".xml")) ) {
            log.info("**** Processing asset: " + filePath);

            AssetProcessThread assetProcessThread;
            // Start Asset Processing in a new thread
            if (offlineProcess) {
                log.debug("Starting Offline Thread");
                assetProcessThread = new OfflineAssetProcessThread(resolverFactory, filePath, aemTargetFolder, sortByDate, workflowService, replicator, sammsDataService, runDUA, lastVersionOnly, replaceExisting, this, sourceRootPath, publishAssets, runSimpleWorkflow,lastIngestionRunDate ,isReRun);
            } else {
                log.debug("Starting Widen Thread");
                assetProcessThread = new WidenAssetProcessThread(resolverFactory, filePath, aemTargetFolder, sortByDate, workflowService, replicator, runDUA, lastVersionOnly, replaceExisting, this,publishAssets, runSimpleWorkflow);
            }

            log.debug("Submitting thread");
            pool.submit(assetProcessThread);

            processedFiles++;
        } else {

            File[] files = asset.listFiles();
            if (files != null) {
                Arrays.sort(files);
                for (File childFile : files) {
                    processFile(childFile,sortByDate, runDUA, lastVersionOnly, replaceExisting, offlineProcess, sourceRootPath, publishAssets, runSimpleWorkflow,lastIngestionRunDate ,isReRun);
                }
            }

        }

    }

    public List<Runnable> stopImport() {
        if (isRunning()) {
            // starts shutdown, but submitted threads will continue to process
            return pool.shutdownNow();
        }
        return null;
    }

    public boolean isRunning() {

        //if true, check if the pool is shutdown
        if (running && pool.isTerminated()) {
            running = false;
        }
        return running;

    }
    public void addCompletedAsset(){
        completedAssets++;
    }

    public int getCompletedAssets() {
        return completedAssets;
    }

    public int getProcessedFiles() {
        return processedFiles;
    }

    public Calendar getStartTime() {
        return startTime;
    }
}
