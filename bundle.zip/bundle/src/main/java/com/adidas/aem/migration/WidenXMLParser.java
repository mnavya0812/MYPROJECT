package com.adidas.aem.migration;

import com.adidas.aem.migration.widen.Order;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

/**
 * Created by bear on 10/8/15.
 */
public class WidenXMLParser extends DefaultHandler {

    private String currentTag;

    private String fileName;
    private String filePath;

    private ArrayList<String> assetGroups;

    private Calendar releaseDate = null;
    private Calendar expirationDate = null;
    private final SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss z");

    private HashMap<Integer, HashMap<String,Object>> versions;
    private HashMap<String,Object> currentVersionMetadata;

    private String metadataKey;
    private String metadataValue;

    private ArrayList<HashMap<String, Object>> comments;
    private HashMap<String,Object> currentComment;
    private boolean active = false;

    private Calendar lastModifiedDate = null;

    private ArrayList<Order> orders;
    private Order currentOrder;

    private static final Logger log = LoggerFactory.getLogger(WidenXMLParser.class);
    private StringBuilder currentString;


    @Override
    public void startDocument() throws SAXException {
        fileName = "";
        filePath = "";
        assetGroups = new ArrayList<String>();
        releaseDate = null;
        expirationDate = null;
    }


    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        currentTag = qName;
        currentString = new StringBuilder("");
//        System.out.println("START: " + currentTag);

        if (currentTag.equals("versions")) {
            versions = new HashMap<Integer, HashMap<String, Object>>();
        } else if (currentTag.equals("version")) {
            currentVersionMetadata = new HashMap<String, Object>();
        } else if (currentTag.equals("comments")) {
            comments = new ArrayList<HashMap<String, Object>>();
        } else if (currentTag.equals("comment")) {
            currentComment = new HashMap<String, Object>();
        } else if (currentTag.equals("orders")) {
            orders = new ArrayList<Order>();
        } else if (currentTag.equals("order")) {
            currentOrder = new Order();
        }
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {

        String currentChars = new String(ch,start,length);
        if (currentString != null) {
            currentString.append(currentChars);
            if (!"".equals(currentTag) && !"".equals(currentString.toString())){
                log.debug("[XML Value] " + currentTag + ": " + currentString.toString());
            }
        }


    }

    @Override
    public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
        if (currentString != null && !currentString.toString().equals("")) {
            currentString.append(new String(ch, start, length));
        }
    }

    private Calendar parseDate(String dateString) {
        if (!"".equals(dateString)) {
            try {
                Calendar date = Calendar.getInstance();
                date.setTime(sdf.parse(dateString.trim()));
                return date;
            } catch (ParseException e) {
                log.error("Cannot parse date - " + dateString);
            }
        }
        return null;
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (qName.equals("version")) {
            versions.put((Integer) currentVersionMetadata.get("versionNumber"), currentVersionMetadata);

        } else if (qName.equals("field")) {
            currentVersionMetadata.put(metadataKey, metadataValue);

        } else if (qName.equals("comment")) {
            comments.add(currentComment);
            currentComment = null;

        } else if (qName.equals("comments")) {
            currentVersionMetadata.put("comments", comments);

        } else if (qName.equals("order")) {
            orders.add(currentOrder);
            currentOrder = null;


            // elements with values
        } else if (qName.equals("filename")) {
            fileName = currentString.toString();

        } else if (qName.equals("filepath")) {
            filePath = currentString.toString();

        } else if (qName.equals("releaseDate")) {
            releaseDate = parseDate(currentString.toString());

        } else if (qName.equals("expirationDate")) {
            expirationDate = parseDate(currentString.toString());

        } else if (qName.equals("assetGroup")) {
            assetGroups.add(currentString.toString());

        } else if (qName.equals("assetIsDistributed")) {
            active = currentString.toString().trim().equals("true");

            //versions
        } else if (qName.equals("versionNumber")) {
            currentVersionMetadata.put(currentTag, Integer.parseInt(currentString.toString()));

        } else if (qName.equals("versionIsFinalized")) {
            currentVersionMetadata.put("finalized", Boolean.parseBoolean(currentString.toString()));

        } else if (qName.equals("versionUploaderName")) {
            currentVersionMetadata.put("uploaderName", currentString.toString());

        } else if (qName.equals("versionUploadEmail")) {
            currentVersionMetadata.put("dam:artDocumentEditor", currentString.toString());
            currentVersionMetadata.put("uploadEmail", currentString.toString());

        } else if (qName.equals("versionDateAdded")) {
            Calendar versionDate = parseDate(currentString.toString());
            currentVersionMetadata.put("jcr:lastModified", versionDate);
            currentVersionMetadata.put("dateAdded", versionDate);
            //update lastModified Date with the most recent version date
            if (lastModifiedDate == null ||
                    (versionDate != null && versionDate.getTimeInMillis() > lastModifiedDate.getTimeInMillis())) {
                lastModifiedDate = versionDate;
            }

        } else if (qName.equals("versionIsWorking")) {
            currentVersionMetadata.put("isWorking", "true".equals(currentString.toString()));

            //metadata fields (per version)
        } else if (qName.equals("key")) {
            metadataKey = currentString.toString();

        } else if (qName.equals("value")) {
            metadataValue = currentString.toString();

            //comments
        } else if (qName.equals("commentMessage")) {
            if (currentComment != null) currentComment.put(currentTag, currentString.toString());

        } else if (qName.equals("commentName")) {
            if (currentComment != null) currentComment.put(currentTag, currentString.toString());

        } else if (qName.equals("commentEmail")) {
            if (currentComment != null) currentComment.put(currentTag, currentString.toString());

        } else if (qName.equals("commentDate")) {
            if (currentComment != null) currentComment.put(currentTag, parseDate(currentString.toString()));

        } else if (qName.equals("orderNumber")) {
            currentOrder.setNumber(currentString.toString());

        } else if (qName.equals("orderDate")) {
            currentOrder.setDate(parseDate(currentString.toString()));

        } else if (qName.equals("orderSender")) {
            currentOrder.setSender(currentString.toString());

        } else if (qName.equals("orderRecipient")) {
            currentOrder.setRecipient(currentString.toString());

        } else {
            if (currentString != null && !"".equals(currentString.toString())) {
                log.warn("Unhandled value - " + currentTag);
            }

        }
        currentTag = "";
        currentString = null;
    }

    @Override
    public void endDocument() throws SAXException {
        currentOrder = null;
        currentString = null;
        currentComment = null;
        currentTag = null;
        currentVersionMetadata = null;
        super.endDocument();
    }

    public String getFileName() {
        return fileName;
    }

    public String getFilePath() {
        return filePath;
    }

    public ArrayList<String> getAssetGroups() {
        return assetGroups;
    }

    public Calendar getReleaseDate() {
        return releaseDate;
    }

    public Calendar getExpirationDate() {
        return expirationDate;
    }

    public HashMap<Integer, HashMap<String, Object>> getVersions() {
        return versions;
    }

    public boolean isActive() {
        return active;
    }

    public Calendar getLastModifiedDate() {
        return lastModifiedDate;
    }
    public void setActive(boolean active) {
        this.active = active;
    }

    public ArrayList<Order> getOrders() {
        return orders;
    }

    public ArrayList<HashMap<String,Object>> getComments() {
        return comments;
    }
}
