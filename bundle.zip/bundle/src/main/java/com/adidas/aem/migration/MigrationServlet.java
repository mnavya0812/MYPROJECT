package com.adidas.aem.migration;

import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.request.RequestParameter;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.servlet.ServletException;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

@SlingServlet(paths="/bin/migration", methods = "GET", metatype=true)
public class MigrationServlet extends SlingSafeMethodsServlet {

    @Reference
    MigrationService migrationService;
    private static final Logger log = LoggerFactory.getLogger(MigrationServlet.class);

    @Override
    protected void doGet(@Nonnull SlingHttpServletRequest request, @Nonnull SlingHttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html><head><title>Widen Asset Migration Tool</title><head><body>");
        out.println("<h1 style='max-width:720px;margin:auto;'>Widen Asset Migration Tool</h1>");
        out.println("<div style='max-width:720px;margin:auto;font-size:small;'><p>");
        out.println("This tool will import assets from the legacy Widen Asset system. Below is a description of the options available.\n" +
                "<ul>\n" +
                "<li><strong>Source Path:</strong> This is the path to the folder that should be processed for migration. This should be a local path on the AEM server. The folder will be processed recursivley, meaning all assets in all folders within the selected folder will be uploaded.</li>\n" +
                "<li><strong>Source Root Path:</strong> This is the root of the asset path that will be replaced by the Target AEM Path. If the Source Path is X:\\assets\\apparel\\adidas, the Target AEM Path is /content/dam/sld and the Source Root Path is X:\\assets, the assets will be uploaded to /content/dam/sld/apparel/adidas. If no Source Root Path is used, then the target folder will be just the Target AEM Path. If thi sis a Widen Import, the file path from the XML will be used.</li>\n" +
                "<li><strong>Target AEM Path:</strong> This is the path within AEM to store/upload the assets. If 'Sort By Week' is selected below, then this path will be appended with the year/week format folder. Otherwise, the path entered here will be appended by the 'filepath' specified in the XML/Metadata of the asset. These are the paths defined and used:\n" +
                "<ul>\n" +
                "<li>/content/dam/sld - used for VIVO assets (not sort by week)</li>\n" +
                "<li>/content/dam/sld/digital-imagery/annual - used for DI/Root assets (sort by week)</li>\n" +
                "</ul>\n" +
                "</li>\n" +
                "<li><strong>Offline Assets?</strong> If not importing Widen assets, select this option.</li>\n" +
                "<li><strong>Publish Assets?</strong> Check to publish assets after they have been imported and metadata applied.</li>\n" +
                "<li><strong>Sort By Week:</strong> instead of the folder path that the file is in, the file will be saved based on the last modified date in a year/week folder structure. This should only be set for DI/root-folder assets.</li>\n" +
                "<li><strong>Max Assets:</strong> Sets the maximum number of assets to upload. Used mainly for doing a test/sample run. Set to 0 for no limit on uploads.</li>\n" +
                "<li><strong>Run DAM Update Asset Workflow:</strong> Checking this will run the DAM Update Asset workflow when the asset has been uploaded and processed. This option should be disabled in order to reduce the load on the server. Once all assets are processed, the Bulk Workflow Manager can be used to run the DAM Update workflow for all assets and create renditions. Afterwards, use the tree replication tool to republish any assets that were previously published without renditions.</li>\n" +
                "<li><strong>Process only final version:</strong> This will prohibit older versions of files from being uploaded and will only upload and process the last version of an asset.</li>\n" +
                "<li><strong>Update existing files/versions?</strong> This will reupload files that already exist in AEM. By default this is turned off so that any files that did not upload can be reuploaded easily by reprocessing the same folder without loading extraneous versions.</li>\n" +
                "<li><strong>Timestamp for last run of same data set :</strong>Timestamp(Format : yyyy-MM-dd HH:mm:ss) of start of first run on same dataset.This timestamp is used to skip reimport of assets if it is a re-run on same data set in case of update existing file/version is true.</li>\n" +
                "<li><strong>Is it a re-run of same data set ? </strong>Check this checkbox in case you are running ingestion on samedata set which is stopped in between and update existing file/version is need to be true.</li>\n" +
                "<ul>\n");
        out.println("</p></div>");

        RequestParameter cmdParam = request.getRequestParameter("cmd");
        out.println("<div style='max-width:640px;margin:auto;'>");
        if (migrationService.isRunning()) {
            out.println("<div style='background-color: #FFEBEB;padding: 5px;margin-bottom: 5px;border: 2px solid #C56666;border-radius: 10px;'>");
            if (cmdParam != null && cmdParam.getString().equals("stopMigration")) {
                List<Runnable> processes = migrationService.stopImport();
                out.println("Shutdown signal sent. This may take some time to finish assets that have been started.");
                out.println("<form><input type='hidden' name='cmd' value='status'/><button type='submit'>Update status</button></form>");
            } else {
                int completedAssets = migrationService.getCompletedAssets();
                int processedFiles = migrationService.getProcessedFiles();
                SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyy HH:mm:ss zzz");
                Calendar startTime = migrationService.getStartTime();
                out.println("Migration is currently running.<br/>");
                out.println("Started: " + sdf.format(startTime.getTime()) + "<br/>");
                out.println(completedAssets + " of " + processedFiles + " assets completed.");
                out.println("<form><input type='hidden' name='cmd' value='status'/><button type='submit'>Update status</button></form>");
                out.println("<form><input type='hidden' name='cmd' value='stopMigration'/><button type='submit'>Stop Migration</button></form>");
            }
            out.println("</div>");
        }
        if (cmdParam != null && cmdParam.getString().equals("runImport")) {
            RequestParameter sourcePathParam = request.getRequestParameter("sourcePath");
            RequestParameter sourceRootPathParam = request.getRequestParameter("sourceRootPath");
            RequestParameter targetPathParam = request.getRequestParameter("targetPath");
            RequestParameter sortByWeekParam = request.getRequestParameter("sortByWeek");
            RequestParameter maxAssetsParam = request.getRequestParameter("maxAssets");
            RequestParameter concurrentThreadsParam = request.getRequestParameter("concurrentThreads");
            RequestParameter runDUAParam = request.getRequestParameter("runDUA");
            RequestParameter runSimpleWorkflowParam = request.getRequestParameter("runSimpleWorkflow");
            RequestParameter lastIngestionRunDateParam = request.getRequestParameter("lastIngestionRunDate");
            RequestParameter isReRunParam = request.getRequestParameter("isReRun");
            RequestParameter lastVersionOnlyParam = request.getRequestParameter("lastVersionOnly");
            RequestParameter replaceExistingParam = request.getRequestParameter("replaceExisting");
            RequestParameter publishAssetsParam = request.getRequestParameter("publishAssets");
            RequestParameter offlineProcessParam = request.getRequestParameter("offlineProcess");

            final String sourcePath = sourcePathParam.getString();
            final String sourceRootPath = sourceRootPathParam != null ? sourceRootPathParam.getString() : sourcePath;
            final String targetPath = targetPathParam.getString();
            final boolean sortByWeek = sortByWeekParam != null && sortByWeekParam.getString().equals("true");
            final int maxAssets = maxAssetsParam != null ? Integer.parseInt(maxAssetsParam.getString()) : 0;
            final int concurrentThreads = concurrentThreadsParam != null ? Integer.parseInt(concurrentThreadsParam.getString()) : 30;
            final boolean runDUA = runDUAParam != null && runDUAParam.getString().equals("true");
            final boolean isReRun = isReRunParam != null && isReRunParam.getString().equals("true");
            final String lastIngestionRunDate = lastIngestionRunDateParam != null ? lastIngestionRunDateParam.getString() : "";
            final boolean runSimpleWorkflow = runSimpleWorkflowParam != null && runSimpleWorkflowParam.getString().equals("true");
            final boolean lastVersionOnly = lastVersionOnlyParam != null && lastVersionOnlyParam.getString().equals("true");
            final boolean replaceExisting = replaceExistingParam != null && replaceExistingParam.getString().equals("true");
            final boolean offlineProcess = offlineProcessParam != null && offlineProcessParam.getString().equals("true");
            final boolean publishAssets = publishAssetsParam != null && publishAssetsParam.getString().equals("true");

            log.debug("runDUA: " + runDUA);
            log.debug("lastVersion: " + lastVersionOnly);
            log.debug("replaceExisting: " + replaceExisting);

            if (migrationService.isRunning()) {
                out.println("<p>Cannot start another migration until the current one finishes.</p>");
            } else {

                //start migration in new thread
                new Thread(new Runnable() {
                    final Logger log = LoggerFactory.getLogger(MigrationServlet.class);
                    @Override
                    public void run() {
                        log.info("Starting import.");
                        migrationService.runImport(sourcePath,targetPath,sortByWeek,maxAssets,concurrentThreads,runDUA,lastVersionOnly,replaceExisting, offlineProcess, sourceRootPath, publishAssets, runSimpleWorkflow,lastIngestionRunDate ,isReRun);
                    }
                }).start();
                out.println("<p>Migration started.</p>");
                out.println("<form><input type='hidden' name='cmd' value='status'/><button type='submit'>Update status</button></form>");
            }
        }


        out.println("<form style='max-width:640px;margin:auto;padding: 10px;background-color: #efefef;'>");
        out.println("<legend style='font-size:large'><strong>Migration Options</strong></legend>");
        out.println("<input type='hidden' name='cmd' value='runImport'/>");
        out.println("<div><label>Source Path: <input style='width:100%' type='text' name='sourcePath' required/></label></div>");
        out.println("<div><label>Source Root Path: <input style='width:100%' type='text' name='sourceRootPath'/></label></div>");
        out.println("<div><label>Target AEM Path: <input style='width:100%' type='text' name='targetPath' value='/content/dam' required/></label></div>");
        out.println("<div><label>Offline Assets (Not Widen)? <input type='checkbox' name='offlineProcess' value='true'/></label></div>");
        out.println("<div><label>Publish Assets? <input type='checkbox' name='publishAssets' value='true' checked/></label></div>");
        out.println("<div><label>Sort By Week? (DI/root Folder): <input type='checkbox' name='sortByWeek' value='true'/></label></div>");
        out.println("<div><label>Max Assets (0 = no limit): <input type='number' name='maxAssets' value='0'/></label></div>");
        out.println("<div><label>Run DAM Update Asset Workflow: <input type='checkbox' name='runDUA' value='true'/></label></div>");
        out.println("<div><label>Run Simple Update Asset Workflow: <input type='checkbox' name='runSimpleWorkflow' value='true'/></label></div>");
        out.println("<div><label>Process only final version: <input type='checkbox' name='lastVersionOnly' value='true'/></label></div>");
        out.println("<div><label>Update existing files/versions? <input type='checkbox' name='replaceExisting' value='true'/></label></div>");
        out.println("<div><label>Timestamp for last run of same data set : <input style='width:100%' type='text' name='lastIngestionRunDate'/></label></div>");
        out.println("<div><label>Is it a re-run of same data set ? <input type='checkbox' name='isReRun' value='true'/></label></div>");
        out.println("<div><label>Concurrent Threads: <input type='number' name='concurrentThreads' value='50'/></label></div>");
        out.println("<div><button style='font-size: small;padding: 5px;font-weight: bold;' type='submit'>Start Migration</button></div>");
        out.println("</form>");
        out.println("</div>");
        out.println("</body></html>");


    }
}
