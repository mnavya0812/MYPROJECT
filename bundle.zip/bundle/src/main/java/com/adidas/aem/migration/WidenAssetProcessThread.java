package com.adidas.aem.migration;

import com.adidas.aem.migration.process.AssetProcessThread;
import com.adidas.aem.migration.widen.Order;
import com.adidas.dam.util.SLDConstants;
import com.adidas.dam.util.TagUtil;
import com.day.cq.commons.jcr.JcrUtil;
import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.AssetManager;
import com.day.cq.replication.ReplicationActionType;
import com.day.cq.replication.ReplicationException;
import com.day.cq.replication.Replicator;
import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowService;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.Workflow;
import com.day.cq.workflow.exec.WorkflowData;
import com.day.cq.workflow.model.WorkflowModel;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.*;
import javax.activation.FileDataSource;
import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.UnsupportedRepositoryOperationException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.apache.commons.lang3.SystemUtils;
import org.apache.sling.api.resource.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.SAXException;

/**
 * Thread to process an asset
 */
public class WidenAssetProcessThread implements AssetProcessThread {

    private final String aemTargetFolder;
    private final String assetPath;
    private final MigrationService migrationService;
    private ResourceResolver resolver;
    private final WorkflowService workflowService;
    private final Replicator replicator;
    private final ResourceResolverFactory resolverFactory;
    private boolean sortByDate;
    private final boolean runSimpleWorkflow ;
    private final boolean publishAssets ;
    private ProcessedResults results;
    private static final Logger log = LoggerFactory.getLogger(WidenAssetProcessThread.class);

    private boolean invokeDamWorkflow = false;
    private boolean lastVersionOnly = false;
    private boolean replaceExisting = false;

    public static final String B_SLASH = "\\";
    public static final String F_SLASH = "/";

    public static final String SLASH = SystemUtils.IS_OS_WINDOWS ? B_SLASH : F_SLASH;

    private static final Object assetCreationLock = new Object();

    WidenAssetProcessThread(ResourceResolverFactory resolverFactory, String assetPath, String aemTargetFolder,
            boolean sortByDate, WorkflowService workflowService, Replicator replicator, boolean runDUA,
            boolean lastVersionOnly, boolean replaceExisting, MigrationService migrationService ,boolean publishAssets, boolean runSimpleWorkflow) {
        this.resolverFactory = resolverFactory;
        this.aemTargetFolder = aemTargetFolder;
        this.sortByDate = sortByDate;
        this.assetPath = assetPath;
        this.workflowService = workflowService;
        this.replicator = replicator;
        this.invokeDamWorkflow = runDUA;
        this.lastVersionOnly = lastVersionOnly;
        this.replaceExisting = replaceExisting;
        this.publishAssets = publishAssets;
        this.runSimpleWorkflow = runSimpleWorkflow;
        this.migrationService = migrationService;
    }

    @Override
    public ProcessedResults call() {

        File asset = new File(assetPath);

        Thread thisThread = Thread.currentThread();
        thisThread.setName(asset.getName());

        results = new ProcessedResults();

        String updateAssetWorkflowModel = "/etc/workflow/models/simplified-migration-update-asset/jcr:content/model";
        String damUpdateAssetWorkflowModel = "/etc/workflow/models/dam/update_asset/jcr:content/model";

        //read metadata
        WidenXMLParser xmlParser = readFileMetadata(asset);
        log.info("XML parsing complete.");

        //Check if this should be active
        xmlParser.setActive(isActiveMigration(xmlParser));

        String parentFolderPath = asset.getParentFile().getPath();

        HashMap<Integer, HashMap<String, Object>> versions = xmlParser.getVersions();

        // Setting filename from XML, but this is overridden when parsing the version with the actual file name
        String assetFileName;

        String targetAEMFolder = aemTargetFolder + "/" + xmlParser.getFilePath();
        if (sortByDate) {
            Calendar lastModifiedDate = xmlParser.getLastModifiedDate();
            log.debug("Last Modified: " + lastModifiedDate);
            targetAEMFolder = aemTargetFolder + Constants.weekBasedFolderFormat.format(lastModifiedDate.getTime());
        }

        if (targetAEMFolder.endsWith("/")) {
            targetAEMFolder = targetAEMFolder.substring(0, targetAEMFolder.lastIndexOf("/"));
        }

        String finalizedVersion = null;
        String assetPath = null;
        boolean genMetadataApplied = false;
        try {
            this.resolver = resolverFactory.getAdministrativeResourceResolver(null);
            Session session = resolver.adaptTo(Session.class);
            session.getWorkspace().getObservationManager().setUserData("changedByWorkflowProcess");
        } catch (LoginException e) {
            log.error("Cannot get resolver. " + e.getMessage());
            return results;
        } catch (UnsupportedRepositoryOperationException e) {
        	log.error("Unsupported Repository Operation:::" + e.getMessage());
		} catch (RepositoryException e) {
			log.error("Repository Exception :::" + e.getMessage());
		}
        boolean publishAsset = false ;
        // process versions
       
        boolean newAssetUploaded = false;
        for (int i = 1; i <= versions.size(); i++) {
            HashMap<String, Object> version = null;
            if (lastVersionOnly) {
                int versionNumber = versions.size();
                version = versions.get(versionNumber);
                while (version == null && versionNumber > 0) {
                    versionNumber--;
                    version = versions.get(versionNumber);
                }
                i = versionNumber;
            } else {
                version = versions.get(i);
            }
            if (version == null) {
                log.error("Unable to get version " + i);
                continue;
            }

            assetPath = null;
            log.info("----- Version " + i + " processing -----");

            //if version is not NFL and is not older than lastVersionDate, import. Other wise, skip
            if ((versions.size() != 1) && version.containsKey("league") && (!Objects.equals(version.get("league"), "NFL"))) {
                Calendar lastModifiedDate = (Calendar) version.get("jcr:lastModified");
                if (lastModifiedDate != null && lastModifiedDate.before(Constants.lastVersionDate)) {
                    log.info("Version is too old. Will not be imported. " + Constants.versionDateFormat.format(lastModifiedDate.getTime()));
                    if (lastVersionOnly) {
                        break;
                    } else {
                        continue;
                    }
                }
            }

            int versionNumber = (Integer) version.get("versionNumber");
            String versionFolderPath = parentFolderPath + SLASH + "v" + versionNumber;

            // get file in version folder (first file. should only be one)
            File versionFolder = new File(versionFolderPath);
            File[] versionFiles = versionFolder.listFiles();
            if (versionFiles != null && versionFiles.length > 0) {
                Arrays.sort(versionFiles);
                File assetVersionFile = versionFiles[0];
                assetFileName = assetVersionFile.getName();
                log.info("Asset version file: " + assetVersionFile.getPath());
                if (assetFileName.startsWith("$")) {
                    assetFileName = assetFileName.replaceFirst("$", ""); // remove starting $ from some files
                }

                //upload version into AEM
                targetAEMFolder = cleanForAEM(targetAEMFolder.replace(B_SLASH, F_SLASH));
                assetFileName = cleanForAEM(assetFileName);
                log.info("Uploading to " + targetAEMFolder);
                log.debug("Version file name: " + assetFileName);
                Asset versionAsset = null;

                //if replaceExisting == false, then check if the file exists and exit if it exists.
                if (!replaceExisting && !newAssetUploaded) {
                    Resource existingAsset = resolver.getResource(targetAEMFolder + "/" + assetFileName);
                    if (existingAsset != null) {
                        log.warn("Asset " + targetAEMFolder + "/" + assetFileName + " exists. Will not reprocess.");
                        if (resolver.isLive()) {
                            resolver.close();
                        }
                        migrationService.addCompletedAsset();
                        return results;
                    }
                }

                //create folder
                try {
                    synchronized (assetCreationLock) {
                        resolver.refresh();
                        //create parent folders
                        log.debug("Ensuring " + targetAEMFolder);
                        JcrUtil.createPath(targetAEMFolder, "sling:OrderedFolder", "sling:OrderedFolder", resolver.adaptTo(Session.class), true);
                        resolver.commit();
                    }
                } catch (javax.jcr.InvalidItemStateException e) {
                    log.warn("Error ensuring path " + e.getMessage());
                } catch (RepositoryException e) {
                    log.error("Could not create folder " + targetAEMFolder + ". " + e.getMessage());
                } catch (PersistenceException e) {
                    log.error("Could not save folder changes. " + e.getMessage());
                }

                synchronized (assetCreationLock) {
                    resolver.refresh();
                    versionAsset = importFile(targetAEMFolder, assetFileName, versionNumber, assetVersionFile);
                }

                newAssetUploaded = true;
                assetPath = versionAsset != null ? versionAsset.getPath() : null;
                log.debug("assetPath: " + assetPath);

                // get the metadata map
                log.info("Getting metadata for AEM");
                HashMap<String, Object> metadataMap = parseMetadataMap(version);

                log.info("Uploaded to " + assetPath);
                Node assetNode = null;
                if (versionAsset != null) {
                    assetNode = versionAsset.adaptTo(Node.class);
                    Node assetContentNode = null;
                    String assetContentNodePath = null;
                    Node assetMetadataNode = null;
                    try {
                        assetContentNode = assetNode.getNode("jcr:content");
                        assetContentNodePath = assetContentNode.getPath();
                        assetMetadataNode = assetContentNode.getNode("metadata");
                    } catch (RepositoryException e) {
                        log.error("Unable to access repository information. " + e.getMessage());
                    }

                    try {
                        setContentMetadata(assetContentNode, assetFileName, (Calendar) metadataMap.get(SLDConstants.ASSET_LASTMOD_DATE), xmlParser.getReleaseDate(), xmlParser.getExpirationDate());
                    } catch (RepositoryException e) {
                        log.error("Unable to set content metadata. " + e.getMessage());
                    } catch (PersistenceException e) {
                        log.error("Cannot save content metadata. " + e.getMessage());
                    }

                    // apply general metadata for the first version of the asset uploaded
                    if (!genMetadataApplied) {
                        HashMap<String, Object> generalMetadataMap = buildGeneralMetadataMap(xmlParser);

                        try {
                            log.debug("Saving asset general metadata.");
                            applyGeneralMetadata(assetMetadataNode, generalMetadataMap);
                        } catch (PersistenceException e) {
                            log.error("Unable to save metadata changes for " + assetPath + "/jcr:content/metadata. " + e.getMessage());
                        } catch (RepositoryException e) {
                            log.error("Unable to set metadata. " + e.getMessage());
                        }

                        log.debug("Saving order information.");
                        saveOrderMetadata(assetContentNodePath, xmlParser);

                        log.debug("Saving comment information");
                        saveCommentsMetadata(assetContentNodePath, xmlParser);

                        genMetadataApplied = true;
                    }

                    synchronized (this) {
                        resolver.refresh();
                        log.debug("Updating version specific metadata.");
                        try {
                            updatePropertiesInAEM(assetMetadataNode, metadataMap);
                            resolver.commit();
                        } catch (PersistenceException e) {
                            log.error("Unable to update metadata for " + assetPath + ". " + e.getMessage());
                        } catch (RepositoryException e) {
                            log.error("Unable to set metadata. " + e.getMessage());
                        }
                    }
                    resolver.refresh();

                    //start update asset workflow and wait for it to complete
                    if(runSimpleWorkflow){
                    try {
                        WorkflowSession wfSession = workflowService.getWorkflowSession(resolver.adaptTo(Session.class));
                        WorkflowModel wfModel = wfSession.getModel(updateAssetWorkflowModel);
                        WorkflowData wfData = wfSession.newWorkflowData("JCR_PATH", assetPath);
                        Workflow workflow = wfSession.startWorkflow(wfModel, wfData);
                        log.debug("Workflow: " + workflow);
                        log.info("Simple Workflow started");
                        try {
                            while (workflow.isActive()) {
                                try {
                                    Thread.sleep(1000);
                                } catch (InterruptedException e) {
                                    log.warn("Cannot sleep thread. " + e.getMessage());
                                }
                            }
                        } catch (Exception e) {
                            log.warn("Check for workflow failed. " + e.getMessage());
                            try {
                                Thread.sleep(10000);
                            } catch (InterruptedException e1) {
                                log.warn("Cannot sleep thread. " + e1.getMessage());
                            }
                        }
                        log.info("Simple Workflow completed");
                    } catch (WorkflowException e) {
                        log.error("Unable to start simple workflow for " + assetPath + ". " + e.getMessage());
                    }
                    
                }
                } else {
                    log.error("File upload failed for " + xmlParser.getFilePath() + ".");
                }

                // publish/activate if needed
                boolean isFinalized = ((Boolean) version.get("finalized"));
                if (isFinalized && xmlParser.isActive()) {
                    finalizedVersion = String.valueOf(versionNumber);
                    publishAsset = true;
                }
                log.info("----- Version " + i + " processed\n");
            } else {
                log.error("----- Version " + i + " failed\n");
            }

            if (lastVersionOnly) {
                break;
            }

        }

        if (assetPath != null) {
            results.addFinalizedAsset(xmlParser.getFileName(), finalizedVersion);
        }

        //start Standard DAM Update asset on final asset
        if (assetPath != null) {
            if (invokeDamWorkflow) {
                try {
                    WorkflowSession wfSession = workflowService.getWorkflowSession(resolver.adaptTo(Session.class));
                    WorkflowModel wfModel = wfSession.getModel(damUpdateAssetWorkflowModel);
                    WorkflowData wfData = wfSession.newWorkflowData("JCR_PATH", assetPath);
                    wfSession.startWorkflow(wfModel, wfData);
                } catch (WorkflowException e) {
                    log.error("Could not start workflow. " + e.getMessage());
                }
            }

            if (publishAsset && publishAssets) {
                try {
                    log.info("Publishing " + assetPath);
                    replicator.replicate(resolver.adaptTo(Session.class), ReplicationActionType.ACTIVATE, assetPath);
                } catch (ReplicationException e) {
                    log.error("Unable to publish " + assetPath + ". " + e.getMessage());
                }
            }
        }

        log.info("**** Finished processing " + asset.getPath() + "\n");

        if (this.resolver != null && this.resolver.isLive()) {
            log.debug("Closing resolver.");
            this.resolver.close();
        }

        migrationService.addCompletedAsset();
        return results;

    }

    private void saveCommentsMetadata(String path, WidenXMLParser xmlParser) {
        synchronized (this) {
            ArrayList<HashMap<String, Object>> comments = xmlParser.getComments();
            String commentPath = path + "/comments";
            for (HashMap<String, Object> comment : comments) {
                resolver.refresh();
                HashMap<String, Object> metadataMap = new HashMap<String, Object>();

                //get comment metadata
                String commentMessage = (String) comment.get("commentMessage");
                String commentName = (String) comment.get("commentName");
                String commentEmail = (String) comment.get("commentEmail");
                Calendar commentdate = (Calendar) comment.get("commentDate");

                // build content node name (64 char, alpha-num, ' ' => '_')
                String commentNodeName = commentMessage.replace(" ", "_").replaceAll("[^A-Za-z0-9]", "");
                if (commentNodeName.length() > 64) {
                    commentNodeName = commentNodeName.substring(0, 63);
                }
                String commentNodePath = commentPath + "/" + commentNodeName;
                Node commentNode = null;
                try {
                    commentNode = JcrUtil.createPath(commentNodePath, "nt:unstructured", resolver.adaptTo(Session.class));
                    String migratedMessage = "[" + Constants.commentDateFormat.format(commentdate.getTime()) + " (" + commentName + ")] " + commentMessage;
                    Calendar now = Calendar.getInstance();

                    // add to metadata map
                    metadataMap.put("jcr:description", migratedMessage);
                    metadataMap.put("jcr:created", now);
                    metadataMap.put("jcr:createdBy", "admin");
                    metadataMap.put("sling:resourceType", "granite/comments/components/comment");
                    metadataMap.put("vivo.name", commentName);
                    metadataMap.put("vivo.email", commentEmail);
                    metadataMap.put("author", commentEmail);

                    updatePropertiesInAEM(commentNode, metadataMap);
                    resolver.commit();
                } catch (RepositoryException e) {
                    log.error("Cannot update comment metadata. " + e.getMessage());
                } catch (PersistenceException e) {
                    log.error("Cannot save comment metadata. " + e.getMessage());
                }

            }
        }
    }

    private void saveOrderMetadata(String assetContentPath, WidenXMLParser xmlParser) {
        //store orders
        synchronized (this) {
            ArrayList<Order> orders = xmlParser.getOrders();
            for (Order order : orders) {
                resolver.refresh();
                String orderPath = assetContentPath + "/orders/order" + order.getNumber();
                try {
                    HashMap<String, Object> orderMap = new HashMap<String, Object>();
                    Node orderNode = JcrUtil.createPath(orderPath, "nt:unstructured", resolver.adaptTo(Session.class));
                    orderMap.put("number", order.getNumber());
                    orderMap.put("date", order.getDate());
                    orderMap.put("sender", order.getSender());
                    orderMap.put("recipient", order.getRecipient());
                    updatePropertiesInAEM(orderNode, orderMap);
                    resolver.commit();
                } catch (RepositoryException e) {
                    log.error("Unable to create orders. " + e.getMessage());
                } catch (PersistenceException e) {
                    log.error("Unable to save order information for " + orderPath + ". " + e.getMessage());
                }

            }
        }
    }

    private HashMap<String, Object> buildGeneralMetadataMap(WidenXMLParser xmlParser) {
        // Apply other metadata
        log.info("Processing general asset metadata.");
        HashMap<String, Object> genMetadataMap = new HashMap<String, Object>();

        // assetGroups
        ArrayList<String> assetGroupsList = xmlParser.getAssetGroups();

        //Get art document type by asset Group and check confidential
        boolean confidential = false;
        for (String assetGroup : assetGroupsList) {
            if (Constants.artDocumentGroupMap.containsKey(assetGroup)) {
                genMetadataMap.put(SLDConstants.ART_DOCUMENT_TYPE, Constants.artDocumentGroupMap.get(assetGroup));
            }

            // Set confidential for Hold -Pending Styles
            if (assetGroup.toLowerCase().startsWith("hold")) {
                confidential = true;
            }
        }

        // add confidential metadata field
        if (confidential) {
            genMetadataMap.put(SLDConstants.DI_CONFIDENTIAL, "yes");
        } else {
            genMetadataMap.put(SLDConstants.DI_CONFIDENTIAL, "no");
        }

        // get asset groups as tags
        ArrayList<String> assetGroupsTagList = convertAssetGroupsListToTags(assetGroupsList);

        // if everyone tag isn't already added, add it for DI/sortByDate assets
        if (sortByDate && !assetGroupsTagList.contains("adidas:everyone")) {
            assetGroupsTagList.add("adidas:everyone");
        }

        //convert to array
        String[] assetGroups = new String[assetGroupsTagList.size()];
        assetGroups = assetGroupsTagList.toArray(assetGroups);

        //if no vendor/contract asset groups, tag for everyone
        if (assetGroups.length == 0) {
            assetGroups = new String[]{"adidas:everyone"};
        }

        genMetadataMap.put(SLDConstants.ACTIVE, String.valueOf(xmlParser.isActive()));
        genMetadataMap.put(SLDConstants.DAM_TAGS, assetGroups);
        genMetadataMap.put("dc:title", xmlParser.getFileName());
        genMetadataMap.put(SLDConstants.ASSET_DRM, SLDConstants.ASSET_DRM_PATH + ".html");
        genMetadataMap.put(SLDConstants.FILE_NAME, xmlParser.getFileName().toUpperCase());
        genMetadataMap.put("filePath", xmlParser.getFilePath());

        // get brand if applicable
        if (xmlParser.getFilePath().startsWith("apparel/adidas")) {
            genMetadataMap.put(SLDConstants.BRAND, "adidas-picklists:brand/adidas");
        } else if (xmlParser.getFilePath().startsWith("apparel/reebok")) {
            genMetadataMap.put(SLDConstants.BRAND, "adidas-picklists:brand/adidas");
        }

        return genMetadataMap;
    }

    private void applyGeneralMetadata(Node assetMetadataNode, HashMap<String, Object> genMetadataMap) throws RepositoryException, PersistenceException {
        synchronized (this) {
            resolver.refresh();
            updatePropertiesInAEM(assetMetadataNode, genMetadataMap);
            resolver.commit();
        }
    }

    private void setContentMetadata(Node assetContentNode, String assetFileName, Calendar lastModifiedDate, Calendar releaseDate, Calendar expirationDate) throws RepositoryException, PersistenceException {
        synchronized (this) {
            resolver.refresh();
            assetContentNode.setProperty(SLDConstants.ASSET_LASTMOD_DATE, lastModifiedDate);
            assetContentNode.setProperty("cq:name", assetFileName);
            assetContentNode.setProperty("onTime", releaseDate);
            assetContentNode.setProperty("offTime", expirationDate);
            resolver.commit();
        }
    }

    private void updatePropertiesInAEM(Node assetNode, HashMap<String, Object> metadataMap) throws RepositoryException {
        for (Map.Entry<String, Object> entry : metadataMap.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();
            log.debug(key + ": " + value);
            if (value instanceof String[]) {
                assetNode.setProperty(key, (String[]) value);
            } else if (value instanceof Calendar) {
                assetNode.setProperty(key, (Calendar) value);
            } else if (value instanceof Integer) {
                assetNode.setProperty(key, (Integer) value);
            } else if (value instanceof Boolean) {
                assetNode.setProperty(key, (Boolean) value);
            } else {
                assetNode.setProperty(key, (String) value);
            }
        }
    }

    public String cleanForAEM(String name) {
        return name.replaceAll("[^a-zA-Z0-9._/-]", "-");
    }

    private Asset importFile(String targetAEMFolder, String assetFileName, int vivoVersion, File assetVersionFile) {
        if (assetFileName.startsWith(".")) {
            return null;
        }

        log.info("Uploading {}", assetVersionFile.getAbsolutePath());

        AssetManager assetManager = resolver.adaptTo(AssetManager.class);
        String assetPath = targetAEMFolder + "/" + assetFileName;
        log.info("Target path: " + assetPath);

        Node parentNode = resolver.getResource(targetAEMFolder).adaptTo(Node.class);

        try {

            //version the existing asset, if existing
            if (parentNode != null && parentNode.hasNode(assetFileName)) {
                log.info("Creating version for " + assetFileName);
                int previousVersion = vivoVersion - 1;
                Asset existingAsset = assetManager.getAssetForBinary(assetPath.replace("/content/dam", "/var/dam"));
                assetManager.createRevision(existingAsset, String.valueOf(previousVersion), "VIVO Version " + previousVersion);
            }

            //upload file
            FileInputStream assetFileStream = new FileInputStream(assetVersionFile);
            FileDataSource fds = new FileDataSource(assetVersionFile);
            String mimeType = fds.getContentType();
            log.debug("mime-type: " + mimeType);
            log.info("Uploading to " + assetPath);
            return assetManager.createAsset(assetPath, assetFileStream, mimeType, true);
        } catch (RepositoryException e) {
            log.error("Unable to create file. " + e.getMessage());
        } catch (Exception e) {
            log.error("Unable to create version. " + e.getMessage());
        }
        return null;
    }

    private ArrayList<String> convertAssetGroupsListToTags(ArrayList<String> assetGroups) {
        ArrayList<String> assetGroupsTagList = new ArrayList<String>();
        boolean hasVendorContractorGroup = false;
        for (String assetGroup : assetGroups) {
            String tagRootPath = Constants.ADIDAS_TAG_PATH;
            if (assetGroup.toLowerCase().startsWith("contractor")) {
                tagRootPath += "/contractor";
                assetGroup = assetGroup.split("-", -1)[1];
                hasVendorContractorGroup = true;
            } else if (assetGroup.toLowerCase().startsWith("vendor")) {
                tagRootPath += "/vendor";
                assetGroup = assetGroup.split("-", -1)[1];
                hasVendorContractorGroup = true;
            } else {
                tagRootPath += "/asset-group";
            }
            assetGroupsTagList.add(TagUtil.findTagIDByTitle(tagRootPath, assetGroup.trim(), resolver, true));
        }

        if (!hasVendorContractorGroup) {
            assetGroupsTagList.add("adidas:everyone");
        }
        return assetGroupsTagList;
    }

    private boolean isImportable(WidenXMLParser xmlParser) {
        // for DI/Weekly import, check that the asset group is in either the active or inactive list.
        if (sortByDate) {
            for (String assetGroup : xmlParser.getAssetGroups()) {
                if (Constants.activeMigrations.contains(assetGroup.toLowerCase()) || Constants.inactiveMigrations.contains(assetGroup.toLowerCase())) {
                    return true;
                }
            }
            return false;
        }

        return true;
    }

    /**
     * Reads in and parses the asset metadata XML using the WidenXMLParse
     *
     * @param file the XML file to parse
     * @return the parser/handler
     */
    private WidenXMLParser readFileMetadata(File file) {
        log.info("Parsing XML: " + file.getPath());
        WidenXMLParser xmlParser = null;
        if (file.exists()) {
            SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
            try {
                SAXParser saxParser = saxParserFactory.newSAXParser();
                xmlParser = new WidenXMLParser();

                saxParser.parse(file, xmlParser);
            } catch (ParserConfigurationException e) {
                log.error("Unable to parse " + file.getPath() + ". " + e.getMessage());
            } catch (SAXException e) {
                log.error("Unable to parse " + file.getPath() + ". " + e.getMessage());
            } catch (IOException e) {
                log.error("Unable to parse " + file.getPath() + ". " + e.getMessage());
            }

        } else {
            log.error("Cannot find XML metadata file: " + file.getPath());
        }

        return xmlParser;
    }

    /**
     * Converts the Parsed XML into a metadata map that can be passed into the
     * updateMetadataInAEM() method
     *
     * @param versionData map of metadata for a version of an asset
     * @return map of key and values as they are to be entered in to AEM. keys
     * are paths to properties relative to the asset in AEM
     */
    private HashMap<String, Object> parseMetadataMap(HashMap<String, Object> versionData) {
        HashMap<String, Object> metadataMap = new HashMap<String, Object>();
        String metadataNodePath = "";   //Blank, left over from external migration script

        for (Map.Entry<String, Object> metadata : versionData.entrySet()) {
            String field = metadata.getKey();
            String fieldInfo = field + "(" + field.getClass().getName() + ")";
            results.addMetadataField(fieldInfo);

            if (field.equals("jcr:lastModified")) {
                metadataMap.put("jcr:lastModified", metadata.getValue());

            } else if (field.equals("dam:artDocumentEditor")) {
                metadataMap.put(metadataNodePath + "dam:artDocumentEditor", metadata.getValue());

            } else if (field.equals("artHoldReason")) {
                metadataMap.put(metadataNodePath + "artHoldReason", metadata.getValue());

            } else if (field.equals("availableToShip")) {
                metadataMap.put(metadataNodePath + "availableToShip", metadata.getValue());

            } else if (field.equals("collection")) {
                String collectionTag = TagUtil.findTagIDByTitle(Constants.PICKLIST_TAG_PATH + "/corporate-marketing-line", (String) metadata.getValue(), resolver, true);
                metadataMap.put("corporateMarketingLine", collectionTag);

            } else if (field.equals("colorCode")) {
                metadataMap.put(metadataNodePath + "colorCode", metadata.getValue());

            } else if (field.equals("Desc") || field.equals("description")) {
                metadataMap.put(metadataNodePath + "dc:description", metadata.getValue());

            } else if (field.equals("fabricContent")) {
                metadataMap.put(metadataNodePath + "fabricContent", metadata.getValue());

            } else if (field.equals("gender")) {
                metadataMap.put(metadataNodePath + "gender",
                        TagUtil.findTagIDByTitle(Constants.PICKLIST_TAG_PATH + "/gender-age", (String) metadata.getValue(), resolver, true));

            } else if (field.equals("graphicsNumber")) {
                metadataMap.put(metadataNodePath + "graphicCode", metadata.getValue());

            } else if (field.equals("itemNumber")) {
                metadataMap.put(metadataNodePath + "itemNumber", metadata.getValue());

            } else if (field.equals("keywords")) {
                metadataMap.put(metadataNodePath + "keywords", metadata.getValue());

            } else if (field.equals("league")) {
                metadataMap.put(metadataNodePath + "league",
                        TagUtil.findTagIDByTitle(Constants.PICKLIST_TAG_PATH + "/league", (String) metadata.getValue(), resolver, true));

            } else if (field.equals("logoGraphicSeries")) {
                metadataMap.put(metadataNodePath + "graphicSeries", metadata.getValue());

            } else if (field.equals("orderDeadline")) {
                metadataMap.put(metadataNodePath + "orderDeadline", metadata.getValue());

            } else if (field.equals("playerNumber")) {
                metadataMap.put(metadataNodePath + "playerNumber", metadata.getValue());

            } else if (field.equals("pose")) {
                String pose = TagUtil.ensureTagExists(Constants.PICKLIST_TAG_PATH + "/pose", (String) metadata.getValue(), resolver);
                metadataMap.put(metadataNodePath + "pose", pose);

            } else if (field.equals("productCategory")) {
                metadataMap.put(metadataNodePath + "productGroup", metadata.getValue());

            } else if (field.equals("season")) {
                String seasonTagPath = Constants.ADIDAS_TAG_PATH + "/season";
                metadataMap.put(metadataNodePath + "season", TagUtil.findTagIDByTitle(seasonTagPath, (String) metadata.getValue(), resolver, true));

            } else if (field.equals("styleNumber")) {
                metadataMap.put(metadataNodePath + "styleNumber", metadata.getValue());

            } else if (field.equals("subCategory")) {
                String subCategory = TagUtil.findTagIDByTitle(Constants.ADIDAS_TAG_PATH + "/product-type", (String) metadata.getValue(), resolver, true);
                metadataMap.put(metadataNodePath + "productType", subCategory);

            } else if (field.equals("subCollection")) {
                String subCollection = TagUtil.findTagIDByTitle(Constants.PICKLIST_TAG_PATH + "/category-marketing-line", (String) metadata.getValue(), resolver, true);
                metadataMap.put(metadataNodePath + "categoryMarketingLine", subCollection);

            } else if (field.equals("team")) {
                metadataMap.put(metadataNodePath + "team", metadata.getValue());

            } else if (field.equals("teamplayer")) {
                metadataMap.put(metadataNodePath + "playerName", metadata.getValue());

            } else if (field.equals("vendor")) {
                metadataMap.put(metadataNodePath + "vendor", metadata.getValue());

            } else if (field.equals("LastSAMMSUpdate")) {
                metadataMap.put(metadataNodePath + "lastSAMMSUpdate", metadata.getValue());

            } else if (field.equals("uploaderEmail")) {
                metadataMap.put(metadataNodePath + "jcr:createdBy", metadata.getValue());

            } else if (field.equals("comments")) {
            } else {// unmapped fields
                log.warn("Unmapped metadata field: " + field);
                metadataMap.put("vivo." + field, metadata.getValue());
            }
        }

        return metadataMap;
    }

    /**
     * Determines if this asset should be imported as an active asset
     *
     * @param xmlParser completed XML parser object
     * @return
     */
    private boolean isActiveMigration(WidenXMLParser xmlParser) {

        // If it is not active in Widen, not active in AEM
        if (!xmlParser.isActive()) {
            return false;
        }

        // If the lastModified version is too old, it is inactive
        if (xmlParser.getLastModifiedDate().before(Constants.lastActiveDate)) {
            return false;
        }

        // If it is a DI folder (sortByDate = true), then check if the assetGroup[] is in the activeMigrations list
        if (sortByDate) {
            for (String assetGroup : xmlParser.getAssetGroups()) {
                if (Constants.activeMigrations.contains(assetGroup.toLowerCase())) {
                    return true;
                }
            }
            return false;
        }

        // This is most likely an active VIVO migration
        return xmlParser.isActive();
    }

}
