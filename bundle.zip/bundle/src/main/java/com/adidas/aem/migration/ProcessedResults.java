package com.adidas.aem.migration;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by bear on 11/3/15.
 */
public class ProcessedResults {

    private HashMap<String,String> finalizedAssets;
    private ArrayList<String> metadataFields;

    ProcessedResults() {
        this.finalizedAssets = new HashMap<String, String>();
        this.metadataFields = new ArrayList<String>();
    }

    public void addMetadataField(String metadataField) {
        if (!metadataFields.contains(metadataField)) {
            metadataFields.add(metadataField);
        }
    }

    public void addFinalizedAsset(String key, String value) {

    }

    public HashMap<String, String> getFinalizedAssets() {
        return finalizedAssets;
    }

    public ArrayList<String> getMetadataFields() {
        return metadataFields;
    }
}
